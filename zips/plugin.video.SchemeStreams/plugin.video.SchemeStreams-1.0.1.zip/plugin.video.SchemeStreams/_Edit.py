import xbmcaddon

MainBase = 'http://bit.ly/2wjHl8c'
addon = xbmcaddon.Addon('plugin.video.SchemeStreams')