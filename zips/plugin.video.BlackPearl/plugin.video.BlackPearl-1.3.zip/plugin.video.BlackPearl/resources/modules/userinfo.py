import base64

addon_name   = base64.b64decode('QmxhY2tQZWFybA==')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLkJsYWNrUGVhcmw=')

host         = base64.b64decode('aHR0cDovL3Blcm9sYW5lZ3JhLm5ldA==')
port         = base64.b64decode('ODAwMA==')