import time
import xbmc
import os
import xbmcgui
import urllib2


xbmc.executebuiltin('plugin://plugin.video.covenant/?action=tvSearch')
