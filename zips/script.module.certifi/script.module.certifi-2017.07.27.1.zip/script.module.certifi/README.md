script.module.certifi
=====================

Python certifi library packed for KODI.

See https://github.com/certifi/python-certifi
