import time
import xbmc
import os
import xbmcgui
import urllib2 

#xbmc.executebuiltin('PlayMedia("plugin://script.tvguide.cerebrotv.usa")')   
xbmc.executebuiltin('plugin://script.tvguide.cerebrotv.usa')
