import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , datetime , urlresolver , random , liveresolver , base64
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
if 64 - 64: i11iIiiIii
VVeve = 'plugin.video.finalgear'
VeevVee = Addon ( VVeve , sys . argv )
VevVevVVevVevVev = xbmcaddon . Addon ( id = VVeve )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.jpg' ) )
eeeevVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.jpg' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'icon.png' ) )
Veveveeeeeevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources/art' , 'next.png' ) )
I1IiiI = base64 . b64decode ( b'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvVTdOdENSNWk=' )
IIi1IiiiI1Ii = VevVevVVevVevVev . getSetting ( 'password' )
I11i11Ii = VevVevVVevVevVev . getSetting ( 'enable_meta' )
eVeveveVe = 'http://matsbuilds.uk'
VVVeev = xbmc . translatePath ( 'special://home/userdata/addon_data/' + VVeve )
if 54 - 54: i1 - eev * i1eVeevVeV * iIIIiiIIiiiIi % Ve
def eevV ( ) :
 if not os . path . exists ( VVVeev ) :
  os . mkdir ( VVVeev )
  #        popup(messagetext,'GlobalCompare')        
 IiiIII111iI = IiII ( I1IiiI )
 iI1Ii11111iIi = re . compile ( '<item>(.+?)</item>' ) . findall ( IiiIII111iI )
 for i1i1II in iI1Ii11111iIi :
  VeveeevVVev = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i1i1II )
  for I1i1iiI1 , iiIIIII1i1iI , eeveVev , iiiii in VeveeevVVev :
   eeevev ( I1i1iiI1 , iiIIIII1i1iI , 1 , eeveVev , iiiii )
   if 88 - 88: VevVeeveVeve . II1iI . i1iIii1Ii1II
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 1 - 1: VevVeeeevev
 if 87 - 87: i1IIi11111i / I11i1i11i1I % ee / VVVevV / I1ii * IIIII
def I1 ( name , url , iconimage , fanart ) :
 IiiIII111iI = IiII ( url )
 VevVeVeeeveve ( IiiIII111iI )
 if '<message>' in IiiIII111iI :
  eVeveveVe = re . compile ( '<message>(.+?)</message>' ) . findall ( IiiIII111iI ) [ 0 ]
  iiiI11 ( eVeveveVe , prettyname )
 if '<intro>' in IiiIII111iI :
  VVeeV = re . compile ( '<intro>(.+?)</intro>' ) . findall ( IiiIII111iI ) [ 0 ]
  INTROPLAY ( VVeeV )
 if 'XXX>yes</XXX' in IiiIII111iI : ADULT_CHECK ( IiiIII111iI )
 iI1Ii11111iIi = re . compile ( '<item>(.+?)</item>' ) . findall ( IiiIII111iI )
 VVeVeveve = len ( iI1Ii11111iIi )
 for i1i1II in iI1Ii11111iIi :
  try :
   if '<sportsdevil>' in i1i1II : II111iiii ( i1i1II , url )
   elif '<folder>' in i1i1II : II ( i1i1II )
   elif '<iptv>' in i1i1II : IPTV ( i1i1II )
   elif '<image>' in i1i1II : IMAGE ( i1i1II )
   elif '<text>' in i1i1II : eVeVeeveveVe ( i1i1II )
   elif '<scraper>' in i1i1II : SCRAPER ( i1i1II )
   elif '<redirect>' in i1i1II : REDIRECT ( i1i1II )
   elif '<oktitle>' in i1i1II : VeeevevVevevVevVevV ( i1i1II )
   else : VeeVevVV ( i1i1II , url )
  except : pass
  if 28 - 28: iIii1
def VeeevevVevevVevVevV ( item ) :
 I1i1iiI1 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 eVVeVev = re . compile ( '<oktitle>(.+?)</oktitle>' ) . findall ( item ) [ 0 ]
 VevVeVevevevVevVV = re . compile ( '<line1>(.+?)</line1>' ) . findall ( item ) [ 0 ]
 iiI1IiI = re . compile ( '<line2>(.+?)</line2>' ) . findall ( item ) [ 0 ]
 IIeeVeVeeevV = re . compile ( '<line3>(.+?)</line3>' ) . findall ( item ) [ 0 ]
 VeeVev = '##' + eVVeVev + '#' + VevVeVevevevVevVV + '#' + iiI1IiI + '#' + IIeeVeVeeevV + '##'
 eeveVev = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 iiiii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 II11iiii1Ii ( I1i1iiI1 , VeeVev , 17 , eeveVev , iiiii )
 if 70 - 70: Vevev / i1I1i1Ii11 . IIIIII11i1I - I1ii % i1iIii1Ii1II
def VevVVV ( name , url ) :
 eeveeveVVVeevee = re . compile ( '##(.+?)##' ) . findall ( url ) [ 0 ] . split ( '#' )
 eeveeeveevVevevVV = xbmcgui . Dialog ( )
 eeveeeveevVevevVV . ok ( eeveeveVVVeevee [ 0 ] , eeveeveVVVeevee [ 1 ] , eeveeveVVVeevee [ 2 ] , eeveeveVVVeevee [ 3 ] )
 if 80 - 80: iIIIiiIIiiiIi
 if 70 - 70: VevVeeeevev - i1IIi11111i
def eVeVeeveveVe ( item ) :
 I1i1iiI1 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 VeeVev = re . compile ( '<text>(.+?)</text>' ) . findall ( item ) [ 0 ]
 eeveVev = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 iiiii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 II11iiii1Ii ( I1i1iiI1 , VeeVev , 9 , eeveVev , iiiii )
 if 43 - 43: I1ii / Ve / i1eVeevVeV . i1IIi11111i . IIIII
def i11Iiii ( name , url ) :
 iI = I1i1I1II ( url )
 i1IiIiiI ( name , iI )
 if 31 - 31: IIIII . IIIII - i1IIi11111i / i1iIii1Ii1II + IIIIII11i1I * VevVeeveVeve
def VeeVevVV ( item , url ) :
 VeveeVeeeeV = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 VeveeevVVev = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for I1i1iiI1 , eevevV , eeveVev , iiiii in VeveeevVVev :
  if 'youtube.com/playlist?' in eevevV :
   VVVevVVVevevee = eevevV . split ( 'list=' ) [ 1 ]
   eeevev ( I1i1iiI1 , eevevV , Iii111II , eeveVev , iiiii , description = VVVevVVVevevee )
 if len ( VeveeVeeeeV ) == 1 :
  VeveeevVVev = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
  for I1i1iiI1 , url , eeveVev , iiiii in VeveeevVVev :
   if '.ts' in url : II11iiii1Ii ( I1i1iiI1 , url , 16 , eeveVev , iiiii , description = '' )
   elif '<meta>' in item :
    iiii11I = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
    addLinkMeta ( I1i1iiI1 , url , 2 , eeveVev , 10 , iiii11I , isFolder = False )
   else : VeeevVVeveVV ( I1i1iiI1 , url , 2 , eeveVev , iiiii )
 elif len ( VeveeVeeeeV ) > 1 :
  I1i1iiI1 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  eeveVev = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  iiiii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  if '.ts' in url : II11iiii1Ii ( I1i1iiI1 , url , 16 , eeveVev , iiiii , description = '' )
  elif '<meta>' in item :
   iiii11I = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
   addLinkMeta ( I1i1iiI1 , url , 3 , eeveVev , 80 , iiii11I , isFolder = False )
  else : VeeevVVeveVV ( I1i1iiI1 , url , 3 , eeveVev , iiiii )
  if 50 - 50: VevVeeveVeve
def II ( item ) :
 VeveeevVVev = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for I1i1iiI1 , iiIIIII1i1iI , eeveVev , iiiii in VeveeevVVev :
  if 'youtube.com/channel/' in iiIIIII1i1iI :
   VVVevVVVevevee = iiIIIII1i1iI . split ( 'channel/' ) [ 1 ]
   eeevev ( I1i1iiI1 , iiIIIII1i1iI , Iii111II , eeveVev , iiiii , description = VVVevVVVevevee )
  elif 'youtube.com/user/' in iiIIIII1i1iI :
   VVVevVVVevevee = iiIIIII1i1iI . split ( 'user/' ) [ 1 ]
   eeevev ( I1i1iiI1 , iiIIIII1i1iI , Iii111II , eeveVev , iiiii , description = VVVevVVVevevee )
  elif 'youtube.com/playlist?' in iiIIIII1i1iI :
   VVVevVVVevevee = iiIIIII1i1iI . split ( 'list=' ) [ 1 ]
   eeevev ( I1i1iiI1 , iiIIIII1i1iI , Iii111II , eeveVev , iiiii , description = VVVevVVVevevee )
  elif 'plugin://' in iiIIIII1i1iI :
   Ii1i11IIii1I = HTMLParser ( )
   iiIIIII1i1iI = Ii1i11IIii1I . unescape ( iiIIIII1i1iI )
   eeevev ( I1i1iiI1 , iiIIIII1i1iI , Iii111II , eeveVev , iiiii )
  else :
   eeevev ( I1i1iiI1 , iiIIIII1i1iI , 1 , eeveVev , iiiii )
   if 52 - 52: i1IIi11111i - i1eVeevVeV + IIIII + IIIII - i1IIi11111i / i1I1i1Ii11
def II111iiii ( item , url ) :
 VeveeVeeeeV = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item )
 I1I = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 if len ( VeveeVeeeeV ) + len ( I1I ) == 1 :
  I1i1iiI1 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  eeveVev = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item ) [ 0 ]
  iiiii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  iIi11Ii1 = re . compile ( '<referer>(.+?)</referer>' ) . findall ( item ) [ 0 ]
  IiiIII111iI = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url
  url = IiiIII111iI + '%26referer=' + iIi11Ii1
  II11iiii1Ii ( I1i1iiI1 , url , 16 , eeveVev , iiiii )
 elif len ( VeveeVeeeeV ) + len ( I1I ) > 1 :
  I1i1iiI1 = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  eeveVev = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  iiiii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  II11iiii1Ii ( I1i1iiI1 , url , 3 , eeveVev , iiiii )
  if 50 - 50: Ve - IIIIII11i1I * I11i1i11i1I / i1I1i1Ii11 + i1IIi11111i
  if 88 - 88: IIIII / i1I1i1Ii11 + iIii1 - Ve / IIIIII11i1I - VevVeeeevev
def IIIIii ( ) :
 Veveev = xbmc . Keyboard ( '' , 'Search Final gear' )
 Veveev . doModal ( )
 if ( Veveev . isConfirmed ( ) ) :
  VVVevVVVevevee = Veveev . getText ( )
  VVVevVVVevevee = VVVevVVVevevee . upper ( )
 else : quit ( )
 IiiIII111iI = IiII ( 'http://pastebin.com/TqpecnXw' )
 VVevevVe = re . compile ( '<link>(.+?)</link>' ) . findall ( IiiIII111iI )
 for iiIIIII1i1iI in VVevevVe :
  try :
   IiiIII111iI = IiII ( iiIIIII1i1iI )
   VevVVVevVVeVevV = re . compile ( '<item>(.+?)</item>' ) . findall ( IiiIII111iI )
   for i1i1II in VevVVVevVVeVevV :
    iI1Ii11111iIi = re . compile ( '<title>(.+?)</title>' ) . findall ( i1i1II )
    for VevevVeeveveveeVev in iI1Ii11111iIi :
     VevevVeeveveveeVev = VevevVeeveveveeVev . upper ( )
     if VVVevVVVevevee in VevevVeeveveveeVev :
      try :
       if '<sportsdevil>' in i1i1II : II111iiii ( i1i1II , iiIIIII1i1iI )
       elif '<folder>' in i1i1II : II ( i1i1II )
       elif '<iptv>' in i1i1II : IPTV ( i1i1II )
       elif '<image>' in i1i1II : IMAGE ( i1i1II )
       elif '<text>' in i1i1II : eVeVeeveveVe ( i1i1II )
       else : VeeVevVV ( i1i1II , iiIIIII1i1iI )
      except : pass
  except : pass
  if 100 - 100: i1 + Vevev - VVVevV + i11iIiiIii * IIIII
def iII ( name , url , iconimage ) :
 eeveeVeeeeveveveVV = [ ]
 VeeveVVe = [ ]
 VeevVeVeveveVVeve = [ ]
 IiiIII111iI = IiII ( url )
 VVVevevV = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( IiiIII111iI ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( VVVevevV ) [ 0 ]
 VeveeVeeeeV = [ ]
 if '<link>' in VVVevevV :
  VVeVVeveeeveeV = re . compile ( '<link>(.+?)</link>' ) . findall ( VVVevevV )
  for VeveevVevevVeeveev in VVeVVeveeeveeV :
   VeveeVeeeeV . append ( VeveevVevevVeeveev )
 if '<sportsdevil>' in VVVevevV :
  VevevVeveVVevevVevev = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( VVVevevV )
  for i1Veevev in VevevVeveVVevevVevev :
   i1Veevev = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + i1Veevev
   VeveeVeeeeV . append ( i1Veevev )
 i1i = 1
 for iiI111I1iIiI in VeveeVeeeeV :
  IIIi1I1IIii1II = iiI111I1iIiI
  if '(' in iiI111I1iIiI :
   iiI111I1iIiI = iiI111I1iIiI . split ( '(' ) [ 0 ]
   Vev = str ( IIIi1I1IIii1II . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   eeveeVeeeeveveveVV . append ( iiI111I1iIiI )
   VeeveVVe . append ( Vev )
  else :
   ii1ii1ii = iiI111I1iIiI . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
   eeveeVeeeeveveveVV . append ( iiI111I1iIiI )
   VeeveVVe . append ( 'Link ' + str ( i1i ) + ' | ' + ii1ii1ii )
  i1i = i1i + 1
 eeveeeveevVevevVV = xbmcgui . Dialog ( )
 eeeeeVeeeveee = eeveeeveevVevevVV . select ( name , VeeveVVe )
 if eeeeeVeeeveee < 0 : quit ( )
 else :
  url = eeveeVeeeeveveveVV [ eeeeeVeeeveee ]
  I1I1IiI1 ( name , url , iconimage )
  if 5 - 5: i1IIi11111i * IIIIII11i1I + VevVeeeevev . VVVevV + VevVeeeevev
  if 91 - 91: i1
def I1I1IiI1 ( name , url , iconimage ) :
 try :
  if 'plugin://plugin.video.SportsDevil/' in url :
   eVVeev ( name , url , iconimage )
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
   eVVeev ( name , url , iconimage )
  elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   eeevevVeveveV ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   eeevevVeveveV ( name , url , iconimage )
  else : eeevevVeveveV ( name , url , iconimage )
 except :
  iIiIIIi ( addtags ( 'JukeBox' ) , 'Stream Unavailable' , '3000' , II1 )
  if 93 - 93: iIii1
def eeevevVeveveV ( name , url , iconimage ) :
 i1IIIiiII1 = True
 VVVVeVeeevVevVev = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; VVVVeVeeevVevVev . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1IIIiiII1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = VVVVeVeeevVevVev )
 VVVVeVeeevVevVev . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , VVVVeVeeevVevVev )
 if 85 - 85: ee % i11iIiiIii - iIii1 * i1eVeevVeV / VevVeeveVeve % VevVeeveVeve
def eVVeev ( name , url , iconimage ) :
 i1IIIiiII1 = True
 VVVVeVeeevVevVev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage ) ; VVVVeVeeevVevVev . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1IIIiiII1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = VVVVeVeeevVevVev )
 xbmc . Player ( ) . play ( url , VVVVeVeeevVevVev , False )
 if 1 - 1: i1iIii1Ii1II - ee . I1ii . i1iIii1Ii1II / II1iI + I1ii
 if 78 - 78: i1 . ee . Ve % VVVevV
 if 49 - 49: IIIII / i1iIii1Ii1II . Ve
def IiII ( url ) :
 eeVVeeeeee = urllib2 . Request ( url )
 eeVVeeeeee . add_header ( 'User-Agent' , 'mat' )
 II1I = urllib2 . urlopen ( eeVVeeeeee )
 IiiIII111iI = II1I . read ( )
 II1I . close ( )
 IiiIII111iI = IiiIII111iI . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 if url <> eVeveveVe : IiiIII111iI = IiiIII111iI . replace ( '\n' , '' ) . replace ( '\r' , '' )
 return IiiIII111iI
 if 84 - 84: Vevev . i11iIiiIii . Vevev * I11i1i11i1I - I1ii
def I1i1I1II ( url ) :
 eeVVeeeeee = urllib2 . Request ( url )
 eeVVeeeeee . add_header ( 'User-Agent' , 'mat' )
 II1I = urllib2 . urlopen ( eeVVeeeeee )
 IiiIII111iI = II1I . read ( )
 II1I . close ( )
 return IiiIII111iI
 if 42 - 42: i11iIiiIii
 if 33 - 33: iIii1 - i1 * iIIIiiIIiiiIi * i1IIi11111i - II1iI
def iiIiI ( ) :
 eeveveeeVevVe = [ ]
 eevVevVVVevVee = sys . argv [ 2 ]
 if len ( eevVevVVVevVee ) >= 2 :
  iiIiII1 = sys . argv [ 2 ]
  VVVevevVevV = iiIiII1 . replace ( '?' , '' )
  if ( iiIiII1 [ len ( iiIiII1 ) - 1 ] == '/' ) :
   iiIiII1 = iiIiII1 [ 0 : len ( iiIiII1 ) - 2 ]
  iii = VVVevevVevV . split ( '&' )
  eeveveeeVevVe = { }
  for i1i in range ( len ( iii ) ) :
   eVeeVVVeVe = { }
   eVeeVVVeVe = iii [ i1i ] . split ( '=' )
   if ( len ( eVeeVVVeVe ) ) == 2 :
    eeveveeeVevVe [ eVeeVVVeVe [ 0 ] ] = eVeeVVVeVe [ 1 ]
 return eeveveeeVevVe
 if 41 - 41: IIIII - i1 - i1
def iIiIIIi ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 68 - 68: VVVevV % i1I1i1Ii11
def eeevev ( name , url , mode , iconimage , fanart , description = '' ) :
 eeVevevVVev = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 i1IIIiiII1 = True
 VVVVeVeeevVevVev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 VVVVeVeeevVevVev . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 VVVVeVeeevVevVev . setProperty ( 'fanart_image' , fanart )
 if 'youtube.com/channel/' in url :
  eeVevevVVev = 'plugin://plugin.video.youtube/channel/' + description + '/'
 if 'youtube.com/user/' in url :
  eeVevevVVev = 'plugin://plugin.video.youtube/user/' + description + '/'
 if 'youtube.com/playlist?' in url :
  eeVevevVVev = 'plugin://plugin.video.youtube/playlist/' + description + '/'
 if 'plugin://' in url :
  eeVevevVVev = url
 i1IIIiiII1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeVevevVVev , listitem = VVVVeVeeevVevVev , isFolder = True )
 return i1IIIiiII1
 if 31 - 31: iIii1 % iIii1 % I1ii
def II11iiii1Ii ( name , url , mode , iconimage , fanart , description = '' ) :
 eeVevevVVev = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 i1IIIiiII1 = True
 VVVVeVeeevVevVev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 VVVVeVeeevVevVev . setProperty ( 'fanart_image' , fanart )
 i1IIIiiII1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeVevevVVev , listitem = VVVVeVeeevVevVev , isFolder = False )
 return i1IIIiiII1
 if 69 - 69: i1iIii1Ii1II - II1iI + iIIIiiIIiiiIi / i1I1i1Ii11
def VeeevVVeveVV ( name , url , mode , iconimage , fanart , description = '' ) :
 eeVevevVVev = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 i1IIIiiII1 = True
 VVVVeVeeevVevVev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 VVVVeVeeevVevVev . setProperty ( 'fanart_image' , fanart )
 VVVVeVeeevVevVev . setProperty ( "IsPlayable" , "true" )
 i1IIIiiII1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeVevevVVev , listitem = VVVVeVeeevVevVev , isFolder = False )
 return i1IIIiiII1
 if 49 - 49: i1 . iIii1
def iiiI11 ( url , name ) :
 I1iI1iIi111i = I1i1I1II ( url )
 if len ( I1iI1iIi111i ) > 1 :
  iiIi1IIi1I = VVVeev
  eevVeVVeveveveeVev = os . path . join ( os . path . join ( iiIi1IIi1I , '' ) , name + '.txt' )
  if not os . path . exists ( eevVeVVeveveveeVev ) :
   file ( eevVeVVeveveveeVev , 'w' ) . close ( )
  eeveeveeveVeveVV = open ( eevVeVVeveveveeVev )
  ii1Ii11I = eeveeveeveVeveVV . read ( )
  if ii1Ii11I == I1iI1iIi111i : pass
  else :
   i1IiIiiI ( 'Final Gear Information' , I1iI1iIi111i )
   eeveveev = open ( eevVeVVeveveveeVev , "w" )
   eeveveev . write ( I1iI1iIi111i )
   eeveveev . close ( )
   if 45 - 45: i1
def i1IiIiiI ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 I1IiiiiI = xbmcgui . Window ( id )
 eevVIiII = 50
 while ( eevVIiII > 0 ) :
  try :
   xbmc . sleep ( 10 )
   eevVIiII -= 1
   I1IiiiiI . getControl ( 1 ) . setLabel ( heading )
   I1IiiiiI . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 25 - 25: i1 - i1 * i1IIi11111i
def VevVeVeeeveve ( link ) :
 try :
  VVVVeveeev = re . compile ( '<layouttype>(.+?)</layouttype>' ) . findall ( link ) [ 0 ]
  if VVVVeveeev == 'thumbnail' : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 except : pass
 if 35 - 35: IIIII - VevVeeveVeve % i1IIi11111i . i1eVeevVeV % IIIII
iiIiII1 = iiIiI ( ) ; iiIIIII1i1iI = None ; I1i1iiI1 = None ; Iii111II = None ; I1i1Iiiii = None ; eeveVev = None
try : I1i1Iiiii = urllib . unquote_plus ( iiIiII1 [ "site" ] )
except : pass
try : iiIIIII1i1iI = urllib . unquote_plus ( iiIiII1 [ "url" ] )
except : pass
try : I1i1iiI1 = urllib . unquote_plus ( iiIiII1 [ "name" ] )
except : pass
try : Iii111II = int ( iiIiII1 [ "mode" ] )
except : pass
try : eeveVev = urllib . unquote_plus ( iiIiII1 [ "iconimage" ] )
except : pass
try : iiiii = urllib . unquote_plus ( iiIiII1 [ "fanart" ] )
except : pass
if 94 - 94: i1IIi11111i * IIIII / II1iI / IIIII
try : eVev = urllib . unquote_plus ( [ "description" ] )
except : pass
if 75 - 75: IIIIII11i1I + VevVeeeevev + i1IIi11111i * I1ii % ee . iIii1
if Iii111II == None or iiIIIII1i1iI == None or len ( iiIIIII1i1iI ) < 1 : eevV ( )
elif Iii111II == 1 : I1 ( I1i1iiI1 , iiIIIII1i1iI , eeveVev , iiiii )
elif Iii111II == 2 : I1I1IiI1 ( I1i1iiI1 , iiIIIII1i1iI , eeveVev )
elif Iii111II == 3 : iII ( I1i1iiI1 , iiIIIII1i1iI , eeveVev )
elif Iii111II == 4 : eeevevVeveveV ( I1i1iiI1 , iiIIIII1i1iI , eeveVev )
elif Iii111II == 5 : IIIIii ( )
elif Iii111II == 9 : i11Iiii ( I1i1iiI1 , iiIIIII1i1iI )
elif Iii111II == 16 : eVVeev ( I1i1iiI1 , iiIIIII1i1iI , eeveVev )
elif Iii111II == 17 : VevVVV ( I1i1iiI1 , iiIIIII1i1iI )
if 55 - 55: VVVevV . VevVeeveVeve
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
