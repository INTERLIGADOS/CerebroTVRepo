import cookielib,base64

a=base64.b64decode("aHR0cDovL3BsYW5ldGlwdHZhZGRvbi5hbHRlcnZpc3RhLm9yZy9tZW51LnBocA==")