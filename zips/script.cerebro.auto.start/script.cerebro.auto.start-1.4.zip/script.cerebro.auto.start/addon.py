exit()
#TODO
import xbmc
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.wargames/",return)')
