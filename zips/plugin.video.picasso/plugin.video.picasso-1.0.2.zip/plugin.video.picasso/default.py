#V 1.0.2
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , requests , urllib , urllib2 , json , os , re , sys , datetime , urlresolver , random , liveresolver , base64 , pyxbmct
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
import nanscrapers
import requests
import downloader as Get_Files
import extract
import time
if 64 - 64: i11iIiiIii
VVeve = 'plugin.video.picasso'
VeevVee = Addon ( VVeve , sys . argv )
VevVevVVevVevVev = xbmcaddon . Addon ( id = VVeve )
iiiii = xbmcaddon . Addon ( ) . getAddonInfo
eeeevVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
Veveveeeeeevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'icon.png' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources/art' , 'next.png' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources' , 'rd.txt' ) )
I11i11Ii = 'http://matsbuilds.uk/pin'
eVeveveVe = xbmcaddon . Addon ( ) . getSetting ( 'password' )
VVVeev = xbmcaddon . Addon ( ) . getSetting ( 'enable_meta' )
Veeeeveveve = base64 . b64decode ( 'aHR0cHM6Ly94aGFtc3Rlci5jb20v' )
IiIi11iIIi1Ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
VeevV = requests . session ( )
IiI = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvaW5mby50eHQ=' )
eeVe = xbmc . translatePath ( 'special://home/userdata/addon_data/' + VVeve )
Ve = xbmc . translatePath ( os . path . join ( 'special://home/userdata/Database' , 'picasso.db' ) )
eevV = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'repository.Goliath' ) )
IiiIII111iI = '[COLOR cyan]Picasso[/COLOR]'
IiII = open ( Ve , 'a' )
IiII . close ( )
if 28 - 28: Ii11111i * iiI1i1
if 46 - 46: VeeevVVeveVV * Ii * Veeve
if not os . path . exists ( eevV ) :
 VVVeveeve = xbmcgui . Dialog ( ) . yesno ( IiiIII111iI , 'This Add-on requires [COLOR cyan]Goliaths Repo[/COLOR] to be installed to work correctly would you like to install it now?' , '' , yeslabel = '[B][COLOR white]YES[/COLOR][/B]' , nolabel = '[B][COLOR grey]NO[/COLOR][/B]' )
 if VVVeveeve == 1 :
  Ii1iI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  if not os . path . exists ( Ii1iI ) :
   os . makedirs ( Ii1iI )
  VeI1Ii11I1Ii1i = base64 . b64decode ( b'aHR0cDovL21hdHNidWlsZHMudWsvZ29saWF0aC9yZXBvc2l0b3J5LkdvbGlhdGgtMS40LnppcA==' )
  Vee = xbmcgui . DialogProgress ( )
  Vee . create ( IiiIII111iI , "" , "" , "Downloading [COLOR cyan]Goliaths Repo[/COLOR]" )
  eeveVeVeveve = os . path . join ( Ii1iI , 'repo.zip' )
  if 43 - 43: VevVVe . II1Iiii1111i
  try :
   os . remove ( eeveVeVeveve )
  except :
   pass
   if 25 - 25: VVeevevev
  Get_Files . download ( VeI1Ii11I1Ii1i , eeveVeVeveve , Vee )
  Vev = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  Vee . update ( 0 , "" , "Installing [COLOR red]Golitaths Repo[/COLOR] Please Wait" , "" )
  extract . all ( eeveVeVeveve , Vev , Vee )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  xbmc . executebuiltin ( "UpdateLocalAddons" )
  if 34 - 34: Veveevev % eeveee / VVVevV / I1ii * eVVVeeveevV + VVeVeeevevee
  if 41 - 41: i11IiIiiIIIII / IiiIII111ii / i1iIIi1
def ii11iIi1I ( st ) :
 import re
 st = re . sub ( '\[.+\]' , '' , st )
 import string
 iI111I11I1I1 = 0
 for VeevV in st :
  if VeevV in 'lij|\' ' : iI111I11I1I1 += 37
  elif VeevV in '![]fI.,:;/\\t' : iI111I11I1I1 += 50
  elif VeevV in '`-(){}r"' : iI111I11I1I1 += 60
  elif VeevV in '*^zcsJkvxy' : iI111I11I1I1 += 85
  elif VeevV in 'aebdhnopqug#$L+<>=?_~FZT' + string . digits : iI111I11I1I1 += 95
  elif VeevV in 'BSPEAKVXY&UwNRCHD' : iI111I11I1I1 += 112
  elif VeevV in 'QGOMm%W@' : iI111I11I1I1 += 135
  else : iI111I11I1I1 += 50
 return int ( iI111I11I1I1 * 6.5 / 100 )
 if 55 - 55: iI1I % iiiIi - eVVVeeveevV / Ii11111i % eeveee + VVeevevev
def iI111IiI111I ( Heading = xbmcaddon . Addon ( ) . getAddonInfo ( 'name' ) ) :
 VeeVeVevVe = xbmc . Keyboard ( '' , Heading )
 VeeVeVevVe . doModal ( )
 if ( VeeVeVevVe . isConfirmed ( ) ) :
  return VeeVeVevVe . getText ( )
  if 47 - 47: I1ii
def iiIiIiIi ( url ) :
 if 33 - 33: i11IiIiiIIIII + Veeve % i11iIiiIii . iiiIi - VevVVe
 import webbrowser
 if 66 - 66: i11IiIiiIIIII - VeeevVVeveVV * VeeevVVeveVV . eVVVeeveevV . VVVevV
 IiI1i11iii1 = webbrowser . open
 eeevVeevevVeev = xbmc . executebuiltin
 eVVVeveve = lambda VevVeveveevVVVev : xbmc . getCondVisibility ( str ( VevVeveveevVVVev ) )
 Ii1iIIIi1ii = lambda VevVeveveevVVVev : eeevVeevevVeev ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( VevVeveveevVVVev ) )
 if 80 - 80: VVeVeeevevee * i11iIiiIii / iI1I
 I11II1i = 'System.Platform.Android'
 if 23 - 23: VVVevV / eeveee + VVeVeeevevee + VVeVeeevevee / Veeve
 if eVVVeveve ( I11II1i ) : Ii1iIIIi1ii ( base64 . b64decode ( url ) )
 else : IiI1i11iii1 ( base64 . b64decode ( url ) )
 if 26 - 26: VeeevVVeveVV
 if 12 - 12: VeeevVVeveVV % Veveevev / iiiIi % eeveee
def iiii ( ) :
 if 54 - 54: VVVevV * eVVVeeveevV
 if 13 - 13: i1iIIi1 + Veveevev - VeeevVVeveVV + iI1I . IiiIII111ii + VVeevevev
 import sys
 if 8 - 8: iiI1i1 . VevVVe - iiI1i1 * i11IiIiiIIIII
 VVVV = 'aHR0cDovL21hdHNidWlsZHMudWsvcGlu'
 VVVevev = 'aHR0cDovL29mZnNob3JlcGx1Z2lucy5jb20vcGluL2NoZWNrLnBocD9waW49JXM='
 iiiiiIIii = 'W0NPTE9SIGJsdWVdSW4gb3JkZXIgdG8gY29udGludWUgcGxlYXNlWy9DT0xPUl0gW0NPTE9SIHdoaXRlXVtCXVZFUklGWVsvQl1bL0NPTE9SXSBbQ09MT1IgYmx1ZV15b3VyIGRldmljZSBieSBnZXR0aW5nIGEgcGluIGZyb20gb3VyIHdlYnNpdGUgYW5kIGVudGVyaW5nIHRoZSBwaW4gb24gdGhlIG5leHQgcHJvbXQuWy9DT0xPUl0='
 if 71 - 71: eVVVeeveevV + i11IiIiiIIIII * eVVVeeveevV - VVeevevev * eeveee
 VeeeevVeeevevev = base64 . b64decode ( iiiiiIIii )
 ee = xbmcaddon . Addon ( ) . getAddonInfo
 ii11I = xbmcaddon . Addon ( ) . getSetting ( 'pin' )
 VeeevVVeveVVii11i1 = lambda VevVeveveevVVVev : base64 . b64decode ( str ( VevVeveveevVVVev ) )
 IIIii1II1II = lambda VevVeveveevVVVev : requests . get ( base64 . b64decode ( VVVevev ) % ( VevVeveveevVVVev ) ) . text . strip ( )
 i1I1iI = lambda VevVeveveevVVVev : xbmcaddon . Addon ( ) . setSetting ( base64 . b64decode ( 'cGlu' ) , VevVeveveevVVVev )
 eeevVeeVVeev = lambda VevVeveveevVVVev : xbmcgui . Dialog ( ) . yesno ( ee ( 'name' ) , VevVeveveevVVVev , yeslabel = "Get A Pin" , nolabel = 'Cancel' )
 eevVVeveveV = bool ( IIIii1II1II ( ii11I ) == base64 . b64decode ( 'T0s=' ) )
 if 39 - 39: i1iIIi1 - Veeve * VVeevevev % eeveee * Veeve % Veeve
 if eevVVeveveV : return
 else :
  if 59 - 59: iiI1i1 + VevVVe - eeveee - VevVVe + eVVVeeveevV / VVVevV
  if eeevVeeVVeev ( VeeeevVeeevevev ) :
   iiIiIiIi ( VVVV )
   I1 = iI111IiI111I ( 'Type Your Pin Here' )
   i1I1iI ( I1 )
   iiii ( )
  else : sys . exit ( )
  if 71 - 71: eVVVeeveevV + iiiIi % i11iIiiIii + VVVevV - i1iIIi1
  if 88 - 88: Veveevev - VVeevevev % eVVVeeveevV
  if 16 - 16: VevVVe * I1ii % i1iIIi1
def Veeveveve ( ) :
 if not os . path . exists ( eeVe ) :
  os . mkdir ( eeVe )
 I11IiI1I11i1i ( IiI , 'GlobalCompare' )
 iI1ii1Ii ( '[B][COLOR yellow]Keep Safe[/COLOR][/B]' , 'url' , 22 , 'http://i.imgur.com/cR0cP8f.png' , II1 )
 iI1ii1Ii ( '[B][COLOR yellow]Find It...[/COLOR][/B]' , 'url' , 5 , 'http://i.imgur.com/ZQYQyHG.png' , II1 )
 iI1ii1Ii ( '[B][COLOR cyan]Movie Madness[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL01haW5tZW51LnhtbA==' ) , 26 , 'http://i.imgur.com/Y2rejnc.png' , II1 )
 iI1ii1Ii ( '[B][COLOR cyan]Telly Box[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvVHZTaG93cy9NYWlubWVudS54bWw=' ) , 27 , 'http://i.imgur.com/63LrHYW.png' , II1 )
 eeeeevevev = iIIIi1 ( iiII1i1 )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV in VVeVVeveeeveeV :
   iI1ii1Ii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , 1 , VevevVeveVVevevVevev , eeeevVV )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 11 - 11: i1iIIi1 . VVVevV
def eev ( name , url , iconimage , fanart ) :
 iI1ii1Ii ( '[B][COLOR yellow]MOVIE SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL1NlYXJjaC9TZWFyY2gudHh0' ) , 5 , 'http://i.imgur.com/QArRVYb.png' , II1 )
 iI1ii1Ii ( '[B][COLOR yellow]UK CINEMA RELEASE DATES[/COLOR][/B]' , 'http://www.empireonline.com/movies/features/upcoming-movies/' , 34 , 'http://i.imgur.com/aKQgDR7.png' , II1 )
 eeeeevevev = iIIIi1 ( url )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for name , url , iconimage , fanart in VVeVVeveeeveeV :
   eeeveVe ( name , url , iconimage , fanart , VVVevevV )
   if 89 - 89: Veveevev
def VVeveVeVVeveVVev ( name , url , iconimage , fanarts ) :
 iI1ii1Ii ( '[B][COLOR yellow]TV SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvYW5ld0V2b2x2ZW1lbnUvc2VhcmNoLnhtbA==' ) , 33 , 'http://i.imgur.com/he5RFkL.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]TV SCHEDULE[/COLOR][/B]' , 'http://www.tvwise.co.uk/uk-premiere-dates/' , 32 , 'http://i.imgur.com/XKAapZH.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]Latest Episodes[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20=' ) , 28 , 'http://i.imgur.com/n8itltl.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]Popular Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9wb3B1bGFyLXNlcmllcw==' ) , 29 , 'http://i.imgur.com/ury75ui.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]New Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9uZXctc2VyaWVz' ) , 30 , 'http://i.imgur.com/UPWjTLw.png' , fanarts )
 eVevVVeeevVV = Vevii1ii1ii ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eVevVVeeevVV )
 eeeeevevev = iIIIi1 ( url )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for name , url , iconimage , eeeevVV in VVeVVeveeeveeV :
   eeeveVe ( name , url , iconimage , eeeevVV , VVVevevV )
   if 91 - 91: i1iIIi1
def iiIii ( name , url , iconimage , fanart ) :
 eVevVVeeevVV = Vevii1ii1ii ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eVevVVeeevVV )
 eeeeevevev = iIIIi1 ( url )
 eeeevV ( eeeeevevev )
 if '<message>' in eeeeevevev :
  IiI = re . compile ( '<message>(.+?)</message>' ) . findall ( eeeeevevev ) [ 0 ]
  I11IiI1I11i1i ( IiI , eVevVVeeevVV )
 if '<intro>' in eeeeevevev :
  eVeVeveevevVVev = re . compile ( '<intro>(.+?)</intro>' ) . findall ( eeeeevevev ) [ 0 ]
  i1I1ii ( eVeVeveevevVVev )
 if 'XXX>yes</XXX' in eeeeevevev : eVVeev ( eeeeevevev )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  eeeveVe ( name , url , iconimage , fanart , VVVevevV )
  if 54 - 54: Ii11111i - i1iIIi1 % eVVVeeveevV
def eeeveVe ( name , url , iconimage , fanart , item ) :
 try :
  if '<sportsdevil>' in item : VVeV ( name , url , iconimage , fanart , item )
  elif '<iplayer>' in item : iII ( name , url , iconimage , fanart , item )
  elif '<folder>' in item : ii1ii11IIIiiI ( name , url , iconimage , fanart , item )
  elif '<iptv>' in item : VevevVVVeVeeevV ( name , url , iconimage , fanart , item )
  elif '<image>' in item : VevevevVVeevevee ( name , url , iconimage , fanart , item )
  elif '<text>' in item : eeevVVe ( name , url , iconimage , fanart , item )
  elif '<scraper>' in item : eeVVVevevVee ( name , url , iconimage , fanart , item )
  elif '<lbscraper>' in item : IiIIIi1iIi ( name , url , iconimage , fanart , item )
  elif '<redirect>' in item : eeVVeeeeee ( name , url , iconimage , fanart , item )
  elif '<oktitle>' in item : II1I ( name , url , iconimage , fanart , item )
  elif '<nan>' in item : Vevi1II1Iiii1I11 ( name , url , iconimage , fanart , item )
  elif '<adult>' in item : IIII ( name , url , iconimage , fanart , item )
  else : iiIiI ( name , url , iconimage , fanart , item )
 except : pass
 if 91 - 91: IiiIII111ii % Ii % iiI1i1
def iII ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<iplayer>(.+?)</iplayer>' ) . findall ( item ) [ 0 ]
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 url = 'plugin://plugin.video.iplayerwww/?url=%s&mode=202&name=%s&iconimage=%s&description=&subtitles_url=&logged_in=False' % ( url , name , iconimage )
 IIi1I11I1II ( name , url , 16 , iconimage , fanart )
 if 63 - 63: VeeevVVeveVV - VVeevevev . Veeve / eeveee . Veveevev / Ii11111i
def Vevi1II1Iiii1I11 ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 eevVVVVevevVevVe = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 ii = re . compile ( '<nan>(.+?)</nan>' ) . findall ( item ) [ 0 ]
 eVeeVVVeVe = re . compile ( '<imdb>(.+?)</imdb>' ) . findall ( item ) [ 0 ]
 if ii == 'movie' :
  eVeeVVVeVe = eVeeVVVeVe + '<>movie'
 elif ii == 'tvshow' :
  i1Iii1i1I = re . compile ( '<showname>(.+?)</showname>' ) . findall ( item ) [ 0 ]
  VVeVevev = re . compile ( '<season>(.+?)</season>' ) . findall ( item ) [ 0 ]
  IiI111111IIII = re . compile ( '<episode>(.+?)</episode>' ) . findall ( item ) [ 0 ]
  i1Ii = re . compile ( '<showyear>(.+?)</showyear>' ) . findall ( item ) [ 0 ]
  ii111iI1iIi1 = re . compile ( '<episodeyear>(.+?)</episodeyear>' ) . findall ( item ) [ 0 ]
  eVeeVVVeVe = eVeeVVVeVe + '<>' + i1Iii1i1I + '<>' + VVeVevev + '<>' + IiI111111IIII + '<>' + i1Ii + '<>' + ii111iI1iIi1
  ii = "tvep"
 VVV ( name , eVeeVVVeVe , 19 , iconimage , 1 , ii , isFolder = True )
 if 68 - 68: Veeve + VVeVeeevevee
def I1I1I ( name , imdb , iconimage , fanart ) :
 IIi1IiiiI1Ii = ''
 VeVVevevev = name
 eVevVVeeevVV = Vevii1ii1ii ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eVevVVeeevVV )
 if 'movie' in imdb :
  imdb = imdb . split ( '<>' ) [ 0 ]
  i1Ii11i1i = [ ]
  eeveVVee = [ ]
  eVeevevVeveeeveveev = name . partition ( '(' )
  iiVVeeeeVevVe = eVeevevVeveeeveveev [ 0 ]
  iiVVeeeeVevVe = Vevii1ii1ii ( iiVVeeeeVevVe )
  VV = eVeevevVeveeeveveev [ 2 ] . partition ( ')' ) [ 0 ]
  iIiIIi1 = nanscrapers . scrape_movie ( iiVVeeeeVevVe , VV , imdb , timeout = 800 )
 else :
  i1Iii1i1I = imdb . split ( '<>' ) [ 1 ]
  I1IIII1i = imdb . split ( '<>' ) [ 0 ]
  VVeVevev = imdb . split ( '<>' ) [ 2 ]
  IiI111111IIII = imdb . split ( '<>' ) [ 3 ]
  i1Ii = imdb . split ( '<>' ) [ 4 ]
  ii111iI1iIi1 = imdb . split ( '<>' ) [ 5 ]
  iIiIIi1 = nanscrapers . scrape_episode ( i1Iii1i1I , i1Ii , ii111iI1iIi1 , VVeVevev , IiI111111IIII , I1IIII1i , None )
 I1I11i = 1
 for Ii1I1I1i1Ii in list ( iIiIIi1 ( ) ) :
  for i1 in Ii1I1I1i1Ii :
   if urlresolver . HostedMediaFile ( i1 [ 'url' ] ) . valid_url ( ) :
    IIi1IiiiI1Ii = VeeveVeveve ( i1 [ 'url' ] )
    name = "Link " + str ( I1I11i ) + ' | ' + i1 [ 'source' ] + IIi1IiiiI1Ii
    I1I11i = I1I11i + 1
    i11I1II1I11i ( name , i1 [ 'url' ] , 2 , iconimage , fanart , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
    if 61 - 61: VevVVe - eVVVeeveevV . I1ii / eVVVeeveevV + II1Iiii1111i
    if 5 - 5: iiiIi + iiiIi / Ii11111i * II1Iiii1111i - eVVVeeveevV % iiiIi
def IIII ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<adult>(.+?)</adult>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 36 , iconimage , fanart )
 if 15 - 15: i11iIiiIii % i11IiIiiIIIII . II1Iiii1111i + VVVevV
def VVevVVVVeeevVVV ( ) :
 iI1ii1Ii ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Top Viewed[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-viewed.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]HD[/COLOR][/B]' , Veeeeveveve + 'categories/hd-videos' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Most Commented[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-commented.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]50 Newest[/COLOR][/B]' , Veeeeveveve + 'last50.php' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Best of 2016[/COLOR][/B]' , Veeeeveveve + 'videos/top/year/2016' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]All-time Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/alltime-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Main Categories[/COLOR][/B]' , Veeeeveveve , 39 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]All Categories Alpha[/COLOR][/B]' , Veeeeveveve + 'categories' , 38 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Search[/COLOR][/B]' , 'url' , 40 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 27 - 27: iiiIi + Veeve
def eevVeevev ( url ) :
 iI = VevVevVeeeeve ( url )
 eVVeeevevVeveve = re . compile ( '<div class="video"><a href="(.+?)" class=".+?"><div class=".+?"  data-previewvideo=".+?"><img src=\'(.+?)\' class=\'.+?\' alt="(.+?)"/><img class=\'.+?\' src=\'.+?\'' , re . DOTALL ) . findall ( iI )
 for url , Veveveeeeeevev , VeveevVevevVeeveev in eVVeeevevVeveve :
  VeveevVevevVeeveev = VeveevVevevVeeveev . replace ( '&#039;' , '\'' ) . replace ( '&amp;' , ' & ' )
  VevVevevVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 41 , Veveveeeeeevev , eeeevVV , '' )
 eeeeeeevVeveveve = re . compile ( '<link rel="next" href="(.+?)"' , re . DOTALL ) . findall ( iI )
 for url in eeeeeeevVeveveve :
  VevVevevVe ( '[B][COLOR cyan]Next Page>>>[/COLOR][/B]' , url , 37 , 'http://i.imgur.com/Uqrznbf.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 64 - 64: VevVVe . eeveee - iI1I / VeeevVVeveVV
def VevVeveeVVV ( url ) :
 iI = VevVevVeeeeve ( url )
 eVVeeevevVeveve = re . compile ( '<div class="list">(.+?)<div class="head"' , re . DOTALL ) . findall ( iI ) [ 1 ]
 eVVeevVeveve = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( str ( eVVeeevevVeveve ) )
 for url in eVVeevVeveve :
  VeveevVevevVeeveev = url . split ( 'xhamster.com/' ) [ 1 ]
  try :
   VeveevVevevVeeveev = VeveevVevevVeeveev . replace ( '-1.html' , '' )
   VeveevVevevVeeveev = VeveevVevevVeeveev . split ( '/' ) [ 1 ] . title ( )
  except : pass
  if 'categories' not in VeveevVevevVeeveev :
   VevVevevVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 8 - 8: VVeevevev
def ii1111iII ( url ) :
 iI = VevVevVeeeeve ( url )
 eVVeeevevVeveve = re . compile ( 'ul class="alphabet-block".+?<a class=""(.+?)</ul>' , re . DOTALL ) . findall ( iI )
 eVVeevVeveve = re . compile ( 'href="(.+?)">(.+?)<' , re . DOTALL ) . findall ( str ( eVVeeevevVeveve ) )
 for url , VeveevVevevVeeveev in eVVeevVeveve :
  VevVevevVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 42 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 32 - 32: Ii / Veeve . II1Iiii1111i
def eeeVeevVVVeeev ( url ) :
 iI = VevVevVeeeeve ( url )
 eVVeeevevVeveve = re . compile ( '<div class="letter-categories">(.+?)</ul>' , re . DOTALL ) . findall ( iI )
 eVVeevVeveve = re . compile ( 'href="(.+?)"><span >(.+?)<' , re . DOTALL ) . findall ( str ( eVVeeevevVeveve ) )
 for url , VeveevVevevVeeveev in eVVeevVeveve :
  VevVevevVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 51 - 51: II1Iiii1111i / Veveevev . eVVVeeveevV * eeveee + VVeevevev * i1iIIi1
def VVVeVe ( ) :
 Veveveev = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 Veveveev . doModal ( )
 if ( Veveveev . isConfirmed ( ) ) :
  I11iII = Veveveev . getText ( ) . replace ( ' ' , '+' )
  VeI1Ii11I1Ii1i = Veeeeveveve + 'search.php?from=&q=' + I11iII + '&qcat=video'
  eevVeevev ( VeI1Ii11I1Ii1i )
  if 5 - 5: VevVVe
def VevVevVeeeeve ( url ) :
 iIiIi11iI = { }
 iIiIi11iI [ 'User-Agent' ] = IiIi11iIIi1Ii
 eeeeevevev = VeevV . get ( url , headers = iIiIi11iI ) . text
 eeeeevevev = eeeeevevev . encode ( 'ascii' , 'ignore' )
 return eeeeevevev
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 83 - 83: Veeve % II1Iiii1111i % iiiIi % VVVevV
def VeVevevevVevVe ( url ) :
 VeeveeveeeeevVev = [ ]
 VeeeeVVeeev = [ ]
 i1I1IiiIi1i = ''
 iI = VevVevVeeeeve ( url )
 eeveveVVeve = re . compile ( 'sources:(.+?)allowFullScreen:' , re . DOTALL ) . findall ( iI ) [ 0 ]
 iiI11ii1I1 = re . compile ( '"(.+?)":"(.+?)"' , re . DOTALL ) . findall ( str ( eeveveVVeve ) )
 for VeeevVVeVeVev , eeeeevevev in iiI11ii1I1 :
  i1I1IiiIi1i = '[B][COLOR cyan]%s[/COLOR][/B]' % VeeevVVeVeVev
  VeeveeveeeeevVev . append ( i1I1IiiIi1i )
  VeeeeVVeeev . append ( eeeeevevev )
 if len ( eeveveVVeve ) > 1 :
  eVeevVVeVev = xbmcgui . Dialog ( )
  II = eVeevVVeVev . select ( 'Please Select Quality' , VeeveeveeeeevVev )
  if II == - 1 :
   return
  elif II > - 1 :
   url = VeeeeVVeeev [ II ]
 else :
  url = re . compile ( 'sources: {".+?":"(.+?)"' ) . findall ( iI ) [ 0 ]
 url = url . replace ( '\/' , '/' )
 eevVeeveVeveVVevev = xbmcgui . ListItem ( VeveevVevevVeeveev , iconImage = 'DefaultVideo.png' , thumbnailImage = VevevVeveVVevevVevev )
 eevVeeveVeveVVevev . setInfo ( type = 'Video' , infoLabels = { "Title" : VeveevVevevVeeveev } )
 eevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
 eevVeeveVeveVVevev . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , eevVeeveVeveVVevev )
 if 92 - 92: VeeevVVeveVV * iI1I
def VevVevevVe ( name , url , mode , iconimage , fanart , description ) :
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 eevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 if mode == 41 :
  eevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
  I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = False )
 else :
  I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = True )
 return I1II1
 if 86 - 86: iiI1i1 / Veveevev . Veeve
 if 19 - 19: VVVevV % VeeevVVeveVV % i1iIIi1 * eeveee % Ii11111i
 if 67 - 67: VevVVe . Ii
def eeVVVevevVee ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<scraper>(.+?)</scraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 18 , iconimage , fanart )
 if 27 - 27: iiiIi % VevVVe
def eeveeeVVevev ( name , url , iconimage , fanart ) :
 iiIiii1IIIII = url
 if iiIiii1IIIII == 'latestmovies' :
  eeveve = 15
  IIIIiiIiiI = MOVIESINDEXER ( )
  IIIIiI11I11 = re . compile ( '<item>(.+?)</item>' ) . findall ( IIIIiiIiiI )
  for VVVevevV in IIIIiI11I11 :
   VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
   eeeveveev = len ( IIIIiI11I11 )
   for name , url , iconimage , fanart in VVeVVeveeeveeV :
    if '<meta>' in VVVevevV :
     i11II1I11I1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( VVVevevV ) [ 0 ]
     VVV ( name , url , eeveve , iconimage , eeeveveev , i11II1I11I1 , isFolder = False )
    else : i11I1II1I11i ( name , url , 15 , iconimage , fanart )
    if 67 - 67: VevVVe - eeveee / VVeVeeevevee - Ii
    if 1 - 1: Veeve
def VeveVeeveve ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( 'http://www.watchepisodes4.com' )
 iiIi11iI1iii = re . compile ( '<a title=".+?" .+? style="background-image: url(.+?)"></a>.+?<div class="hb-right">.+?<a title=".+?" href="(.+?)" class="episode">(.+?)</a>' , re . DOTALL ) . findall ( eeeeevevev )
 for iconimage , url , name in iiIi11iI1iii :
  iconimage = iconimage . replace ( "('" , "" ) . replace ( "')" , "" )
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  name = name . split ( '  ' ) [ 0 ]
  iI1ii1Ii ( name , url , 24 , iconimage , iconimage )
  if 67 - 67: Ii11111i / iI1I
def VVVeveveveveV ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( name , url , 31 , iconimage , iconimage )
  if 15 - 15: Veveevev % VevVVe * VVeVeeevevee
def VevVeeeVev ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( name , url , 31 , iconimage , iconimage )
  if 85 - 85: VVeVeeevevee
def iI1i11II1i ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 iIi1I11I = re . compile ( '<div class="std-cts">.+?<div class="sdt-content tnContent">.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( eeeeevevev ) [ 0 ] . replace ( ' Episodes' , '' ) . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
 eeveveVVeve = re . compile ( '<a title=".+?" href="(.+?)">.+?<div class="season">(.+?) </div>.+?<div class="episode">(.+?)</div>.+?<div class="e-name">(.+?)</div>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , VVeVevev , IiI111111IIII , Iii1 in eeveveVVeve :
  Iii1 = Iii1 . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  if '</div>' in name : name = 'TBA'
  iI1ii1Ii ( '%s ' % iIi1I11I + '(%s ' % VVeVevev + '%s)' % IiI111111IIII , url , 24 , iconimage , iconimage )
  if 58 - 58: VevVVe . IiiIII111ii + Veveevev
def VevevVV ( name , url , iconimage , fanart ) :
 VeVVevevev = name
 eeeeevevev = eeveevVeVeevVevVV ( url )
 I1I1 = re . compile ( '<a target="_blank" href=".+?" data-episodeid=".+?" data-linkid=".+?" data-hostname=".+?" class="watch-button" data-actuallink="(.+?)">Watch Now!</a>' ) . findall ( eeeeevevev )
 I1I11i = 1
 i1Ii11i1i = [ ]
 eeveVVee = [ ]
 for VeVevVeveeveVVV in I1I1 :
  IIi1IiiiI1Ii = VeeveVeveve ( VeVevVeveeveVVV )
  if 'http' in VeVevVeveeveVVV : VVeVeVe = VeVevVeveeveVVV . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : VVeVeVe = VeVevVeveeveVVV
  name = "Link " + str ( I1I11i ) + ' | ' + VVeVeVe + IIi1IiiiI1Ii
  if VVeVeVe != 'www' :
   i11I1II1I11i ( VVeVeVe , VeVevVeveeveVVV , 2 , iconimage , fanart , description = '' )
   if 98 - 98: IiiIII111ii
def VeeeeVeveVVVV ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 iiIi11iI1iii = re . compile ( '<td height="20">(.+?)</td>.+?<td>(.+?)</td>.+?<td><a href=".+?">(.+?)</a></td>.+?<td><a href=".+?">(.+?)</a></td>.+?</tr>' , re . DOTALL ) . findall ( eeeeevevev )
 for eevVeveveVVee , name , i1I1iIi , time in iiIi11iI1iii :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( '[COLOR yellow]%s[/COLOR] - ' % i1I1iIi + '[COLOR yellow]%s[/COLOR] ' % name + '- [COLOR white]%s[/COLOR]' % eevVeveveVVee , url , 28 , iconimage , fanart )
  if 22 - 22: Veveevev * Ii11111i . i1iIIi1 * i11iIiiIii - VevVVe * iiiIi
def VVeeeevVeveev ( url ) :
 II1iI1I11I = ''
 eevVVev = xbmc . Keyboard ( II1iI1I11I , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 eevVVev . doModal ( )
 if eevVVev . isConfirmed ( ) :
  II1iI1I11I = eevVVev . getText ( ) . replace ( ' ' , '+' ) . replace ( '+and+' , '+%26+' )
 if len ( II1iI1I11I ) > 1 :
  url = 'http://www.watchepisodes4.com/search/ajax_search?q=' + II1iI1I11I
  eeeeevevev = eeveevVeVeevVevVV ( url )
  VVeVVeveeeveeV = json . loads ( eeeeevevev )
  VVeVVeveeeveeV = VVeVVeveeeveeV [ 'series' ]
  for VVVevevV in VVeVVeveeeveeV :
   VeveevVevevVeeveev = VVVevevV [ 'value' ]
   IiI11ii1I = VVVevevV [ 'seo' ]
   url = 'http://www.watchepisodes4.com/' + IiI11ii1I
   VevevVeveVVevevVevev = 'http://www.watchepisodes4.com/movie_images/' + IiI11ii1I + '.jpg'
   iI1ii1Ii ( VeveevVevevVeeveev , url , 31 , VevevVeveVVevevVevev , eeeevVV )
  II1iI1I11I = II1iI1I11I [ : - 1 ]
  eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/anewEvolvemenu/search.xml' )
  eee = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeeevevev )
  for url in eee :
   try :
    eeeeevevev = iIIIi1 ( url )
    iiI = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
    for VVVevevV in iiI :
     eeveveVVeve = re . compile ( '<title>(.+?)</title>' ) . findall ( VVVevevV )
     for VeVVevevev in eeveveVVeve :
      VeVVevevev = Vevii1ii1ii ( VeVVevevev . upper ( ) )
      II1iI1I11I = II1iI1I11I . upper ( )
      if II1iI1I11I in VeVVevevev :
       eeeveVe ( VeveevVevevVeeveev , url , VevevVeveVVevevVevev , eeeevVV , VVVevevV )
   except : pass
   if 56 - 56: II1Iiii1111i . VVVevV . VevVVe
   if 39 - 39: Ii11111i + iI1I
def VeVeeVeV ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 iiIi11iI1iii = re . compile ( '<h2 id=".+?">(.+?)</h2>.+?<p><span class="article__image article__image--undefined"><img src="(.+?)" alt=".+?"></span> </p>.+?<p><strong>(.+?)</strong>(.+?)<' , re . DOTALL ) . findall ( eeeeevevev )
 for VeVVevevev , iconimage , iiIiii1iI1i , i1I1iIi in iiIi11iI1iii :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( '[COLOR yellow]%s [/COLOR] ' % VeVVevevev + '[COLOR yellow]%s[/COLOR]' % iiIiii1iI1i + '[COLOR white]%s[/COLOR]' % i1I1iIi , url , 35 , iconimage , fanart )
def I1ii1ii11i1I ( name , url , iconimage , fanart ) :
 eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/Menus/Movies/EvolveLatest/mainmenu.xml' )
 iiIi11iI1iii = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in iiIi11iI1iii :
  eeeveVe ( name , url , iconimage , fanart , VVVevevV )
  if 58 - 58: IiiIII111ii + II1Iiii1111i
  if 12 - 12: eeveee - VVVevV % Veveevev * VVeVeeevevee
  if 44 - 44: IiiIII111ii % i11IiIiiIIIII
  if 41 - 41: Ii - VVeVeeevevee - i11IiIiiIIIII
  if 8 - 8: VVeevevev + iI1I - eeveee % II1Iiii1111i % eeveee * I1ii
def IIIi11I11 ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 44 - 44: Veeve
def VVVVevVVV ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 3 - 3: VVeevevev
def eeeVeVVVeveeeve ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="thumb">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image"' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 85 - 85: VeeevVVeveVV % Ii * VeeevVVeveVV / VVVevV
def eeVVeV ( name , url , iconimage , fanarts ) :
 i1Ii11i1i = [ ]
 eeveVVee = [ ]
 I1i11i = [ ]
 eeeeevevev = eeveevVeVeevVevVV ( url )
 I1I1 = re . compile ( '<a href="(.+?)" title=".+?" rel="nofollow" target="blank">.+?</a><br/>' ) . findall ( eeeeevevev )
 I1I11i = 1
 i1Ii11i1i = [ ]
 eeveVVee = [ ]
 for VeVevVeveeveVVV in I1I1 :
  IIi1IiiiI1Ii = VeeveVeveve ( VeVevVeveeveVVV )
  if '//' in VeVevVeveeveVVV : VVeVeVe = VeVevVeveeveVVV . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : VVeVeVe = VeVevVeveeveVVV
  name = "Link " + str ( I1I11i ) + ' | ' + VVeVeVe + IIi1IiiiI1Ii
  if VVeVeVe != 'www' :
   i11I1II1I11i ( VVeVeVe , VeVevVeveeveVVV , 2 , iconimage , eeeevVV , description = '' )
   if 11 - 11: VevVVe / Veeve + eeveee * VVVevV - VVVevV - VevVVe
   if 85 - 85: VVeVeeevevee % I1ii / iiI1i1 . iiI1i1
def IiIIIi1iIi ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<lbscraper>(.+?)</lbscraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 10 , iconimage , fanart )
 if 31 - 31: eeveee % VVeevevev
def iI1IVeeVeVe ( name , url , iconimage , fanart ) :
 iIiIIi1 = III1I1Iii1iiI ( name , url , iconimage )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( iIiIIi1 )
 for VVVevevV in eeveveVVeve :
  eeeveVe ( name , url , iconimage , fanart , VVVevevV )
  if 17 - 17: i11IiIiiIIIII % iiI1i1 - iiI1i1
def III1I1Iii1iiI ( name , url , iconimage ) :
 iiIiii1IIIII = url
 string = ''
 if url == 'mamahd' :
  eeeeevevev = eeveeeeVeveevV ( "http://mamahd.com" ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
  VeveevVev = re . compile ( '<a href="(.+?)">.+?<img src="(.+?)"></div>.+?<div class="home cell">.+?<span>(.+?)</span>.+?<span>(.+?)</span>.+?</a>' ) . findall ( eeeeevevev )
  for url , iconimage , Ii1II1I11i1 , eVeeeeeVeV in VeveevVev :
   string = string + '<item>\n<title>%s vs %s</title>\n<sportsdevil>%s</sportsdevil>\n<thumbnail>%s</thumbnail>\n<fanart>fanart</fanart>\n</item>\n\n' % ( Ii1II1I11i1 , eVeeeeeVeV , url , iconimage )
  return string
  if 33 - 33: Veeve / iiiIi * Ii11111i % i11IiIiiIIIII * iI1I
 elif url == 'cricfree' :
  eeeeevevev = eeveeeeVeveevV ( "http://cricfree.sc/football-live-stream" )
  Veve = re . compile ( '<td><span class="sport-icon(.+?)</tr>' , re . DOTALL ) . findall ( eeeeevevev )
  for VevVVeVVVeveV in Veve :
   I1ii11 = re . compile ( '<td>(.+?)<br(.+?)</td>' ) . findall ( VevVVeVVVeveV )
   for eVeVeVeeev , i1I1iIi in I1ii11 :
    eVeVeVeeev = '[COLOR yellow]' + eVeVeVeeev + '[/COLOR]'
    i1I1iIi = i1I1iIi . replace ( '>' , '' )
   time = re . compile ( '<td class="matchtime" style="color:#545454;font-weight:bold;font-size: 9px">(.+?)</td>' ) . findall ( VevVVeVVVeveV ) [ 0 ]
   time = '[COLOR white](' + time + ')[/COLOR]'
   III1ii1I = re . compile ( '<a style="text-decoration:none !important;color:#545454;" href="(.+?)" target="_blank">(.+?)</a></td>' ) . findall ( VevVVeVVVeveV )
   for url , Ii1i1iI in III1ii1I :
    url = url
    Ii1i1iI = Ii1i1iI
   string = string + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( eVeVeVeeev + ' ' + time + ' - ' + Ii1i1iI , url )
   string = string + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return string
  if 16 - 16: eVVVeeveevV / II1Iiii1111i / VeeevVVeveVV * VevVVe + Ii % eVVVeeveevV
 elif url == 'bigsports' :
  eeeeevevev = eeveeeeVeveevV ( "http://www.bigsports.me/cat/4/football-live-stream.html" )
  VeveevVev = re . compile ( '<td>.+?<td>(.+?)\-(.+?)\-(.+?)</td>.+?<td>(.+?)\:(.+?)</td>.+?<td>Football</td>.+?<td><strong>(.+?)</strong></td>.+?<a target=.+? href=(.+?) class=.+?' , re . DOTALL ) . findall ( eeeeevevev )
  for eVeVeVeeev , eeeeveevev , eeV , eeveevev , IIi , name , url in VeveevVev :
   if not '</td>' in eVeVeVeeev :
    url = url . replace ( '"' , '' )
    i1I1iIi = eVeVeVeeev + ' ' + eeeeveevev + ' ' + eeV
    time = eeveevev + ':' + IIi
    i1I1iIi = '[COLOR yellow]' + i1I1iIi + '[/COLOR]'
    time = '[COLOR cyan](' + time + ')[/COLOR]'
    string = string + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( i1I1iIi + ' ' + time + ' ' + name , url )
    string = string + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return string
  if 66 - 66: I1ii % VVeevevev . eVVVeeveevV
def II1I ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 eevVIiiiI = re . compile ( '<oktitle>(.+?)</oktitle>' ) . findall ( item ) [ 0 ]
 VevevVeVVeveeev = re . compile ( '<line1>(.+?)</line1>' ) . findall ( item ) [ 0 ]
 eVV = re . compile ( '<line2>(.+?)</line2>' ) . findall ( item ) [ 0 ]
 VeveevVVeveveveveee = re . compile ( '<line3>(.+?)</line3>' ) . findall ( item ) [ 0 ]
 iIIII1iIIii = '##' + eevVIiiiI + '#' + VevevVeVVeveeev + '#' + eVV + '#' + VeveevVVeveveveveee + '##'
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 IIi1I11I1II ( name , iIIII1iIIii , 17 , iconimage , fanart )
 if 52 - 52: eeveee % II1Iiii1111i
def VeeveveveeVVV ( name , url ) :
 Ii11i1I11i = re . compile ( '##(.+?)##' ) . findall ( url ) [ 0 ] . split ( '#' )
 eVeevVVeVev = xbmcgui . Dialog ( )
 eVeevVVeVev . ok ( Ii11i1I11i [ 0 ] , Ii11i1I11i [ 1 ] , Ii11i1I11i [ 2 ] , Ii11i1I11i [ 3 ] )
 if 13 - 13: i1iIIi1 / i11iIiiIii % Veeve % VVeVeeevevee . VVVevV
def eeVVeeeeee ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<redirect>(.+?)</redirect>' ) . findall ( item ) [ 0 ]
 iiIii ( 'name' , url , 'iconimage' , 'fanart' )
 if 8 - 8: Veveevev + II1Iiii1111i - Veeve
def eeevVVe ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iIIII1iIIii = re . compile ( '<text>(.+?)</text>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 IIi1I11I1II ( name , iIIII1iIIii , 9 , iconimage , fanart )
 if 11 - 11: Ii % i11iIiiIii - Ii * Veveevev
def i1I11IiI1iiII ( name , url ) :
 eeveveVeeveVee = eeveevVeVeevVevVV ( url )
 eVVVeveeveve ( name , eeveveVeeveVee )
 if 1 - 1: VevVVe / i1iIIi1 * iiiIi
def VevevevVVeevevee ( name , url , iconimage , fanart , item ) :
 I1iIiIi11i11 = re . compile ( '<image>(.+?)</image>' ) . findall ( item )
 if len ( I1iIiIi11i11 ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  Veveeeev = re . compile ( '<image>(.+?)</image>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  IIi1I11I1II ( name , Veveeeev , 7 , iconimage , fanart )
 elif len ( I1iIiIi11i11 ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  I1iii11 = ''
  for Veveeeev in I1iIiIi11i11 : I1iii11 = I1iii11 + '<image>' + Veveeeev + '</image>'
  Ii1iI = eeVe
  name = Vevii1ii1ii ( name )
  eeeevViII1iii = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( eeeevViII1iii ) : file ( eeeevViII1iii , 'w' ) . close ( )
  i11i1iiiII = open ( eeeevViII1iii , "w" )
  i11i1iiiII . write ( I1iii11 )
  i11i1iiiII . close ( )
  IIi1I11I1II ( name , 'image' , 8 , iconimage , fanart )
  if 68 - 68: i11iIiiIii * VVeevevev
def VevevVVVeVeeevV ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<iptv>(.+?)</iptv>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 6 , iconimage , fanart )
 if 46 - 46: Veveevev / iiI1i1 % IiiIII111ii . iiI1i1 * IiiIII111ii
def IIi1ii1Ii ( url , iconimage ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 VeVeV = re . compile ( '^#.+?:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( eeeeevevev )
 eevii1i = [ ]
 for eVVee , VeveevVevevVeeveev , url in VeVeV :
  iII1111III1I = { "params" : eVVee , "name" : VeveevVevevVeeveev , "url" : url }
  eevii1i . append ( iII1111III1I )
 list = [ ]
 for eevVeveveVVee in eevii1i :
  iII1111III1I = { "name" : eevVeveveVVee [ "name" ] , "url" : eevVeveveVVee [ "url" ] }
  VeVeV = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( eevVeveveVVee [ "params" ] )
  for ii11i , VeveveVeeveveeve in VeVeV :
   iII1111III1I [ ii11i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = VeveveVeeveveeve . strip ( )
  list . append ( iII1111III1I )
 for eevVeveveVVee in list :
  if '.ts' in eevVeveveVVee [ "url" ] : IIi1I11I1II ( eevVeveveVVee [ "name" ] , eevVeveveVVee [ "url" ] , 2 , iconimage , eeeevVV )
  else : i11I1II1I11i ( eevVeveveVVee [ "name" ] , eevVeveveVVee [ "url" ] , 2 , iconimage , eeeevVV )
  if 85 - 85: IiiIII111ii + VeeevVVeveVV * IiiIII111ii - iI1I % i11iIiiIii
def iiIiI ( name , url , iconimage , fanart , item ) :
 IIi1IiiiI1Ii = ''
 VVeevevVeV = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , iIi1 , iconimage , fanart in VVeVVeveeeveeV :
  if 'youtube.com/playlist?' in iIi1 :
   II1iI1I11I = iIi1 . split ( 'list=' ) [ 1 ]
   iI1ii1Ii ( name , iIi1 , i11iiI1111 , iconimage , fanart , description = II1iI1I11I )
 if len ( VVeevevVeV ) == 1 :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
  for name , url , iconimage , fanart in VVeVVeveeeveeV :
   try :
    IIi1IiiiI1Ii = VeeveVeveve ( url )
    eVeeeeevevevVeevev = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
    if 'SportsDevil' in url : eVeeeeevevevVeevev = ''
   except : pass
   if '.ts' in url : i11I1II1I11i ( name , url , 16 , iconimage , fanart , description = '' )
   if '<meta>' in item :
    i11II1I11I1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
    VVV ( name + IIi1IiiiI1Ii , url , 2 , iconimage , 10 , i11II1I11I1 , isFolder = False )
   else :
    i11I1II1I11i ( name + IIi1IiiiI1Ii , url , 2 , iconimage , fanart )
 elif len ( VVeevevVeV ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  if '.ts' in url : i11I1II1I11i ( name , url , 16 , iconimage , fanart , description = '' )
  if '<meta>' in item :
   i11II1I11I1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
   VVV ( name , url , 3 , iconimage , len ( VVeevevVeV ) , i11II1I11I1 , isFolder = True )
  else :
   iI1ii1Ii ( name , url , 3 , iconimage , fanart )
   if 93 - 93: VVVevV / VevVVe / iiI1i1 % iI1I % iI1I
   if 40 - 40: i11iIiiIii * iI1I - Ii * iI1I - VVeVeeevevee . Ii
def VVeV ( name , url , iconimage , fanart , item ) :
 VVeevevVeV = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item )
 eeevVevVeeeeee = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 if len ( VVeevevVeV ) + len ( eeevVevVeeeeee ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item ) [ 0 ]
  url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url
  IIi1I11I1II ( name , url , 16 , iconimage , fanart )
 elif len ( VVeevevVeV ) + len ( eeevVevVeeeeee ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  iI1ii1Ii ( name , url , 3 , iconimage , fanart )
  if 39 - 39: i1iIIi1 * II1Iiii1111i + iiI1i1 - i1iIIi1 + eVVVeeveevV
def eVVeev ( link ) :
 if eVeveveVe == '' :
  eVeevVVeVev = xbmcgui . Dialog ( )
  II = eVeevVVeVev . yesno ( 'Adult Content' , 'You have found the goodies ;)' , '' , 'Please set a password to prevent accidental access' , 'Cancel' , 'OK' )
  if II == 1 :
   Veveveev = xbmc . Keyboard ( '' , 'Set Password' )
   Veveveev . doModal ( )
   if ( Veveveev . isConfirmed ( ) ) :
    eeviiiI1I1iIIIi1 = Veveveev . getText ( )
    VevVevVVevVevVev . setSetting ( 'password' , eeviiiI1I1iIIIi1 )
  else : quit ( )
 elif eVeveveVe <> '' :
  eVeevVVeVev = xbmcgui . Dialog ( )
  II = eVeevVVeVev . yesno ( 'Adult Content' , 'Please enter the password you set!' , 'to continue' , 'dirty git' , 'Cancel' , 'OK' )
  if II == 1 :
   Veveveev = xbmc . Keyboard ( '' , 'Enter Password' )
   Veveveev . doModal ( )
   if ( Veveveev . isConfirmed ( ) ) :
    eeviiiI1I1iIIIi1 = Veveveev . getText ( )
   if eeviiiI1I1iIIIi1 <> eVeveveVe :
    quit ( )
  else : quit ( )
  if 17 - 17: iiI1i1 . VeeevVVeveVV / VVeVeeevevee % Veeve % Ii / i11iIiiIii
def VVVIiiiii1iI ( name , url , iconimage ) :
 IIieeVeeeev = ''
 eVevVVeeevVV = Vevii1ii1ii ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eVevVVeeevVV )
 eeeeevevev = iIIIi1 ( url )
 eVevVVev = re . compile ( '<title>.*?' + re . escape ( name ) + '.*?</title>(.+?)</item>' , re . DOTALL ) . findall ( eeeeevevev ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( eVevVVev ) [ 0 ]
 VVeevevVeV = [ ]
 if '<link>' in eVevVVev :
  eevVevVeevev = re . compile ( '<link>(.+?)</link>' ) . findall ( eVevVVev )
  for VevVeeveeveveveV in eevVevVeevev :
   VVeevevVeV . append ( VevVeeveeveveveV )
 if '<sportsdevil>' in eVevVVev :
  eVeveeveveVVeeVev = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( eVevVVev )
  for VVVeVevevev in eVeveeveveVVeeVev :
   VVVeVevevev = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + VVVeVevevev
   VVeevevVeV . append ( VVVeVevevev )
 I1I11i = 1
 for eeeeevevev in VVeevevVeV :
  if '(' in eeeeevevev :
   eeeeevevev = eeeeevevev . split ( '(' )
   IIieeVeeeev = eeeeevevev [ 1 ] . replace ( ')' , '' )
   eeeeevevev = eeeeevevev [ 0 ]
  IIi1IiiiI1Ii = VeeveVeveve ( eeeeevevev )
  eVeeeeevevevVeevev = eeeeevevev . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  if IIieeVeeeev <> '' : name = "Link " + str ( I1I11i ) + ' | ' + IIieeVeeeev + IIi1IiiiI1Ii
  else : name = "Link " + str ( I1I11i ) + ' | ' + eVeeeeevevevVeevev + IIi1IiiiI1Ii
  I1I11i = I1I11i + 1
  VVV ( name , eeeeevevev , 2 , iconimage , 10 , '' , isFolder = False , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
  if 57 - 57: Veeve
def ii1ii11IIIiiI ( name , url , iconimage , fanart , item ) :
 VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , url , iconimage , fanart in VVeVVeveeeveeV :
  if 'youtube.com/channel/' in url :
   II1iI1I11I = url . split ( 'channel/' ) [ 1 ]
   iI1ii1Ii ( name , url , i11iiI1111 , iconimage , fanart , description = II1iI1I11I )
  elif 'youtube.com/user/' in url :
   II1iI1I11I = url . split ( 'user/' ) [ 1 ]
   iI1ii1Ii ( name , url , i11iiI1111 , iconimage , fanart , description = II1iI1I11I )
  elif 'youtube.com/playlist?' in url :
   II1iI1I11I = url . split ( 'list=' ) [ 1 ]
   iI1ii1Ii ( name , url , i11iiI1111 , iconimage , fanart , description = II1iI1I11I )
  elif 'plugin://' in url :
   eVVVee = HTMLParser ( )
   url = eVVVee . unescape ( url )
   iI1ii1Ii ( name , url , i11iiI1111 , iconimage , fanart )
  else :
   iI1ii1Ii ( name , url , 1 , iconimage , fanart )
   if 15 - 15: i11iIiiIii % VevVVe * VVeVeeevevee / iI1I
def eeeVeveeveevVev ( ) :
 Veveveev = xbmc . Keyboard ( '' , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 Veveveev . doModal ( )
 if ( Veveveev . isConfirmed ( ) ) :
  II1iI1I11I = Veveveev . getText ( )
  II1iI1I11I = II1iI1I11I . upper ( )
 else : quit ( )
 eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/Menus/anewEvolvemenu/search.xml' )
 eee = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeeevevev )
 for VeI1Ii11I1Ii1i in eee :
  try :
   eeeeevevev = iIIIi1 ( VeI1Ii11I1Ii1i )
   iiI = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
   for VVVevevV in iiI :
    eeveveVVeve = re . compile ( '<title>(.+?)</title>' ) . findall ( VVVevevV )
    for VeVVevevev in eeveveVVeve :
     VeVVevevev = VeVVevevev . upper ( )
     if II1iI1I11I in VeVVevevev :
      eeeveVe ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV , VVVevevV )
  except : pass
  if 27 - 27: VeeevVVeveVV - IiiIII111ii / VVeVeeevevee
def VVeeVeeveveeev ( url ) :
 string = "ShowPicture(%s)" % url
 xbmc . executebuiltin ( string )
 if 84 - 84: iI1I + VVeVeeevevee
def IIiiIIi1 ( name , url , iconimage , description ) :
 if description : name = description
 try :
  if 'plugin://plugin.video.SportsDevil/' in url :
   eevev ( name , url , iconimage )
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
   url = url . replace ( '|' , '' )
   eevev ( name , url , iconimage )
  elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   eeVevevV ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   eeVevevV ( name , url , iconimage )
  else : eeVevevV ( name , url , iconimage )
 except :
  eeeveveevVe ( eVVVVeVevevVeVV ( 'Picasso' ) , 'Stream Unavailable' , '3000' , Veveveeeeeevev )
  if 85 - 85: I1ii - iiI1i1 / Ii11111i
def i1I1ii ( url ) :
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 xbmc . Player ( ) . play ( url )
 if 99 - 99: Veeve * i1iIIi1 % iiI1i1 / i11IiIiiIIIII
def eeVevevV ( name , url , iconimage ) :
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = eevVeeveVeveVVevev )
 eevVeeveVeveVVevev . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , eevVeeveVeveVVevev )
 if 90 - 90: I1ii % eVVVeeveevV - eVVVeeveevV % Veeve * VVeevevev
def eevev ( name , url , iconimage ) :
 xbmc . executebuiltin ( 'Dialog.Close(all,True)' )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage ) ; eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = eevVeeveVeveVVevev )
 xbmc . Player ( ) . play ( url , eevVeeveVeveVVevev , False )
 if 39 - 39: VVeVeeevevee
def eeVevevevVevevev ( url ) :
 xbmc . executebuiltin ( "PlayMedia(%s)" % url )
 if 19 - 19: iiI1i1
def iIIIi1 ( url ) :
 Ii1IiI1i1ii = urllib2 . Request ( url )
 Ii1IiI1i1ii . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'aWhqdXJoeWRkZ3N0YWdhazk0aGZ5ZHM=' ) )
 I1I1i1I = urllib2 . urlopen ( Ii1IiI1i1ii )
 eeeeevevev = I1I1i1I . read ( )
 I1I1i1I . close ( )
 eeeeevevev = eeeeevevev . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 if '{' in eeeeevevev :
  string = eeeeevevev [ : : - 1 ]
  string = string . replace ( '}' , '' ) . replace ( '{' , '' ) . replace ( ',' , '' ) . replace ( ']' , '' ) . replace ( '[' , '' )
  string = string + '=='
  eeeeevevev = string . decode ( 'base64' )
 if url <> IiI : eeeeevevev = eeeeevevev . replace ( '\n' , '' ) . replace ( '\r' , '' )
 print eeeeevevev
 return eeeeevevev
 if 87 - 87: Ii11111i / iiI1i1 * Ii
def eeveevVeVeevVevVV ( url ) :
 Ii1IiI1i1ii = urllib2 . Request ( url )
 Ii1IiI1i1ii . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'aWhqdXJoeWRkZ3N0YWdhazk0aGZ5ZHM=' ) )
 I1I1i1I = urllib2 . urlopen ( Ii1IiI1i1ii )
 eeeeevevev = I1I1i1I . read ( )
 I1I1i1I . close ( )
 return eeeeevevev
 if 41 - 41: Veveevev * VVeVeeevevee / Veveevev % I1ii
def eeveeeeVeveevV ( url ) :
 Ii1IiI1i1ii = urllib2 . Request ( url )
 Ii1IiI1i1ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 I1I1i1I = urllib2 . urlopen ( Ii1IiI1i1ii )
 eeeeevevev = I1I1i1I . read ( )
 I1I1i1I . close ( )
 eeeeevevev = eeeeevevev . replace ( '\n' , '' ) . replace ( '\r' , '' )
 return eeeeevevev
 if 18 - 18: Veeve . VeeevVVeveVV % Veveevev % i11IiIiiIIIII
 if 9 - 9: VVeevevev - II1Iiii1111i * VeeevVVeveVV . II1Iiii1111i
def ii1Ii1IiIIi ( ) :
 iiii ( )
 eevVVeveVeevevVeeveevVe = [ ]
 I1I1Vev = sys . argv [ 2 ]
 if len ( I1I1Vev ) >= 2 :
  eVVee = sys . argv [ 2 ]
  iIi1IiII = eVVee . replace ( '?' , '' )
  if ( eVVee [ len ( eVVee ) - 1 ] == '/' ) :
   eVVee = eVVee [ 0 : len ( eVVee ) - 2 ]
  I1i = iIi1IiII . split ( '&' )
  eevVVeveVeevevVeeveevVe = { }
  for I1I11i in range ( len ( I1i ) ) :
   eeeii1iiIi1 = { }
   eeeii1iiIi1 = I1i [ I1I11i ] . split ( '=' )
   if ( len ( eeeii1iiIi1 ) ) == 2 :
    eevVVeveVeevevVeeveevVe [ eeeii1iiIi1 [ 0 ] ] = eeeii1iiIi1 [ 1 ]
 return eevVVeveVeevevVeeveevVe
 if 34 - 34: eVVVeeveevV
def eeeveveevVe ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 91 - 91: iiI1i1 % eeveee . iiI1i1 % Ii / Veeve * Veveevev
def Vevii1ii1ii ( string ) :
 iieeeveevVeVVV = re . compile ( '(\[.+?\])' ) . findall ( string )
 for eeVeveVevevVeve in iieeeveevVeVVV : string = string . replace ( eeVeveVevevVeve , '' )
 return string
 if 70 - 70: iI1I
def eVVVVeVevevVeVV ( string ) :
 string = string . split ( ' ' )
 i11iIIi11 = ''
 for eeVeeeevevevVVevev in string :
  IiIiI1I1I1 = '[B][COLOR yellow]' + eeVeeeevevevVVevev [ 0 ] . upper ( ) + '[/COLOR][COLOR white]' + eeVeeeevevevVVevev [ 1 : ] + '[/COLOR][/B] '
  i11iIIi11 = i11iIIi11 + IiIiI1I1I1
 return i11iIIi11
 if 6 - 6: IiiIII111ii . i1iIIi1 * Veveevev . Ii
def VVV ( name , url , mode , iconimage , itemcount , metatype , isFolder = False , description = '' ) :
 if isFolder == True : VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 else : VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 if VVVeev == 'true' :
  eVVe = name
  name = Vevii1ii1ii ( name )
  I1IiIIi = ""
  IiVVeevev = ""
  iIII = [ ]
  Ii1iI11iI1 = eval ( base64 . b64decode ( 'bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ==' ) )
  eevVVVVevevVevVe = { }
  if metatype == 'movie' :
   eVeevevVeveeeveveev = name . partition ( '(' )
   if len ( eVeevevVeveeeveveev ) > 0 :
    I1IiIIi = eVeevevVeveeeveveev [ 0 ]
    IiVVeevev = eVeevevVeveeeveveev [ 2 ] . partition ( ')' )
   if len ( IiVVeevev ) > 0 :
    IiVVeevev = IiVVeevev [ 0 ]
   eevVVVVevevVevVe = Ii1iI11iI1 . get_meta ( 'movie' , name = I1IiIIi , year = IiVVeevev )
   if not eevVVVVevevVevVe [ 'trailer' ] == '' : iIII . append ( ( eVVVVeVevevVeVV ( 'Play Trailer' ) , 'XBMC.RunPlugin(%s)' % VeevVee . build_plugin_url ( { 'mode' : 11 , 'url' : eevVVVVevevVevVe [ 'trailer' ] } ) ) )
  elif metatype == 'tvep' :
   VeVVevevev = VevVevVVevVevVev . getSetting ( 'tv' )
   if '<>' in url :
    print url
    I1IIII1i = url . split ( '<>' ) [ 0 ]
    i1Iii1i1I = url . split ( '<>' ) [ 1 ]
    VVeVevev = url . split ( '<>' ) [ 2 ]
    IiI111111IIII = url . split ( '<>' ) [ 3 ]
    i1Ii = url . split ( '<>' ) [ 4 ]
    ii111iI1iIi1 = url . split ( '<>' ) [ 5 ]
    eevVVVVevevVevVe = Ii1iI11iI1 . get_episode_meta ( i1Iii1i1I , imdb_id = I1IIII1i , season = VVeVevev , episode = IiI111111IIII , air_date = '' , episode_title = '' , overlay = '' )
   else :
    i11 = re . compile ( 'Season (.+?) Episode (.+?)\)' ) . findall ( name )
    for I1II , VVev in i11 :
     eevVVVVevevVevVe = Ii1iI11iI1 . get_episode_meta ( VeVVevevev , imdb_id = '' , season = I1II , episode = VVev , air_date = '' , episode_title = '' , overlay = '' )
  try :
   if eevVVVVevevVevVe [ 'cover_url' ] == '' : iconimage = iconimage
   else : iconimage = eevVVVVevevVevVe [ 'cover_url' ]
  except : pass
  eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( eeeevVV ) + "&iconimage=" + urllib . quote_plus ( iconimage )
  I1II1 = True
  eevVeeveVeveVVevev = xbmcgui . ListItem ( eVVe , iconImage = iconimage , thumbnailImage = iconimage )
  eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = eevVVVVevevVevVe )
  eevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
  eevVeeveVeveVVevev . addContextMenuItems ( iIII , replaceItems = False )
  if not eevVVVVevevVevVe . get ( 'backdrop_url' , '' ) == '' : eevVeeveVeveVVevev . setProperty ( 'fanart_image' , eevVVVVevevVevVe [ 'backdrop_url' ] )
  else : eevVeeveVeveVVevev . setProperty ( 'fanart_image' , eeeevVV )
  VVVeveVVeevevV = VevVevVVevVevVev . getSetting ( 'favlist' )
  VVeveIII111i11IiI = [ ]
  VVeveIII111i11IiI . append ( ( eVVVVeVevevVeVV ( 'Stream Information' ) , 'XBMC.Action(Info)' ) )
  if VVVeveVVeevevV == 'yes' : VVeveIII111i11IiI . append ( ( '[COLOR cyan]Remove From Keep Safe? [/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  else : VVeveIII111i11IiI . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  eevVeeveVeveVVevev . addContextMenuItems ( VVeveIII111i11IiI , replaceItems = False )
  I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = isFolder , totalItems = itemcount )
  return I1II1
 else :
  if isFolder :
   iI1ii1Ii ( name , url , mode , iconimage , eeeevVV , description = '' )
  else :
   i11I1II1I11i ( name , url , mode , iconimage , eeeevVV , description = '' )
   if 71 - 71: VVeVeeevevee / VVeVeeevevee * I1ii * I1ii / Veeve
def iI1ii1Ii ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 eevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 if 'youtube.com/channel/' in url :
  eeveveveveV = 'plugin://plugin.video.youtube/channel/' + description + '/'
 if 'youtube.com/user/' in url :
  eeveveveveV = 'plugin://plugin.video.youtube/user/' + description + '/'
 if 'youtube.com/playlist?' in url :
  eeveveveveV = 'plugin://plugin.video.youtube/playlist/' + description + '/'
 if 'plugin://' in url :
  eeveveveveV = url
 VVeveIII111i11IiI = [ ]
 VVVeveVVeevevV = VevVevVVevVevVev . getSetting ( 'favlist' )
 if VVVeveVVeevevV == 'yes' : VVeveIII111i11IiI . append ( ( '[COLOR cyan]Remove From Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : VVeveIII111i11IiI . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 eevVeeveVeveVVevev . addContextMenuItems ( VVeveIII111i11IiI , replaceItems = False )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = True )
 return I1II1
 if 35 - 35: eVVVeeveevV * eeveee * VevVVe % II1Iiii1111i . Veveevev
def IIi1I11I1II ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 VVeveIII111i11IiI = [ ]
 VVVeveVVeevevV = VevVevVVevVevVev . getSetting ( 'favlist' )
 if VVVeveVVeevevV == 'yes' : VVeveIII111i11IiI . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : VVeveIII111i11IiI . append ( ( '[COLOR cyan]Add to Keeo Safe[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 eevVeeveVeveVVevev . addContextMenuItems ( VVeveIII111i11IiI , replaceItems = False )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = False )
 return I1II1
 if 58 - 58: VVeVeeevevee + Veeve * IiiIII111ii * i11iIiiIii - iiI1i1
def i11I1II1I11i ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 eevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
 VVeveIII111i11IiI = [ ]
 VVVeveVVeevevV = VevVevVVevVevVev . getSetting ( 'favlist' )
 if VVVeveVVeevevV == 'yes' : VVeveIII111i11IiI . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : VVeveIII111i11IiI . append ( ( '[COLOR cyan]Add to Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 eevVeeveVeveVVevev . addContextMenuItems ( VVeveIII111i11IiI , replaceItems = False )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = False )
 return I1II1
iiII1i1 = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvRXZvbHZlTWFpbk1lbnUueG1s' )
def I11IiI1I11i1i ( url , name ) :
 eeeeeveveeveeve = eeveevVeVeevVevVV ( url )
 if len ( eeeeeveveeveeve ) > 1 :
  Ii1iI = eeVe
  eeeevViII1iii = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( eeeevViII1iii ) :
   file ( eeeevViII1iii , 'w' ) . close ( )
  VevVeeveveVevVevev = open ( eeeevViII1iii )
  IiVevevevVevVVevevee = VevVeeveveVevVevev . read ( )
  if IiVevevevVevVVevevee == eeeeeveveeveeve : pass
  else :
   eVVVeveeveve ( '[B][COLOR yellow]PICASSO INFO[/COLOR][/B]' , eeeeeveveeveeve )
   i11i1iiiII = open ( eeeevViII1iii , "w" )
   i11i1iiiII . write ( eeeeeveveeveeve )
   i11i1iiiII . close ( )
   if 69 - 69: eeveee / II1Iiii1111i
def eVVVeveeveve ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 IIiIii = xbmcgui . Window ( id )
 IIIII1iii = 50
 while ( IIIII1iii > 0 ) :
  try :
   xbmc . sleep ( 10 )
   IIIII1iii -= 1
   IIiIii . getControl ( 1 ) . setLabel ( heading )
   IIiIii . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 7 - 7: eeveee + Ii . VevVVe / II1Iiii1111i
def I111i1I1 ( name ) :
 global Icon
 global Next
 global Previous
 global window
 global Quit
 global images
 eeeevViII1iii = os . path . join ( os . path . join ( eeVe , '' ) , name + '.txt' )
 VevVeeveveVevVevev = open ( eeeevViII1iii )
 IiVevevevVevVVevevee = VevVeeveveVevVevev . read ( )
 images = re . compile ( '<image>(.+?)</image>' ) . findall ( IiVevevevVevVVevevee )
 VevVevVVevVevVev . setSetting ( 'pos' , '0' )
 window = pyxbmct . AddonDialogWindow ( '' )
 VeveevevVVeevevVevV = '/resources/art'
 II1i = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + VeveevevVVeevevVevV , 'next_focus.png' ) )
 VeVVeVevevevVeveveV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + VeveevevVVeevevVevV , 'next1.png' ) )
 i1VeVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + VeveevevVVeevevVevV , 'previous_focus.png' ) )
 iIII1I1i1i = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + VeveevevVVeevevVevV , 'previous.png' ) )
 eevVIIiI1I1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + VeveevevVVeevevVevV , 'close_focus.png' ) )
 I11I1IIiiII1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + VeveevevVVeevevVevV , 'close.png' ) )
 IIIIIii1ii11 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + VeveevevVVeevevVevV , 'main-bg1.png' ) )
 window . setGeometry ( 1300 , 720 , 100 , 50 )
 VVVeeeevVeeVeV = pyxbmct . Image ( IIIIIii1ii11 )
 window . placeControl ( VVVeeeevVeeVeV , - 10 , - 10 , 130 , 70 )
 iIIII1iIIii = '0xFF000000'
 Previous = pyxbmct . Button ( '' , focusTexture = i1VeVV , noFocusTexture = iIII1I1i1i , textColor = iIIII1iIIii , focusedColor = iIIII1iIIii )
 Next = pyxbmct . Button ( '' , focusTexture = II1i , noFocusTexture = VeVVeVevevevVeveveV , textColor = iIIII1iIIii , focusedColor = iIIII1iIIii )
 Quit = pyxbmct . Button ( '' , focusTexture = eevVIIiI1I1 , noFocusTexture = I11I1IIiiII1 , textColor = iIIII1iIIii , focusedColor = iIIII1iIIii )
 Icon = pyxbmct . Image ( images [ 0 ] , aspectRatio = 2 )
 window . placeControl ( Previous , 102 , 1 , 10 , 10 )
 window . placeControl ( Next , 102 , 40 , 10 , 10 )
 window . placeControl ( Quit , 102 , 21 , 10 , 10 )
 window . placeControl ( Icon , 0 , 0 , 100 , 50 )
 Previous . controlRight ( Next )
 Previous . controlUp ( Quit )
 window . connect ( Previous , eVeVVVe )
 window . connect ( Next , ii1I )
 Previous . setVisible ( False )
 window . setFocus ( Quit )
 Previous . controlRight ( Quit )
 Quit . controlLeft ( Previous )
 Quit . controlRight ( Next )
 Next . controlLeft ( Quit )
 window . connect ( Quit , window . close )
 window . doModal ( )
 del window
 if 85 - 85: VVeVeeevevee
def ii1I ( ) :
 eeVeVev = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 eeeveeeVe = int ( eeVeVev ) + 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( eeeveeeVe ) )
 eevVVevVevVe = len ( images )
 Icon . setImage ( images [ int ( eeeveeeVe ) ] )
 Previous . setVisible ( True )
 if int ( eeeveeeVe ) == int ( eevVVevVevVe ) - 1 :
  Next . setVisible ( False )
  if 78 - 78: Veveevev / II1Iiii1111i - eVVVeeveevV - IiiIII111ii * I1ii
def eVeVVVe ( ) :
 eeVeVev = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 Ii1I11I = int ( eeVeVev ) - 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( Ii1I11I ) )
 Icon . setImage ( images [ int ( Ii1I11I ) ] )
 Next . setVisible ( True )
 if int ( Ii1I11I ) == 0 :
  Previous . setVisible ( False )
  if 36 - 36: Ii11111i + II1Iiii1111i
def iIIIi1i1I11i ( url , fanart ) :
 VevVevVVevVevVev . setSetting ( 'favlist' , 'yes' )
 eVVevVVevVV = None
 file = open ( Ve , 'r' )
 eVVevVVevVV = file . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 eeveveVVeve = re . compile ( "<item>(.+?)</item>" , re . DOTALL ) . findall ( eVVevVVevVV )
 for VVVevevV in eeveveVVeve :
  eeeveVe ( VeveevVevevVeeveev , url , Veveveeeeeevev , fanart , VVVevevV )
 VevVevVVevVevVev . setSetting ( 'favlist' , 'no' )
 if 87 - 87: I1ii + iiI1i1 - VeeevVVeveVV
def IiI1 ( name , url , iconimage , fanart ) :
 i1IIii1iiIi = VevVevVVevVevVev . getSetting ( 'favtype' )
 url = url . replace ( ' ' , '%20' )
 iconimage = iconimage . replace ( ' ' , '%20' )
 if '<>' in url :
  I1IIII1i = url . split ( '<>' ) [ 0 ]
  VVeVevev = url . split ( '<>' ) [ 1 ]
  IiI111111IIII = url . split ( '<>' ) [ 2 ]
  i1Ii = url . split ( '<>' ) [ 3 ]
  ii111iI1iIi1 = url . split ( '<>' ) [ 4 ]
  string = '<FAV><item>\n<title>' + name + '</title>\n<meta>tvep</meta>\n<nan>tvshow</nan>\n<showyear>' + i1Ii + '</showyear>\n<imdb>' + I1IIII1i + '</imdb>\n<season>' + VVeVevev + '</season>\n<episode>' + IiI111111IIII + '</episode>\n<episodeyear>' + ii111iI1iIi1 + '</episodeyear>\n<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 elif len ( url ) == 9 :
  string = '<FAV><item>\n<title>' + name + '</title>\n<meta>movie</meta>\n<nan>movie</nan>\n<imdb>' + url + '</imdb>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 else :
  string = '<FAV><item>\n<title>' + name + '</title>\n<' + i1IIii1iiIi + '>' + url + '</' + i1IIii1iiIi + '>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 IiII = open ( Ve , 'a' )
 IiII . write ( string )
 IiII . close ( )
 if 63 - 63: VVVevV
def i1II ( name , url , iconimage ) :
 print name
 eVVevVVevVV = None
 file = open ( Ve , 'r' )
 eVVevVVevVV = file . read ( )
 IiiI11i1I = ''
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( eVVevVVevVV )
 for VVeVVeveeeveeV in eeveveVVeve :
  string = '\n<FAV><item>\n' + VVeVVeveeeveeV + '</item>\n'
  if name in VVeVVeveeeveeV :
   print 'xxxxxxxxxxxxxxxxx'
   string = string . replace ( 'item' , ' ' )
  IiiI11i1I = IiiI11i1I + string
 file = open ( Ve , 'w' )
 file . truncate ( )
 file . write ( IiiI11i1I )
 file . close ( )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 80 - 80: eVVVeeveevV / VVeVeeevevee / Veveevev + Ii - II1Iiii1111i
def VeeveVeveve ( url ) :
 try :
  eVeeeeevevevVeevev = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  file = open ( IIi1IiiiI1Ii , 'r' )
  iIIiiIIi1IiI = file . read ( )
  if eVeeeeevevevVeevev in iIIiiIIi1IiI : return '[COLOR cyan] (RD)[/COLOR]'
  else : return ''
 except : return ''
 if 14 - 14: i1iIIi1 % I1ii % II1Iiii1111i - i11iIiiIii
def eevVVeveveveeVe ( ) :
 xbmcaddon . Addon ( 'script.module.nanscrapers' ) . openSettings ( )
 if 86 - 86: VVeevevev * VeeevVVeveVV
def VeeVeveVe ( ) :
 xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
 if 66 - 66: VVeevevev * II1Iiii1111i
def II1IIIiiI11 ( ) :
 xbmcaddon . Addon ( 'script.module.metahandler' ) . openSettings ( )
 if 86 - 86: VVeevevev % VeeevVVeveVV % VVeevevev / VevVVe
def eeeevV ( link ) :
 try :
  VeeveeeevVee = re . compile ( '<layouttype>(.+?)</layouttype>' ) . findall ( link ) [ 0 ]
  if VeeveeeevVee == 'thumbnail' : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 except : pass
 if 9 - 9: II1Iiii1111i
 if 99 - 99: VVeVeeevevee - iI1I - I1ii % VVeevevev
eVVee = ii1Ii1IiIIi ( ) ; VeI1Ii11I1Ii1i = None ; VeveevVevevVeeveev = None ; i11iiI1111 = None ; IiiIIiiiiii = None ; VevevVeveVVevevVevev = None ; VVVVeve = None
try : IiiIIiiiiii = urllib . unquote_plus ( eVVee [ "site" ] )
except : pass
try : VeI1Ii11I1Ii1i = urllib . unquote_plus ( eVVee [ "url" ] )
except : pass
try : VeveevVevevVeeveev = urllib . unquote_plus ( eVVee [ "name" ] )
except : pass
try : i11iiI1111 = int ( eVVee [ "mode" ] )
except : pass
try : VevevVeveVVevevVevev = urllib . unquote_plus ( eVVee [ "iconimage" ] )
except : pass
try : eeeevVV = urllib . unquote_plus ( eVVee [ "fanart" ] )
except : pass
try : VVVVeve = str ( eVVee [ "description" ] )
except : pass
if 10 - 10: iI1I % VevVVe
if i11iiI1111 == None or VeI1Ii11I1Ii1i == None or len ( VeI1Ii11I1Ii1i ) < 1 : Veeveveve ( )
elif i11iiI1111 == 1 : iiIii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 2 : IIiiIIi1 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , VVVVeve )
elif i11iiI1111 == 3 : VVVIiiiii1iI ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i11iiI1111 == 4 : eeVevevV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i11iiI1111 == 5 : eeeVeveeveevVev ( )
elif i11iiI1111 == 6 : IIi1ii1Ii ( VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i11iiI1111 == 7 : VVeeVeeveveeev ( VeI1Ii11I1Ii1i )
elif i11iiI1111 == 8 : I111i1I1 ( VeveevVevevVeeveev )
elif i11iiI1111 == 9 : i1I11IiI1iiII ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i )
elif i11iiI1111 == 10 : iI1IVeeVeVe ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 11 : eeVevevevVevevev ( VeI1Ii11I1Ii1i )
elif i11iiI1111 == 12 : VeeVeveVe ( )
elif i11iiI1111 == 13 : II1IIIiiI11 ( )
elif i11iiI1111 == 15 : SCRAPEMOVIE ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i11iiI1111 == 16 : eevev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i11iiI1111 == 17 : VeeveveveeVVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i )
elif i11iiI1111 == 18 : eeveeeVVevev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 19 : I1I1I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 97 - 97: VeeevVVeveVV - iI1I
elif i11iiI1111 == 20 : IiI1 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 21 : i1II ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i11iiI1111 == 22 : iIIIi1i1I11i ( VeI1Ii11I1Ii1i , eeeevVV )
elif i11iiI1111 == 23 : DOIPLAYER ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 24 : VevevVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 25 : eevVVeveveveeVe ( )
if 58 - 58: iiI1i1 + Ii11111i
elif i11iiI1111 == 26 : eev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 27 : VVeveVeVVeveVVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 28 : VeveVeeveve ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 29 : VevVeeeVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 30 : VVVeveveveveV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 31 : iI1i11II1i ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 32 : VeeeeVeveVVVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 33 : VVeeeevVeveev ( VeI1Ii11I1Ii1i )
elif i11iiI1111 == 34 : VeVeeVeV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 35 : I1ii1ii11i1I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 30 - 30: iiiIi % IiiIII111ii * eVVVeeveevV - VVVevV * i11IiIiiIIIII % iiiIi
elif i11iiI1111 == 36 : VVevVVVVeeevVVV ( )
elif i11iiI1111 == 37 : eevVeevev ( VeI1Ii11I1Ii1i )
elif i11iiI1111 == 38 : ii1111iII ( VeI1Ii11I1Ii1i )
elif i11iiI1111 == 39 : VevVeveeVVV ( VeI1Ii11I1Ii1i )
elif i11iiI1111 == 40 : VVVeVe ( )
elif i11iiI1111 == 41 : VeVevevevVevVe ( VeI1Ii11I1Ii1i )
elif i11iiI1111 == 42 : eeeVeevVVVeeev ( VeI1Ii11I1Ii1i )
if 46 - 46: i11iIiiIii - Ii11111i . I1ii
elif i11iiI1111 == 43 : IIIi11I11 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 44 : VVVVevVVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 45 : eeeVeVVVeveeeve ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i11iiI1111 == 46 : eeVVeV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 100 - 100: VevVVe / eeveee * IiiIII111ii . Ii11111i / eVVVeeveevV
elif i11iiI1111 == 47 : DODOCLOGMENU ( )
elif i11iiI1111 == 48 : GET_DOCCONTENT ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , II1 )
elif i11iiI1111 == 49 : DO_DOCCONTENT ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , II1 )
elif i11iiI1111 == 50 : RESOLVE2 ( VeI1Ii11I1Ii1i )
if 83 - 83: iI1I
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
