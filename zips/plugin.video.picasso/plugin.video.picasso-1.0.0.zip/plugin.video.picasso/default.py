#V 1.0.0
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , requests , urllib , urllib2 , json , os , re , sys , datetime , urlresolver , random , liveresolver , base64 , pyxbmct
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
import nanscrapers
if 64 - 64: i11iIiiIii
if 65 - 65: Vev / iIii1I11I1II1 % VeeeeeeeVV - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = 'plugin.video.picasso'
iIiiiI1IiI1I1 = Addon ( IiII1IiiIiI1 , sys . argv )
eevVeVeVVevev = xbmcaddon . Addon ( id = IiII1IiiIiI1 )
I11i = xbmcaddon . Addon ( ) . getAddonInfo
VevV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 , 'fanart.png' ) )
Ve = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 , 'fanart.png' ) )
I1ii11iIi11i = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 , 'icon.png' ) )
I1IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'next.png' ) )
eevVVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources' , 'rd.txt' ) )
iIiiiI = 'http://matsbuilds.uk/Menus/anewEvolvemenu/EvolveMainMenu.xml'
Iii1ii1II11i = eevVeVeVVevev . getSetting ( 'password' )
iI111iI = eevVeVeVVevev . getSetting ( 'enable_meta' )
IiII = 'https://xhamster.com/'
iI1Ii11111iIi = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
i1i1II = requests . session ( )
VeveeevVVev = 'http://matsbuilds.uk/Menus/anewEvolvemenu/info.txt'
I1i1iiI1 = xbmc . translatePath ( 'special://home/userdata/addon_data/' + IiII1IiiIiI1 )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/Database' , 'picasso.db' ) )
eeveVev = 'http://newmoviesonline.ws/'
eeevev = 'http://newmoviesonline.ws/sleight/'
eevev = open ( iiIIIII1i1iI , 'a' )
eevev . close ( )
if 62 - 62: II1ii - eeveVeVeveve . iIi1IIii11I + eeev * Veeev % eeeveveveveveev
def I11i1i11i1I ( ) :
 if not os . path . exists ( I1i1iiI1 ) :
  os . mkdir ( I1i1iiI1 )
 Iiii ( VeveeevVVev , 'GlobalCompare' )
 VVVevV ( '[B][COLOR yellow]Keep Safe[/COLOR][/B]' , 'url' , 22 , 'http://i.imgur.com/cR0cP8f.png' , Ve )
 VVVevV ( '[B][COLOR yellow]Find It...[/COLOR][/B]' , 'url' , 5 , 'http://i.imgur.com/ZQYQyHG.png' , Ve )
 VVVevV ( '[B][COLOR cyan]Movie Madness[/COLOR][/B]' , 'http://matsbuilds.uk/Menus/Movies/Mainmenu.xml' , 26 , 'http://i.imgur.com/Y2rejnc.png' , Ve )
 VVVevV ( '[B][COLOR cyan]Telly Box[/COLOR][/B]' , 'http://matsbuilds.uk/Menus/TvShows/Mainmenu.xml' , 27 , 'http://i.imgur.com/63LrHYW.png' , Ve )
 eeeveeVeveVVVVe = eVevevevVeVeeeveve ( iIiiiI )
 iiiI11 = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeveeVeveVVVVe )
 for VVeeV in iiiI11 :
  VVeVeveve = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVeeV )
  for II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV in VVeVeveve :
   VVVevV ( II111iiiiII , eVeVeeveveVe , 1 , VeeevevVevevVevVevV , VevV )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 90 - 90: i1IIiiiii + i1iIIIiI1I - VeVevevev % VeeVeVevVe + iiIIiIiIi
def i1I11 ( name , url , iconimage , fanart ) :
 VVVevV ( '[B][COLOR yellow]MOVIE SEARCH[/COLOR][/B]' , 'http://matsbuilds.uk/Menus/Movies/Search/Search.txt' , 5 , 'http://i.imgur.com/QArRVYb.png' , Ve )
 VVVevV ( '[B][COLOR yellow]UK CINEMA RELEASE DATES[/COLOR][/B]' , 'http://www.empireonline.com/movies/features/upcoming-movies/' , 34 , 'http://i.imgur.com/aKQgDR7.png' , Ve )
 eeeveeVeveVVVVe = eVevevevVeVeeeveve ( url )
 iiiI11 = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeveeVeveVVVVe )
 for VVeeV in iiiI11 :
  VVeVeveve = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVeeV )
  for name , url , iconimage , fanart in VVeVeveve :
   iI ( name , url , iconimage , fanart , VVeeV )
   if 100 - 100: VeveeeeevVeevev - Vevev / i11I1
def Ii11Ii11I ( name , url , iconimage , fanarts ) :
 VVVevV ( '[B][COLOR yellow]TV SEARCH[/COLOR][/B]' , 'http://matsbuilds.uk/anewEvolvemenu/search.xml' , 33 , 'http://i.imgur.com/he5RFkL.png' , fanarts )
 VVVevV ( '[B][COLOR yellow]TV SCHEDULE[/COLOR][/B]' , 'http://www.tvwise.co.uk/uk-premiere-dates/' , 32 , 'http://i.imgur.com/XKAapZH.png' , fanarts )
 VVVevV ( '[B][COLOR yellow]Latest Episodes[/COLOR][/B]' , 'http://www.watchepisodes4.com' , 28 , 'http://i.imgur.com/n8itltl.png' , fanarts )
 VVVevV ( '[B][COLOR yellow]Popular Shows[/COLOR][/B]' , 'http://www.watchepisodes4.com/home/popular-series' , 29 , 'http://i.imgur.com/ury75ui.png' , fanarts )
 VVVevV ( '[B][COLOR yellow]New Shows[/COLOR][/B]' , 'http://www.watchepisodes4.com/home/new-series' , 30 , 'http://i.imgur.com/UPWjTLw.png' , fanarts )
 iI11i1I1 = eeveevVVVeveev ( name )
 eevVeVeVVevev . setSetting ( 'tv' , iI11i1I1 )
 eeeveeVeveVVVVe = eVevevevVeVeeeveve ( url )
 iiiI11 = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeveeVeveVVVVe )
 for VVeeV in iiiI11 :
  VVeVeveve = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVeeV )
  for name , url , iconimage , VevV in VVeVeveve :
   iI ( name , url , iconimage , VevV , VVeeV )
   if 84 - 84: VeveeeeevVeevev
def iIi1ii1I1 ( name , url , iconimage , fanart ) :
 iI11i1I1 = eeveevVVVeveev ( name )
 eevVeVeVVevev . setSetting ( 'tv' , iI11i1I1 )
 eeeveeVeveVVVVe = eVevevevVeVeeeveve ( url )
 eev ( eeeveeVeveVVVVe )
 if '<message>' in eeeveeVeveVVVVe :
  VeveeevVVev = re . compile ( '<message>(.+?)</message>' ) . findall ( eeeveeVeveVVVVe ) [ 0 ]
  Iiii ( VeveeevVVev , iI11i1I1 )
 if '<intro>' in eeeveeVeveVVVVe :
  I11II1i = re . compile ( '<intro>(.+?)</intro>' ) . findall ( eeeveeVeveVVVVe ) [ 0 ]
  IIIII ( I11II1i )
 if 'XXX>yes</XXX' in eeeveeVeveVVVVe : eeeeeeVevee ( eeeveeVeveVVVVe )
 iiiI11 = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeveeVeveVVVVe )
 for VVeeV in iiiI11 :
  iI ( name , url , iconimage , fanart , VVeeV )
  if 49 - 49: Veeev * iIii1I11I1II1 / i1IIi / i11iIiiIii / Veeev
def iI ( name , url , iconimage , fanart , item ) :
 try :
  if '<sportsdevil>' in item : I1i1I1II ( name , url , iconimage , fanart , item )
  elif '<iplayer>' in item : i1 ( name , url , iconimage , fanart , item )
  elif '<folder>' in item : IiIiiI ( name , url , iconimage , fanart , item )
  elif '<iptv>' in item : I1I ( name , url , iconimage , fanart , item )
  elif '<image>' in item : eVVeveveVV ( name , url , iconimage , fanart , item )
  elif '<text>' in item : VeVe ( name , url , iconimage , fanart , item )
  elif '<scraper>' in item : iIeevevV ( name , url , iconimage , fanart , item )
  elif '<lbscraper>' in item : VVVevVVVevevee ( name , url , iconimage , fanart , item )
  elif '<redirect>' in item : Iii111II ( name , url , iconimage , fanart , item )
  elif '<oktitle>' in item : iiii11I ( name , url , iconimage , fanart , item )
  elif '<nan>' in item : VeeevVVeveVV ( name , url , iconimage , fanart , item )
  elif '<adult>' in item : ii11i1 ( name , url , iconimage , fanart , item )
  else : IIIii1II1II ( name , url , iconimage , fanart , item )
 except : pass
 if 42 - 42: VeeVeVevVe + i1IIiiiii
def i1 ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<iplayer>(.+?)</iplayer>' ) . findall ( item ) [ 0 ]
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 url = 'plugin://plugin.video.iplayerwww/?url=%s&mode=202&name=%s&iconimage=%s&description=&subtitles_url=&logged_in=False' % ( url , name , iconimage )
 eevVeveevVe ( name , url , 16 , iconimage , fanart )
 if 16 - 16: Vev - Vevev * iIii1I11I1II1 + iiIIiIiIi
def VeeevVVeveVV ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 Ii11iII1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 VeevVevVeveeVevV = re . compile ( '<nan>(.+?)</nan>' ) . findall ( item ) [ 0 ]
 IIIIii = re . compile ( '<imdb>(.+?)</imdb>' ) . findall ( item ) [ 0 ]
 if VeevVevVeveeVevV == 'movie' :
  IIIIii = IIIIii + '<>movie'
 elif VeevVevVeveeVevV == 'tvshow' :
  Veveev = re . compile ( '<showname>(.+?)</showname>' ) . findall ( item ) [ 0 ]
  VVevevVe = re . compile ( '<season>(.+?)</season>' ) . findall ( item ) [ 0 ]
  VevVVVevVVeVevV = re . compile ( '<episode>(.+?)</episode>' ) . findall ( item ) [ 0 ]
  VevevVeeveveveeVev = re . compile ( '<showyear>(.+?)</showyear>' ) . findall ( item ) [ 0 ]
  VeVevVevev = re . compile ( '<episodeyear>(.+?)</episodeyear>' ) . findall ( item ) [ 0 ]
  IIIIii = IIIIii + '<>' + Veveev + '<>' + VVevevVe + '<>' + VevVVVevVVeVevV + '<>' + VevevVeeveveveeVev + '<>' + VeVevVevev
  VeevVevVeveeVevV = "tvep"
 IIiII ( name , IIIIii , 19 , iconimage , 1 , VeevVevVeveeVevV , isFolder = True )
 if 80 - 80: VeveeeeevVeevev . i1IIiiiii
def IIi ( name , imdb , iconimage , fanart ) :
 eevVVV = ''
 i11iIIIIIi1 = name
 iI11i1I1 = eeveevVVVeveev ( name )
 eevVeVeVVevev . setSetting ( 'tv' , iI11i1I1 )
 if 'movie' in imdb :
  imdb = imdb . split ( '<>' ) [ 0 ]
  iiII1i1 = [ ]
  eeveveVVeve = [ ]
  VVVevevV = name . partition ( '(' )
  VVeVVeveeeveeV = VVVevevV [ 0 ]
  VVeVVeveeeveeV = eeveevVVVeveev ( VVeVVeveeeveeV )
  VeveevVevevVeeveev = VVVevevV [ 2 ] . partition ( ')' ) [ 0 ]
  VevevVeveVVevevVevev = nanscrapers . scrape_movie ( VVeVVeveeeveeV , VeveevVevevVeeveev , imdb , timeout = 800 )
 else :
  Veveev = imdb . split ( '<>' ) [ 1 ]
  i1Veevev = imdb . split ( '<>' ) [ 0 ]
  VVevevVe = imdb . split ( '<>' ) [ 2 ]
  VevVVVevVVeVevV = imdb . split ( '<>' ) [ 3 ]
  VevevVeeveveveeVev = imdb . split ( '<>' ) [ 4 ]
  VeVevVevev = imdb . split ( '<>' ) [ 5 ]
  VevevVeveVVevevVevev = nanscrapers . scrape_episode ( Veveev , VevevVeeveveveeVev , VeVevVevev , VVevevVe , VevVVVevVVeVevV , i1Veevev , None )
 i1i = 1
 for iiI111I1iIiI in list ( VevevVeveVVevevVevev ( ) ) :
  for II in iiI111I1iIiI :
   if urlresolver . HostedMediaFile ( II [ 'url' ] ) . valid_url ( ) :
    eevVVV = Ii1I1IIii1II ( II [ 'url' ] )
    name = "Link " + str ( i1i ) + ' | ' + II [ 'source' ] + eevVVV
    i1i = i1i + 1
    Vevii1ii1ii ( name , II [ 'url' ] , 2 , iconimage , fanart , description = eevVeVeVVevev . getSetting ( 'tv' ) )
    if 91 - 91: VeveeeeevVeevev
    if 15 - 15: II111iiii
def ii11i1 ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<adult>(.+?)</adult>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 VVVevV ( name , url , 36 , iconimage , fanart )
 if 18 - 18: i11iIiiIii . i1IIi % VeeeeeeeVV / Vev
def VVevVeVeveevev ( ) :
 VVVevV ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , IiII + 'rankings/weekly-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]Top Viewed[/COLOR][/B]' , IiII + 'rankings/weekly-top-viewed.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]HD[/COLOR][/B]' , IiII + 'categories/hd-videos' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]Most Commented[/COLOR][/B]' , IiII + 'rankings/weekly-top-commented.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , IiII + 'rankings/weekly-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]50 Newest[/COLOR][/B]' , IiII + 'last50.php' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]Best of 2016[/COLOR][/B]' , IiII + 'videos/top/year/2016' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]All-time Top Rated[/COLOR][/B]' , IiII + 'rankings/alltime-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]Main Categories[/COLOR][/B]' , IiII , 39 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]All Categories Alpha[/COLOR][/B]' , IiII + 'categories' , 38 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 VVVevV ( '[B][COLOR yellow]Search[/COLOR][/B]' , 'url' , 40 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 53 - 53: Vev * iIi1IIii11I + i1iIIIiI1I
def Ii ( url ) :
 eVVeev = eeevevVeveveV ( url )
 iIiIIIi = re . compile ( '<div class="video" data-previewvideo=".+?"><a href="(.+?)" class="hRotator"><img src=\'(.+?)\' class=\'thumb\' alt="(.+?)"/>' , re . DOTALL ) . findall ( eVVeev )
 for url , I1ii11iIi11i , II111iiiiII in iIiIIIi :
  II111iiiiII = II111iiiiII . replace ( '&#039;' , '\'' ) . replace ( '&amp;' , ' & ' )
  eeeevevVVVeeV ( '[B][COLOR yellow]%s[/COLOR][/B]' % II111iiiiII , url , 41 , I1ii11iIi11i , VevV , '' )
 VevevVVVeVeeevV = re . compile ( '<link rel="next" href="(.+?)"' , re . DOTALL ) . findall ( eVVeev )
 for url in VevevVVVeVeeevV :
  eeeevevVVVeeV ( '[B][COLOR cyan]Next Page>>>[/COLOR][/B]' , url , 37 , 'http://i.imgur.com/Uqrznbf.png' , VevV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 77 - 77: iiIIiIiIi % iiIIiIiIi * i1IIiiiii - i11iIiiIii
def VeeveV ( url ) :
 eVVeev = eeevevVeveveV ( url )
 iIiIIIi = re . compile ( '<div class="list">(.+?)<div class="head"' , re . DOTALL ) . findall ( eVVeev ) [ 1 ]
 IIiIi1iI = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( str ( iIiIIIi ) )
 for url in IIiIi1iI :
  II111iiiiII = url . split ( 'xhamster.com/' ) [ 1 ]
  try :
   II111iiiiII = II111iiiiII . replace ( '-1.html' , '' )
   II111iiiiII = II111iiiiII . split ( '/' ) [ 1 ] . title ( )
  except : pass
  if 'categories' not in II111iiiiII :
   eeeevevVVVeeV ( '[B][COLOR yellow]%s[/COLOR][/B]' % II111iiiiII , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 35 - 35: VeeVeVevVe % Vev - Vev
def IiIIIi1iIi ( url ) :
 eVVeev = eeevevVeveveV ( url )
 iIiIIIi = re . compile ( 'ul class="alphabet-block".+?<a class=""(.+?)</ul>' , re . DOTALL ) . findall ( eVVeev )
 IIiIi1iI = re . compile ( 'href="(.+?)">(.+?)<' , re . DOTALL ) . findall ( str ( iIiIIIi ) )
 for url , II111iiiiII in IIiIi1iI :
  eeeevevVVVeeV ( '[B][COLOR yellow]%s[/COLOR][/B]' % II111iiiiII , url , 42 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 68 - 68: i11iIiiIii % eeeveveveveveev + i11iIiiIii
def iii ( url ) :
 eVVeev = eeevevVeveveV ( url )
 iIiIIIi = re . compile ( '<div class="letter-categories">(.+?)</ul>' , re . DOTALL ) . findall ( eVVeev )
 IIiIi1iI = re . compile ( 'href="(.+?)"><span >(.+?)<' , re . DOTALL ) . findall ( str ( iIiIIIi ) )
 for url , II111iiiiII in IIiIi1iI :
  eeeevevVVVeeV ( '[B][COLOR yellow]%s[/COLOR][/B]' % II111iiiiII , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , VevV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 1 - 1: eeveVeVeveve / Veeev % iiIIiIiIi * VeveeeeevVeevev . i11iIiiIii
def III1Iiii1I11 ( ) :
 IIII = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 IIII . doModal ( )
 if ( IIII . isConfirmed ( ) ) :
  iiIiI = IIII . getText ( ) . replace ( ' ' , '+' )
  eVeVeeveveVe = IiII + 'search.php?from=&q=' + iiIiI + '&qcat=video'
  Ii ( eVeVeeveveVe )
  if 91 - 91: iiIIiIiIi % i1IIi % iIii1I11I1II1
def eeevevVeveveV ( url ) :
 IIi1I11I1II = { }
 IIi1I11I1II [ 'User-Agent' ] = iI1Ii11111iIi
 eeeveeVeveVVVVe = i1i1II . get ( url , headers = IIi1I11I1II ) . text
 eeeveeVeveVVVVe = eeeveeVeveVVVVe . encode ( 'ascii' , 'ignore' )
 return eeeveeVeveVVVVe
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 63 - 63: VeeeeeeeVV - iIi1IIii11I . II111iiii / Veeev . eeev / Vev
def eevVVVVevevVevVe ( url ) :
 ii = [ ]
 eVeeVVVeVe = [ ]
 i1Iii1i1I = ''
 eVVeev = eeevevVeveveV ( url )
 iiiI11 = re . compile ( 'sources:(.+?)allowFullScreen:' , re . DOTALL ) . findall ( eVVeev ) [ 0 ]
 VVeVevev = re . compile ( '"(.+?)":"(.+?)"' , re . DOTALL ) . findall ( str ( iiiI11 ) )
 for IiI111111IIII , eeeveeVeveVVVVe in VVeVevev :
  i1Iii1i1I = '[B][COLOR cyan]%s[/COLOR][/B]' % IiI111111IIII
  ii . append ( i1Iii1i1I )
  eVeeVVVeVe . append ( eeeveeVeveVVVVe )
 if len ( iiiI11 ) > 1 :
  i1Ii = xbmcgui . Dialog ( )
  ii111iI1iIi1 = i1Ii . select ( 'Please Select Quality' , ii )
  if ii111iI1iIi1 == - 1 :
   return
  elif ii111iI1iIi1 > - 1 :
   url = eVeeVVVeVe [ ii111iI1iIi1 ]
 else :
  url = re . compile ( 'sources: {".+?":"(.+?)"' ) . findall ( eVVeev ) [ 0 ]
 url = url . replace ( '\/' , '/' )
 VVV = xbmcgui . ListItem ( II111iiiiII , iconImage = 'DefaultVideo.png' , thumbnailImage = VeeevevVevevVevVevV )
 VVV . setInfo ( type = 'Video' , infoLabels = { "Title" : II111iiiiII } )
 VVV . setProperty ( "IsPlayable" , "true" )
 VVV . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , VVV )
 if 68 - 68: II111iiii + VeVevevev
def eeeevevVVVeeV ( name , url , mode , iconimage , fanart , description ) :
 I1I1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 VeVVevevev = True
 VVV = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 VVV . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 VVV . setProperty ( 'fanart_image' , fanart )
 if mode == 41 :
  VVV . setProperty ( "IsPlayable" , "true" )
  VeVVevevev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1I1I , listitem = VVV , isFolder = False )
 else :
  VeVVevevev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1I1I , listitem = VVV , isFolder = True )
 return VeVVevevev
 if 14 - 14: VeveeeeevVeevev - eeeveveveveveev
 if 11 - 11: II111iiii * II111iiii % iIii1I11I1II1 * Vevev + eeev / II1ii
 if 3 - 3: Veeev
def iIeevevV ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<scraper>(.+?)</scraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 VVVevV ( name , url , 18 , iconimage , fanart )
 if 24 - 24: i11iIiiIii + iiIIiIiIi * VeeVeVevVe - II111iiii . i1iIIIiI1I % iIii1I11I1II1
def ee ( name , url , iconimage , fanart ) :
 I1IiiiiI = url
 if I1IiiiiI == 'latestmovies' :
  eevV = 15
  IiIIii1iII1II = MOVIESINDEXER ( )
  Iii1I1I11iiI1 = re . compile ( '<item>(.+?)</item>' ) . findall ( IiIIii1iII1II )
  for VVeeV in Iii1I1I11iiI1 :
   VVeVeveve = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVeeV )
   I1I1i1I = len ( Iii1I1I11iiI1 )
   for name , url , iconimage , fanart in VVeVeveve :
    if '<meta>' in VVeeV :
     ii1I = re . compile ( '<meta>(.+?)</meta>' ) . findall ( VVeeV ) [ 0 ]
     IIiII ( name , url , eevV , iconimage , I1I1i1I , ii1I , isFolder = False )
    else : Vevii1ii1ii ( name , url , 15 , iconimage , fanart )
    if 99 - 99: VeeVeVevVe / eeveVeVeveve / VeveeeeevVeevev % II1ii
    if 13 - 13: VeVevevev * eeveVeVeveve * i11I1
def iI11iI1IiiIiI ( name , url , iconimage , fanarts ) :
 eeeveeVeveVVVVe = Ii1I1i ( 'http://www.watchepisodes4.com' )
 VV = re . compile ( '<a title=".+?" .+? style="background-image: url(.+?)"></a>.+?<div class="hb-right">.+?<a title=".+?" href="(.+?)" class="episode">(.+?)</a>' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
 for iconimage , url , name in VV :
  iconimage = iconimage . replace ( "('" , "" ) . replace ( "')" , "" )
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  name = name . split ( '  ' ) [ 0 ]
  VVVevV ( name , url , 24 , iconimage , iconimage )
  if 37 - 37: i11I1 % i1IIiiiii . i11iIiiIii % VeeVeVevVe . eeveVeVeveve
def I11I1IIII ( name , url , iconimage , fanart ) :
 eeeveeVeveVVVVe = Ii1I1i ( url )
 VV = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
 for url , name , iconimage in VV :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  VVVevV ( name , url , 31 , iconimage , iconimage )
  if 25 - 25: VeVevevev
def iiiI1i1I ( name , url , iconimage , fanart ) :
 eeeveeVeveVVVVe = Ii1I1i ( url )
 VV = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
 for url , name , iconimage in VV :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  VVVevV ( name , url , 31 , iconimage , iconimage )
  if 13 - 13: VeveeeeevVeevev + Vev + iiIIiIiIi % II1ii / Veeev . VeveeeeevVeevev
def VVevVeeeeveVVevV ( name , url , iconimage , fanart ) :
 eeeveeVeveVVVVe = eevevVev ( url )
 eVVevVevevVeevVeve = re . compile ( '<div class="std-cts">.+?<div class="sdt-content tnContent">.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( eeeveeVeveVVVVe ) [ 0 ] . replace ( ' Episodes' , '' ) . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
 iiiI11 = re . compile ( '<a title=".+?" href="(.+?)">.+?<div class="season">(.+?) </div>.+?<div class="episode">(.+?)</div>.+?<div class="e-name">(.+?)</div>' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
 for url , VVevevVe , VevVVVevVVeVevV , ii1 in iiiI11 :
  ii1 = ii1 . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  if '</div>' in name : name = 'TBA'
  VVVevV ( '%s ' % eVVevVevevVeevVeve + '(%s ' % VVevevVe + '%s)' % VevVVVevVVeVevV , url , 24 , iconimage , iconimage )
  if 35 - 35: iiIIiIiIi * i1IIiiiii / iIii1I11I1II1 - Veeev / VeeeeeeeVV - Vevev
def II1I1iiIII ( name , url , iconimage , fanart ) :
 i11iIIIIIi1 = name
 eeeveeVeveVVVVe = eevevVev ( url )
 eVVeevVeveve = re . compile ( '<a target="_blank" href=".+?" data-episodeid=".+?" data-linkid=".+?" data-hostname=".+?" class="watch-button" data-actuallink="(.+?)">Watch Now!</a>' ) . findall ( eeeveeVeveVVVVe )
 i1i = 1
 iiII1i1 = [ ]
 eeveveVVeve = [ ]
 for iIiIi11 in eVVeevVeveve :
  eevVVV = Ii1I1IIii1II ( iIiIi11 )
  if 'http' in iIiIi11 : VVViiiiI = iIiIi11 . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : VVViiiiI = iIiIi11
  name = "Link " + str ( i1i ) + ' | ' + VVViiiiI + eevVVV
  if VVViiiiI != 'www' :
   Vevii1ii1ii ( VVViiiiI , iIiIi11 , 2 , iconimage , fanart , description = '' )
   if 62 - 62: VeeeeeeeVV * II1ii
def eVVVeeevVeveV ( name , url , iconimage , fanart ) :
 eeeveeVeveVVVVe = eevevVev ( url )
 VV = re . compile ( '<td height="20">(.+?)</td>.+?<td>(.+?)</td>.+?<td><a href=".+?">(.+?)</a></td>.+?<td><a href=".+?">(.+?)</a></td>.+?</tr>' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
 for iIII1I111III , name , IIeeveevVevVeveveVVe , iIIIiIi in VV :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  VVVevV ( '[COLOR yellow]%s[/COLOR] - ' % IIeeveevVevVeveveVVe + '[COLOR yellow]%s[/COLOR] ' % name + '- [COLOR white]%s[/COLOR]' % iIII1I111III , url , 28 , iconimage , fanart )
  if 100 - 100: II1ii / Veeev % II111iiii % eeveVeVeveve % i1iIIIiI1I
def VeveveVevevevVevV ( url ) :
 I1i1i1iii = ''
 I1111i = xbmc . Keyboard ( I1i1i1iii , '[B][COLOR yellow]S[/COLOR][COLOR white]earch[/COLOR][/B] [B][COLOR yellow]E[/COLOR][COLOR white]volve[/COLOR][/B]' )
 I1111i . doModal ( )
 if I1111i . isConfirmed ( ) :
  I1i1i1iii = I1111i . getText ( ) . replace ( ' ' , '+' ) . replace ( '+and+' , '+%26+' )
 if len ( I1i1i1iii ) > 1 :
  url = 'http://www.watchepisodes4.com/search/ajax_search?q=' + I1i1i1iii
  eeeveeVeveVVVVe = eevevVev ( url )
  VVeVeveve = json . loads ( eeeveeVeveVVVVe )
  VVeVeveve = VVeVeveve [ 'series' ]
  for VVeeV in VVeVeveve :
   II111iiiiII = VVeeV [ 'value' ]
   iIIii = VVeeV [ 'seo' ]
   url = 'http://www.watchepisodes4.com/' + iIIii
   VeeevevVevevVevVevV = 'http://www.watchepisodes4.com/movie_images/' + iIIii + '.jpg'
   VVVevV ( II111iiiiII , url , 31 , VeeevevVevevVevVevV , VevV )
  I1i1i1iii = I1i1i1iii [ : - 1 ]
  eeeveeVeveVVVVe = eVevevevVeVeeeveve ( 'http://matsbuilds.uk/anewEvolvemenu/search.xml' )
  eevevVevV = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeveeVeveVVVVe )
  for url in eevevVevV :
   try :
    eeeveeVeveVVVVe = eVevevevVeVeeeveve ( url )
    ii1iii1i = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeveeVeveVVVVe )
    for VVeeV in ii1iii1i :
     iiiI11 = re . compile ( '<title>(.+?)</title>' ) . findall ( VVeeV )
     for i11iIIIIIi1 in iiiI11 :
      i11iIIIIIi1 = eeveevVVVeveev ( i11iIIIIIi1 . upper ( ) )
      I1i1i1iii = I1i1i1iii . upper ( )
      if I1i1i1iii in i11iIIIIIi1 :
       iI ( II111iiiiII , url , VeeevevVevevVevVevV , VevV , VVeeV )
   except : pass
   if 35 - 35: II111iiii % i1iIIIiI1I . i11I1 + i11I1 % II111iiii % II111iiii
   if 72 - 72: II111iiii + i1IIi + Veeev
def VVVIIiI1i1i ( name , url , iconimage , fanart ) :
 eeeveeVeveVVVVe = eevevVev ( url )
 VV = re . compile ( '<h2 id=".+?">(.+?)</h2>.+?<p><span class="article__image article__image--undefined"><img src="(.+?)" alt=".+?"></span> </p>.+?<p><strong>(.+?)</strong>(.+?)<' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
 for i11iIIIIIi1 , iconimage , VevevVeev , IIeeveevVevVeveveVVe in VV :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  VVVevV ( '[COLOR yellow]%s [/COLOR] ' % i11iIIIIIi1 + '[COLOR yellow]%s[/COLOR]' % VevevVeev + '[COLOR white]%s[/COLOR]' % IIeeveevVevVeveveVVe , url , 35 , iconimage , fanart )
def IiII111i1i11 ( name , url , iconimage , fanart ) :
 eeeveeVeveVVVVe = eVevevevVeVeeeveve ( 'http://matsbuilds.uk/Menus/Movies/EvolveLatest/mainmenu.xml' )
 VV = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeveeVeveVVVVe )
 for VVeeV in VV :
  iI ( name , url , iconimage , fanart , VVeeV )
  if 40 - 40: i11I1 * VeveeeeevVeevev * i11iIiiIii
  if 57 - 57: i11I1
  if 29 - 29: eeev - VeveeeeevVeevev * VeeeeeeeVV + VeeeeeeeVV . II111iiii + VeeeeeeeVV
  if 74 - 74: VeeVeVevVe - VeveeeeevVeevev / iiIIiIiIi * Vev - i1iIIIiI1I
  if 19 - 19: II1ii
def i11i ( name , url , iconimage , fanarts ) :
 eeeveeVeveVVVVe = Ii1I1i ( url )
 VV = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
 for url , name , iconimage in VV :
  VVVevV ( name , url , 46 , iconimage , iconimage )
  if 73 - 73: i1iIIIiI1I
def eeV ( name , url , iconimage , fanarts ) :
 eeeveeVeveVVVVe = Ii1I1i ( url )
 VV = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
 for url , name , iconimage in VV :
  VVVevV ( name , url , 46 , iconimage , iconimage )
  if 51 - 51: II1ii % Vevev . i1IIiiiii / iIii1I11I1II1 / VeVevevev . i1IIiiiii
def IIIii11 ( name , url , iconimage , fanarts ) :
 eeeveeVeveVVVVe = Ii1I1i ( url )
 VV = re . compile ( '<div class="thumb">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image"' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
 for url , name , iconimage in VV :
  VVVevV ( name , url , 46 , iconimage , iconimage )
  if 9 - 9: Vev % Vev - Veeev
def VeV ( name , url , iconimage , fanarts ) :
 iiII1i1 = [ ]
 eeveveVVeve = [ ]
 iiI1IIIi = [ ]
 eeeveeVeveVVVVe = eevevVev ( url )
 eVVeevVeveve = re . compile ( '<a href="(.+?)" title=".+?" rel="nofollow" target="blank">.+?</a><br/>' ) . findall ( eeeveeVeveVVVVe )
 i1i = 1
 iiII1i1 = [ ]
 eeveveVVeve = [ ]
 for iIiIi11 in eVVeevVeveve :
  eevVVV = Ii1I1IIii1II ( iIiIi11 )
  if '//' in iIiIi11 : VVViiiiI = iIiIi11 . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : VVViiiiI = iIiIi11
  name = "Link " + str ( i1i ) + ' | ' + VVViiiiI + eevVVV
  if VVViiiiI != 'www' :
   Vevii1ii1ii ( VVViiiiI , iIiIi11 , 2 , iconimage , VevV , description = '' )
   if 47 - 47: eeveVeVeveve % VeVevevev % i11iIiiIii - Vev + i11I1
   if 94 - 94: Vevev
def VVVevVVVevevee ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<lbscraper>(.+?)</lbscraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 VVVevV ( name , url , 10 , iconimage , fanart )
 if 4 - 4: VeeVeVevVe % i1IIiiiii * iIi1IIii11I
def eevVevVVVVeVVev ( name , url , iconimage , fanart ) :
 VevevVeveVVevevVevev = iiVeveVeeveve ( name , url , iconimage )
 iiiI11 = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( VevevVeveVVevevVevev )
 for VVeeV in iiiI11 :
  iI ( name , url , iconimage , fanart , VVeeV )
  if 81 - 81: VeveeeeevVeevev % i1IIi . iIii1I11I1II1
def iiVeveVeeveve ( name , url , iconimage ) :
 I1IiiiiI = url
 Ii1Iii1iIi = ''
 if url == 'mamahd' :
  eeeveeVeveVVVVe = Ii1I1i ( "http://mamahd.com" ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
  VVevee = re . compile ( '<a href="(.+?)">.+?<img src="(.+?)"></div>.+?<div class="home cell">.+?<span>(.+?)</span>.+?<span>(.+?)</span>.+?</a>' ) . findall ( eeeveeVeveVVVVe )
  for url , iconimage , Iii1 , VVVeveveveveV in VVevee :
   Ii1Iii1iIi = Ii1Iii1iIi + '<item>\n<title>%s vs %s</title>\n<sportsdevil>%s</sportsdevil>\n<thumbnail>%s</thumbnail>\n<fanart>fanart</fanart>\n</item>\n\n' % ( Iii1 , VVVeveveveveV , url , iconimage )
  return Ii1Iii1iIi
  if 15 - 15: eeev % II1ii * VeVevevev
 elif url == 'cricfree' :
  eeeveeVeveVVVVe = Ii1I1i ( "http://cricfree.sc/football-live-stream" )
  VevVeeeVev = re . compile ( '<td><span class="sport-icon(.+?)</tr>' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
  for eeeevVeveevevV in VevVeeeVev :
   I1i11 = re . compile ( '<td>(.+?)<br(.+?)</td>' ) . findall ( eeeevVeveevevV )
   for IiIi1I1 , IIeeveevVevVeveveVVe in I1i11 :
    IiIi1I1 = '[COLOR yellow]' + IiIi1I1 + '[/COLOR]'
    IIeeveevVevVeveveVVe = IIeeveevVevVeveveVVe . replace ( '>' , '' )
   iIIIiIi = re . compile ( '<td class="matchtime" style="color:#545454;font-weight:bold;font-size: 9px">(.+?)</td>' ) . findall ( eeeevVeveevevV ) [ 0 ]
   iIIIiIi = '[COLOR white](' + iIIIiIi + ')[/COLOR]'
   IiIIi1 = re . compile ( '<a style="text-decoration:none !important;color:#545454;" href="(.+?)" target="_blank">(.+?)</a></td>' ) . findall ( eeeevVeveevevV )
   for url , IIIIiii1IIii in IiIIi1 :
    url = url
    IIIIiii1IIii = IIIIiii1IIii
   Ii1Iii1iIi = Ii1Iii1iIi + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( IiIi1I1 + ' ' + iIIIiIi + ' - ' + IIIIiii1IIii , url )
   Ii1Iii1iIi = Ii1Iii1iIi + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return Ii1Iii1iIi
  if 38 - 38: i1iIIIiI1I + II111iiii % i11I1 % eeev - VeeVeVevVe / VeeeeeeeVV
 elif url == 'bigsports' :
  eeeveeVeveVVVVe = Ii1I1i ( "http://www.bigsports.me/cat/4/football-live-stream.html" )
  VVevee = re . compile ( '<td>.+?<td>(.+?)\-(.+?)\-(.+?)</td>.+?<td>(.+?)\:(.+?)</td>.+?<td>Football</td>.+?<td><strong>(.+?)</strong></td>.+?<a target=.+? href=(.+?) class=.+?' , re . DOTALL ) . findall ( eeeveeVeveVVVVe )
  for IiIi1I1 , eVVeeevevevevVeveev , II1III , III1 , VeeeeVeveVVVV , name , url in VVevee :
   if not '</td>' in IiIi1I1 :
    url = url . replace ( '"' , '' )
    IIeeveevVevVeveveVVe = IiIi1I1 + ' ' + eVVeeevevevevVeveev + ' ' + II1III
    iIIIiIi = III1 + ':' + VeeeeVeveVVVV
    IIeeveevVevVeveveVVe = '[COLOR yellow]' + IIeeveevVevVeveveVVe + '[/COLOR]'
    iIIIiIi = '[COLOR cyan](' + iIIIiIi + ')[/COLOR]'
    Ii1Iii1iIi = Ii1Iii1iIi + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( IIeeveevVevVeveveVVe + ' ' + iIIIiIi + ' ' + name , url )
    Ii1Iii1iIi = Ii1Iii1iIi + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return Ii1Iii1iIi
  if 100 - 100: iiIIiIiIi % i1iIIIiI1I
def iiii11I ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 VVViII1 = re . compile ( '<oktitle>(.+?)</oktitle>' ) . findall ( item ) [ 0 ]
 VVe = re . compile ( '<line1>(.+?)</line1>' ) . findall ( item ) [ 0 ]
 IIii11Ii1i1I = re . compile ( '<line2>(.+?)</line2>' ) . findall ( item ) [ 0 ]
 VeeeevV = re . compile ( '<line3>(.+?)</line3>' ) . findall ( item ) [ 0 ]
 eeevevVeveVevVev = '##' + VVViII1 + '#' + VVe + '#' + IIii11Ii1i1I + '#' + VeeeevV + '##'
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 eevVeveevVe ( name , eeevevVeveVevVev , 17 , iconimage , fanart )
 if 96 - 96: i11iIiiIii % i11I1 / eeev
def I1IiI11 ( name , url ) :
 iI1iiiiIii = re . compile ( '##(.+?)##' ) . findall ( url ) [ 0 ] . split ( '#' )
 i1Ii = xbmcgui . Dialog ( )
 i1Ii . ok ( iI1iiiiIii [ 0 ] , iI1iiiiIii [ 1 ] , iI1iiiiIii [ 2 ] , iI1iiiiIii [ 3 ] )
 if 19 - 19: iIi1IIii11I - eeveVeVeveve . Vev
def Iii111II ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<redirect>(.+?)</redirect>' ) . findall ( item ) [ 0 ]
 iIi1ii1I1 ( 'name' , url , 'iconimage' , 'fanart' )
 if 60 - 60: II111iiii + eeveVeVeveve
def VeVe ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 eeevevVeveVevVev = re . compile ( '<text>(.+?)</text>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 eevVeveevVe ( name , eeevevVeveVevVev , 9 , iconimage , fanart )
 if 9 - 9: i11I1 * VeeeeeeeVV - iIii1I11I1II1 + eeev / iIi1IIii11I . iIi1IIii11I
def iiIIi ( name , url ) :
 iiI1iI111ii1i = eevevVev ( url )
 Ii1IIiI1IiIII ( name , iiI1iI111ii1i )
 if 69 - 69: eeev * iIi1IIii11I % i1iIIIiI1I / iiIIiIiIi
def eVVeveveVV ( name , url , iconimage , fanart , item ) :
 eVeVeveve = re . compile ( '<image>(.+?)</image>' ) . findall ( item )
 if len ( eVeVeveve ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  eVevevVev = re . compile ( '<image>(.+?)</image>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  eevVeveevVe ( name , eVevevVev , 7 , iconimage , fanart )
 elif len ( eVeVeveve ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  IIi1IIIi = ''
  for eVevevVev in eVeVeveve : IIi1IIIi = IIi1IIIi + '<image>' + eVevevVev + '</image>'
  VevevVee = I1i1iiI1
  name = eeveevVVVeveev ( name )
  VVVVevVVV = os . path . join ( os . path . join ( VevevVee , '' ) , name + '.txt' )
  if not os . path . exists ( VVVVevVVV ) : file ( VVVVevVVV , 'w' ) . close ( )
  i1i1ii = open ( VVVVevVVV , "w" )
  i1i1ii . write ( IIi1IIIi )
  i1i1ii . close ( )
  eevVeveevVe ( name , 'image' , 8 , iconimage , fanart )
  if 46 - 46: eeev + iIi1IIii11I
def I1I ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<iptv>(.+?)</iptv>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 VVVevV ( name , url , 6 , iconimage , fanart )
 if 70 - 70: iiIIiIiIi / iIii1I11I1II1
def VeeveeeVeveV ( url , iconimage ) :
 eeeveeVeveVVVVe = eevevVev ( url )
 IiIiII1 = re . compile ( '^#.+?:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( eeeveeVeveVVVVe )
 Iii1iiIi1II = [ ]
 for VVevVeveveVe , II111iiiiII , url in IiIiII1 :
  ii1II = { "params" : VVevVeveveVe , "name" : II111iiiiII , "url" : url }
  Iii1iiIi1II . append ( ii1II )
 list = [ ]
 for iIII1I111III in Iii1iiIi1II :
  ii1II = { "name" : iIII1I111III [ "name" ] , "url" : iIII1I111III [ "url" ] }
  IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iIII1I111III [ "params" ] )
  for iI1I , VeeVeVe in IiIiII1 :
   ii1II [ iI1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = VeeVeVe . strip ( )
  list . append ( ii1II )
 for iIII1I111III in list :
  if '.ts' in iIII1I111III [ "url" ] : eevVeveevVe ( iIII1I111III [ "name" ] , iIII1I111III [ "url" ] , 2 , iconimage , VevV )
  else : Vevii1ii1ii ( iIII1I111III [ "name" ] , iIII1I111III [ "url" ] , 2 , iconimage , VevV )
  if 14 - 14: Veeev * i1iIIIiI1I + iiIIiIiIi + Vev + i11iIiiIii
def IIIii1II1II ( name , url , iconimage , fanart , item ) :
 eevVVV = ''
 eVeVev = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 VVeVeveve = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , Veev , iconimage , fanart in VVeVeveve :
  if 'youtube.com/playlist?' in Veev :
   I1i1i1iii = Veev . split ( 'list=' ) [ 1 ]
   VVVevV ( name , Veev , eeevVeveeveveevV , iconimage , fanart , description = I1i1i1iii )
 if len ( eVeVev ) == 1 :
  VVeVeveve = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
  for name , url , iconimage , fanart in VVeVeveve :
   try :
    eevVVV = Ii1I1IIii1II ( url )
    I11i1II = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
    if 'SportsDevil' in url : I11i1II = ''
   except : pass
   if '.ts' in url : Vevii1ii1ii ( name , url , 16 , iconimage , fanart , description = '' )
   if '<meta>' in item :
    ii1I = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
    IIiII ( name + eevVVV , url , 2 , iconimage , 10 , ii1I , isFolder = False )
   else :
    Vevii1ii1ii ( name + eevVVV , url , 2 , iconimage , fanart )
 elif len ( eVeVev ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  if '.ts' in url : Vevii1ii1ii ( name , url , 16 , iconimage , fanart , description = '' )
  if '<meta>' in item :
   ii1I = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
   IIiII ( name , url , 3 , iconimage , len ( eVeVev ) , ii1I , isFolder = True )
  else :
   VVVevV ( name , url , 3 , iconimage , fanart )
   if 72 - 72: iIii1I11I1II1 . i1IIi / eeveVeVeveve . II111iiii
   if 54 - 54: II111iiii % II111iiii
def I1i1I1II ( name , url , iconimage , fanart , item ) :
 eVeVev = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item )
 Veeveveveveveeve = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 if len ( eVeVev ) + len ( Veeveveveveveeve ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item ) [ 0 ]
  url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url
  eevVeveevVe ( name , url , 16 , iconimage , fanart )
 elif len ( eVeVev ) + len ( Veeveveveveveeve ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  VVVevV ( name , url , 3 , iconimage , fanart )
  if 72 - 72: i1iIIIiI1I % eeeveveveveveev + iIi1IIii11I / i1IIiiiii + VeveeeeevVeevev
def eeeeeeVevee ( link ) :
 if Iii1ii1II11i == '' :
  i1Ii = xbmcgui . Dialog ( )
  ii111iI1iIi1 = i1Ii . yesno ( 'Adult Content' , 'You have found the goodies ;)' , '' , 'Please set a password to prevent accidental access' , 'Cancel' , 'OK' )
  if ii111iI1iIi1 == 1 :
   IIII = xbmc . Keyboard ( '' , 'Set Password' )
   IIII . doModal ( )
   if ( IIII . isConfirmed ( ) ) :
    I1I1i = IIII . getText ( )
    eevVeVeVVevev . setSetting ( 'password' , I1I1i )
  else : quit ( )
 elif Iii1ii1II11i <> '' :
  i1Ii = xbmcgui . Dialog ( )
  ii111iI1iIi1 = i1Ii . yesno ( 'Adult Content' , 'Please enter the password you set!' , 'to continue' , 'dirty git' , 'Cancel' , 'OK' )
  if ii111iI1iIi1 == 1 :
   IIII = xbmc . Keyboard ( '' , 'Enter Password' )
   IIII . doModal ( )
   if ( IIII . isConfirmed ( ) ) :
    I1I1i = IIII . getText ( )
   if I1I1i <> Iii1ii1II11i :
    quit ( )
  else : quit ( )
  if 1 - 1: VeVevevev % i1iIIIiI1I + Vev + i1IIi - iIi1IIii11I
def iIIIII1ii1I ( name , url , iconimage ) :
 Ii1i1iI = ''
 iI11i1I1 = eeveevVVVeveev ( name )
 eevVeVeVVevev . setSetting ( 'tv' , iI11i1I1 )
 eeeveeVeveVVVVe = eVevevevVeVeeeveve ( url )
 IIiI1 = re . compile ( '<title>.*?' + re . escape ( name ) + '.*?</title>(.+?)</item>' , re . DOTALL ) . findall ( eeeveeVeveVVVVe ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiI1 ) [ 0 ]
 eVeVev = [ ]
 if '<link>' in IIiI1 :
  i1iI1 = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiI1 )
  for ii1I1IiiI1ii1i in i1iI1 :
   eVeVev . append ( ii1I1IiiI1ii1i )
 if '<sportsdevil>' in IIiI1 :
  Veve = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiI1 )
  for eVevVeVeveve in Veve :
   eVevVeVeveve = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + eVevVeVeveve
   eVeVev . append ( eVevVeVeveve )
 i1i = 1
 for eeeveeVeveVVVVe in eVeVev :
  if '(' in eeeveeVeveVVVVe :
   eeeveeVeveVVVVe = eeeveeVeveVVVVe . split ( '(' )
   Ii1i1iI = eeeveeVeveVVVVe [ 1 ] . replace ( ')' , '' )
   eeeveeVeveVVVVe = eeeveeVeveVVVVe [ 0 ]
  eevVVV = Ii1I1IIii1II ( eeeveeVeveVVVVe )
  I11i1II = eeeveeVeveVVVVe . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  if Ii1i1iI <> '' : name = "Link " + str ( i1i ) + ' | ' + Ii1i1iI + eevVVV
  else : name = "Link " + str ( i1i ) + ' | ' + I11i1II + eevVVV
  i1i = i1i + 1
  IIiII ( name , eeeveeVeveVVVVe , 2 , iconimage , 10 , '' , isFolder = False , description = eevVeVeVVevev . getSetting ( 'tv' ) )
  if 11 - 11: eeveVeVeveve - II1ii * II111iiii . eeeveveveveveev . i1IIiiiii
def IiIiiI ( name , url , iconimage , fanart , item ) :
 VVeVeveve = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , url , iconimage , fanart in VVeVeveve :
  if 'youtube.com/channel/' in url :
   I1i1i1iii = url . split ( 'channel/' ) [ 1 ]
   VVVevV ( name , url , eeevVeveeveveevV , iconimage , fanart , description = I1i1i1iii )
  elif 'youtube.com/user/' in url :
   I1i1i1iii = url . split ( 'user/' ) [ 1 ]
   VVVevV ( name , url , eeevVeveeveveevV , iconimage , fanart , description = I1i1i1iii )
  elif 'youtube.com/playlist?' in url :
   I1i1i1iii = url . split ( 'list=' ) [ 1 ]
   VVVevV ( name , url , eeevVeveeveveevV , iconimage , fanart , description = I1i1i1iii )
  elif 'plugin://' in url :
   VevVeVVeveeev = HTMLParser ( )
   url = VevVeVVeveeev . unescape ( url )
   VVVevV ( name , url , eeevVeveeveveevV , iconimage , fanart )
  else :
   VVVevV ( name , url , 1 , iconimage , fanart )
   if 96 - 96: eeev . Veeev - i11I1
def VevVI11iiiii1II ( ) :
 IIII = xbmc . Keyboard ( '' , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 IIII . doModal ( )
 if ( IIII . isConfirmed ( ) ) :
  I1i1i1iii = IIII . getText ( )
  I1i1i1iii = I1i1i1iii . upper ( )
 else : quit ( )
 eeeveeVeveVVVVe = eVevevevVeVeeeveve ( 'http://matsbuilds.uk/anewEvolvemenu/search.xml' )
 eevevVevV = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeveeVeveVVVVe )
 for eVeVeeveveVe in eevevVevV :
  try :
   eeeveeVeveVVVVe = eVevevevVeVeeeveve ( eVeVeeveveVe )
   ii1iii1i = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeveeVeveVVVVe )
   for VVeeV in ii1iii1i :
    iiiI11 = re . compile ( '<title>(.+?)</title>' ) . findall ( VVeeV )
    for i11iIIIIIi1 in iiiI11 :
     i11iIIIIIi1 = i11iIIIIIi1 . upper ( )
     if I1i1i1iii in i11iIIIIIi1 :
      iI ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV , VVeeV )
  except : pass
  if 51 - 51: Vev % i1IIiiiii - II111iiii
def I1II ( url ) :
 Ii1Iii1iIi = "ShowPicture(%s)" % url
 xbmc . executebuiltin ( Ii1Iii1iIi )
 if 64 - 64: Vev % VeVevevev % Vev * iIi1IIii11I . i1IIiiiii + II1ii
def VevevI11ii1i1 ( name , url , iconimage , description ) :
 if description : name = description
 try :
  if 'plugin://plugin.video.SportsDevil/' in url :
   eeeevVeVVVVV ( name , url , iconimage )
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
   url = url . replace ( '|' , '' )
   eeeevVeVVVVV ( name , url , iconimage )
  elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   i1iIi1iI ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   i1iIi1iI ( name , url , iconimage )
  else : i1iIi1iI ( name , url , iconimage )
 except :
  i1I11IiI1iiII ( eeveveVeeveVee ( 'Picasso' ) , 'Stream Unavailable' , '3000' , I1ii11iIi11i )
  if 57 - 57: eeev - eeeveveveveveev
def IIIII ( url ) :
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 xbmc . Player ( ) . play ( url )
 if 50 - 50: Vevev / i1IIi % iIi1IIii11I . II1ii / iiIIiIiIi
def i1iIi1iI ( name , url , iconimage ) :
 VeVVevevev = True
 VVV = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; VVV . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 VeVVevevev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = VVV )
 VVV . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , VVV )
 if 88 - 88: i1iIIIiI1I . VeVevevev * Veeev . eeev / i11I1 . VeVevevev
def eeeevVeVVVVV ( name , url , iconimage ) :
 xbmc . executebuiltin ( 'Dialog.Close(all,True)' )
 VeVVevevev = True
 VVV = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage ) ; VVV . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 VeVVevevev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = VVV )
 xbmc . Player ( ) . play ( url , VVV , False )
 if 10 - 10: Veeev * eeveVeVeveve % Vev * iIii1I11I1II1 . Vev % eeeveveveveveev
def Iii1Veeeev ( url ) :
 xbmc . executebuiltin ( "PlayMedia(%s)" % url )
 if 59 - 59: VeeeeeeeVV
def eVevevevVeVeeeveve ( url ) :
 i1iiiii1 = urllib2 . Request ( url )
 i1iiiii1 . add_header ( 'User-Agent' , 'mat' )
 VeviII1 = urllib2 . urlopen ( i1iiiii1 )
 eeeveeVeveVVVVe = VeviII1 . read ( )
 VeviII1 . close ( )
 eeeveeVeveVVVVe = eeeveeVeveVVVVe . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 if '{' in eeeveeVeveVVVVe :
  Ii1Iii1iIi = eeeveeVeveVVVVe [ : : - 1 ]
  Ii1Iii1iIi = Ii1Iii1iIi . replace ( '}' , '' ) . replace ( '{' , '' ) . replace ( ',' , '' ) . replace ( ']' , '' ) . replace ( '[' , '' )
  Ii1Iii1iIi = Ii1Iii1iIi + '=='
  eeeveeVeveVVVVe = Ii1Iii1iIi . decode ( 'base64' )
 if url <> VeveeevVVev : eeeveeVeveVVVVe = eeeveeVeveVVVVe . replace ( '\n' , '' ) . replace ( '\r' , '' )
 print eeeveeVeveVVVVe
 return eeeveeVeveVVVVe
 if 27 - 27: iIi1IIii11I . VeVevevev + eeev / iIii1I11I1II1 % iiIIiIiIi . i11I1
def eevevVev ( url ) :
 i1iiiii1 = urllib2 . Request ( url )
 i1iiiii1 . add_header ( 'User-Agent' , 'mat' )
 VeviII1 = urllib2 . urlopen ( i1iiiii1 )
 eeeveeVeveVVVVe = VeviII1 . read ( )
 VeviII1 . close ( )
 return eeeveeVeveVVVVe
 if 14 - 14: i1IIiiiii + eeeveveveveveev - iiIIiIiIi / Vev . Vevev
def Ii1I1i ( url ) :
 i1iiiii1 = urllib2 . Request ( url )
 i1iiiii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 VeviII1 = urllib2 . urlopen ( i1iiiii1 )
 eeeveeVeveVVVVe = VeviII1 . read ( )
 VeviII1 . close ( )
 eeeveeVeveVVVVe = eeeveeVeveVVVVe . replace ( '\n' , '' ) . replace ( '\r' , '' )
 return eeeveeVeveVVVVe
 if 45 - 45: Vevev
 if 83 - 83: eeev . VeeeeeeeVV
def Veeveee ( ) :
 IIiIiiii = [ ]
 VevevevevVVVev = sys . argv [ 2 ]
 if len ( VevevevevVVVev ) >= 2 :
  VVevVeveveVe = sys . argv [ 2 ]
  eeeev = VVevVeveveVe . replace ( '?' , '' )
  if ( VVevVeveveVe [ len ( VVevVeveveVe ) - 1 ] == '/' ) :
   VVevVeveveVe = VVevVeveveVe [ 0 : len ( VVevVeveveVe ) - 2 ]
  eVeveveveVeeveveeve = eeeev . split ( '&' )
  IIiIiiii = { }
  for i1i in range ( len ( eVeveveveVeeveveeve ) ) :
   VeveveVev = { }
   VeveveVev = eVeveveveVeeveveeve [ i1i ] . split ( '=' )
   if ( len ( VeveveVev ) ) == 2 :
    IIiIiiii [ VeveveVev [ 0 ] ] = VeveveVev [ 1 ]
 return IIiIiiii
 if 70 - 70: VeVevevev . eeeveveveveveev * VeeeeeeeVV - VeveeeeevVeevev * II1ii + eeev
def i1I11IiI1iiII ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 10 - 10: Veeev / i11iIiiIii
def eeveevVVVeveev ( string ) :
 eeveveV = re . compile ( '(\[.+?\])' ) . findall ( string )
 for VevevVevVeeeeevev in eeveveV : string = string . replace ( VevevVevVeeeeevev , '' )
 return string
 if 97 - 97: i11I1 / Vevev % i1IIi % eeeveveveveveev
def eeveveVeeveVee ( string ) :
 string = string . split ( ' ' )
 ii111I11iI = ''
 for VVeve in string :
  eeeveevVevVeeeee = '[B][COLOR yellow]' + VVeve [ 0 ] . upper ( ) + '[/COLOR][COLOR white]' + VVeve [ 1 : ] + '[/COLOR][/B] '
  ii111I11iI = ii111I11iI + eeeveevVevVeeeee
 return ii111I11iI
 if 1 - 1: i11I1 % eeev * eeveVeVeveve
def IIiII ( name , url , mode , iconimage , itemcount , metatype , isFolder = False , description = '' ) :
 if isFolder == True : eevVeVeVVevev . setSetting ( 'favtype' , 'folder' )
 else : eevVeVeVVevev . setSetting ( 'favtype' , 'link' )
 if iI111iI == 'true' :
  eevVeveeev = name
  name = eeveevVVVeveev ( name )
  iiiI1I1iIIIi1 = ""
  Iii = ""
  I1iiiiI1iI = [ ]
  iIiiiii1i = eval ( base64 . b64decode ( 'bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ==' ) )
  Ii11iII1 = { }
  if metatype == 'movie' :
   VVVevevV = name . partition ( '(' )
   if len ( VVVevevV ) > 0 :
    iiiI1I1iIIIi1 = VVVevevV [ 0 ]
    Iii = VVVevevV [ 2 ] . partition ( ')' )
   if len ( Iii ) > 0 :
    Iii = Iii [ 0 ]
   Ii11iII1 = iIiiiii1i . get_meta ( 'movie' , name = iiiI1I1iIIIi1 , year = Iii )
   if not Ii11iII1 [ 'trailer' ] == '' : I1iiiiI1iI . append ( ( eeveveVeeveVee ( 'Play Trailer' ) , 'XBMC.RunPlugin(%s)' % iIiiiI1IiI1I1 . build_plugin_url ( { 'mode' : 11 , 'url' : Ii11iII1 [ 'trailer' ] } ) ) )
  elif metatype == 'tvep' :
   i11iIIIIIi1 = eevVeVeVVevev . getSetting ( 'tv' )
   if '<>' in url :
    print url
    i1Veevev = url . split ( '<>' ) [ 0 ]
    Veveev = url . split ( '<>' ) [ 1 ]
    VVevevVe = url . split ( '<>' ) [ 2 ]
    VevVVVevVVeVevV = url . split ( '<>' ) [ 3 ]
    VevevVeeveveveeVev = url . split ( '<>' ) [ 4 ]
    VeVevVevev = url . split ( '<>' ) [ 5 ]
    Ii11iII1 = iIiiiii1i . get_episode_meta ( Veveev , imdb_id = i1Veevev , season = VVevevVe , episode = VevVVVevVVeVevV , air_date = '' , episode_title = '' , overlay = '' )
   else :
    iiIi1IIiI = re . compile ( 'Season (.+?) Episode (.+?)\)' ) . findall ( name )
    for i1eVevVVev , eevVevVeevev in iiIi1IIiI :
     Ii11iII1 = iIiiiii1i . get_episode_meta ( i11iIIIIIi1 , imdb_id = '' , season = i1eVevVVev , episode = eevVevVeevev , air_date = '' , episode_title = '' , overlay = '' )
  try :
   if Ii11iII1 [ 'cover_url' ] == '' : iconimage = iconimage
   else : iconimage = Ii11iII1 [ 'cover_url' ]
  except : pass
  I1I1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( VevV ) + "&iconimage=" + urllib . quote_plus ( iconimage )
  VeVVevevev = True
  VVV = xbmcgui . ListItem ( eevVeveeev , iconImage = iconimage , thumbnailImage = iconimage )
  VVV . setInfo ( type = "Video" , infoLabels = Ii11iII1 )
  VVV . setProperty ( "IsPlayable" , "true" )
  VVV . addContextMenuItems ( I1iiiiI1iI , replaceItems = False )
  if not Ii11iII1 . get ( 'backdrop_url' , '' ) == '' : VVV . setProperty ( 'fanart_image' , Ii11iII1 [ 'backdrop_url' ] )
  else : VVV . setProperty ( 'fanart_image' , VevV )
  VevVeeveeveveveV = eevVeVeVVevev . getSetting ( 'favlist' )
  eVeveeveveVVeeVev = [ ]
  eVeveeveveVVeeVev . append ( ( eeveveVeeveVee ( 'Stream Information' ) , 'XBMC.Action(Info)' ) )
  if VevVeeveeveveveV == 'yes' : eVeveeveveVVeeVev . append ( ( '[COLOR cyan]Remove From Keep Safe? [/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  else : eVeveeveveVVeeVev . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  VVV . addContextMenuItems ( eVeveeveveVVeeVev , replaceItems = False )
  VeVVevevev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1I1I , listitem = VVV , isFolder = isFolder , totalItems = itemcount )
  return VeVVevevev
 else :
  if isFolder :
   VVVevV ( name , url , mode , iconimage , VevV , description = '' )
  else :
   Vevii1ii1ii ( name , url , mode , iconimage , VevV , description = '' )
   if 79 - 79: iIi1IIii11I - iIii1I11I1II1 + VeeVeVevVe - Vevev
def VVVevV ( name , url , mode , iconimage , fanart , description = '' ) :
 eevVeVeVVevev . setSetting ( 'favtype' , 'folder' )
 I1I1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 VeVVevevev = True
 VVV = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 VVV . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 VVV . setProperty ( 'fanart_image' , fanart )
 if 'youtube.com/channel/' in url :
  I1I1I = 'plugin://plugin.video.youtube/channel/' + description + '/'
 if 'youtube.com/user/' in url :
  I1I1I = 'plugin://plugin.video.youtube/user/' + description + '/'
 if 'youtube.com/playlist?' in url :
  I1I1I = 'plugin://plugin.video.youtube/playlist/' + description + '/'
 if 'plugin://' in url :
  I1I1I = url
 eVeveeveveVVeeVev = [ ]
 VevVeeveeveveveV = eevVeVeVVevev . getSetting ( 'favlist' )
 if VevVeeveeveveveV == 'yes' : eVeveeveveVVeeVev . append ( ( '[COLOR cyan]Remove From Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : eVeveeveveVVeeVev . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 VVV . addContextMenuItems ( eVeveeveveVVeeVev , replaceItems = False )
 VeVVevevev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1I1I , listitem = VVV , isFolder = True )
 return VeVVevevev
 if 93 - 93: II111iiii . II1ii - eeveVeVeveve + eeev
def eevVeveevVe ( name , url , mode , iconimage , fanart , description = '' ) :
 eevVeVeVVevev . setSetting ( 'favtype' , 'link' )
 I1I1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 VeVVevevev = True
 VVV = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 VVV . setProperty ( 'fanart_image' , fanart )
 eVeveeveveVVeeVev = [ ]
 VevVeeveeveveveV = eevVeVeVVevev . getSetting ( 'favlist' )
 if VevVeeveeveveveV == 'yes' : eVeveeveveVVeeVev . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : eVeveeveveVVeeVev . append ( ( '[COLOR cyan]Add to Keeo Safe[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 VVV . addContextMenuItems ( eVeveeveveVVeeVev , replaceItems = False )
 VeVVevevev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1I1I , listitem = VVV , isFolder = False )
 return VeVVevevev
 if 61 - 61: II111iiii
def Vevii1ii1ii ( name , url , mode , iconimage , fanart , description = '' ) :
 eevVeVeVVevev . setSetting ( 'favtype' , 'link' )
 I1I1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 VeVVevevev = True
 VVV = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 VVV . setProperty ( 'fanart_image' , fanart )
 VVV . setProperty ( "IsPlayable" , "true" )
 eVeveeveveVVeeVev = [ ]
 VevVeeveeveveveV = eevVeVeVVevev . getSetting ( 'favlist' )
 if VevVeeveeveveveV == 'yes' : eVeveeveveVVeeVev . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : eVeveeveveVVeeVev . append ( ( '[COLOR cyan]Add to Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 VVV . addContextMenuItems ( eVeveeveveVVeeVev , replaceItems = False )
 VeVVevevev = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1I1I , listitem = VVV , isFolder = False )
 return VeVVevevev
 if 15 - 15: i11iIiiIii % II1ii * VeVevevev / Vevev
def Iiii ( url , name ) :
 eeeVeveeveevVev = eevevVev ( url )
 if len ( eeeVeveeveevVev ) > 1 :
  VevevVee = I1i1iiI1
  VVVVevVVV = os . path . join ( os . path . join ( VevevVee , '' ) , name + '.txt' )
  if not os . path . exists ( VVVVevVVV ) :
   file ( VVVVevVVV , 'w' ) . close ( )
  iii11111I = open ( VVVVevVVV )
  ii11ii11 = iii11111I . read ( )
  if ii11ii11 == eeeVeveeveevVev : pass
  else :
   Ii1IIiI1IiIII ( '[B][COLOR yellow]PICASSO INFO[/COLOR][/B]' , eeeVeveeveevVev )
   i1i1ii = open ( VVVVevVVV , "w" )
   i1i1ii . write ( eeeVeveeveevVev )
   i1i1ii . close ( )
   if 25 - 25: VeVevevev * iiIIiIiIi / Veeev
def Ii1IIiI1IiIII ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 eV = xbmcgui . Window ( id )
 eVVeeveveveVeVev = 50
 while ( eVVeeveveveVeVev > 0 ) :
  try :
   xbmc . sleep ( 10 )
   eVVeeveveveVeVev -= 1
   eV . getControl ( 1 ) . setLabel ( heading )
   eV . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 86 - 86: II111iiii % i11iIiiIii + VeeVeVevVe % i11iIiiIii
def VeeeveevVVV ( name ) :
 global Icon
 global Next
 global Previous
 global window
 global Quit
 global images
 VVVVevVVV = os . path . join ( os . path . join ( I1i1iiI1 , '' ) , name + '.txt' )
 iii11111I = open ( VVVVevVVV )
 ii11ii11 = iii11111I . read ( )
 images = re . compile ( '<image>(.+?)</image>' ) . findall ( ii11ii11 )
 eevVeVeVVevev . setSetting ( 'pos' , '0' )
 window = pyxbmct . AddonDialogWindow ( '' )
 i11IiII = '/resources/art'
 eVeeeevVeve = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + i11IiII , 'next_focus.png' ) )
 Veevevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + i11IiII , 'next1.png' ) )
 VevevVeveVVe = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + i11IiII , 'previous_focus.png' ) )
 VeveV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + i11IiII , 'previous.png' ) )
 VVeveveveeeeev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + i11IiII , 'close_focus.png' ) )
 eVeVeveeveee = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + i11IiII , 'close.png' ) )
 eVeveevVevVeeeve = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + i11IiII , 'main-bg1.png' ) )
 window . setGeometry ( 1300 , 720 , 100 , 50 )
 i1Ii11II = pyxbmct . Image ( eVeveevVevVeeeve )
 window . placeControl ( i1Ii11II , - 10 , - 10 , 130 , 70 )
 eeevevVeveVevVev = '0xFF000000'
 Previous = pyxbmct . Button ( '' , focusTexture = VevevVeveVVe , noFocusTexture = VeveV , textColor = eeevevVeveVevVev , focusedColor = eeevevVeveVevVev )
 Next = pyxbmct . Button ( '' , focusTexture = eVeeeevVeve , noFocusTexture = Veevevev , textColor = eeevevVeveVevVev , focusedColor = eeevevVeveVevVev )
 Quit = pyxbmct . Button ( '' , focusTexture = VVeveveveeeeev , noFocusTexture = eVeVeveeveee , textColor = eeevevVeveVevVev , focusedColor = eeevevVeveVevVev )
 Icon = pyxbmct . Image ( images [ 0 ] , aspectRatio = 2 )
 window . placeControl ( Previous , 102 , 1 , 10 , 10 )
 window . placeControl ( Next , 102 , 40 , 10 , 10 )
 window . placeControl ( Quit , 102 , 21 , 10 , 10 )
 window . placeControl ( Icon , 0 , 0 , 100 , 50 )
 Previous . controlRight ( Next )
 Previous . controlUp ( Quit )
 window . connect ( Previous , IieVeveVVVevVee )
 window . connect ( Next , i1i1I )
 Previous . setVisible ( False )
 window . setFocus ( Quit )
 Previous . controlRight ( Quit )
 Quit . controlLeft ( Previous )
 Quit . controlRight ( Next )
 Next . controlLeft ( Quit )
 window . connect ( Quit , window . close )
 window . doModal ( )
 del window
 if 25 - 25: iIii1I11I1II1 + eeeveveveveveev + iiIIiIiIi / II111iiii / VeVevevev
def i1i1I ( ) :
 eevVevVeevevVeeve = int ( eevVeVeVVevev . getSetting ( 'pos' ) )
 VVVe = int ( eevVevVeevevVeeve ) + 1
 eevVeVeVVevev . setSetting ( 'pos' , str ( VVVe ) )
 eeevVVeevV = len ( images )
 Icon . setImage ( images [ int ( VVVe ) ] )
 Previous . setVisible ( True )
 if int ( VVVe ) == int ( eeevVVeevV ) - 1 :
  Next . setVisible ( False )
  if 39 - 39: VeeeeeeeVV + i1IIiiiii % i1iIIIiI1I / i1iIIIiI1I
def IieVeveVVVevVee ( ) :
 eevVevVeevevVeeve = int ( eevVeVeVVevev . getSetting ( 'pos' ) )
 I1i = int ( eevVevVeevevVeeve ) - 1
 eevVeVeVVevev . setSetting ( 'pos' , str ( I1i ) )
 Icon . setImage ( images [ int ( I1i ) ] )
 Next . setVisible ( True )
 if int ( I1i ) == 0 :
  Previous . setVisible ( False )
  if 72 - 72: iIii1I11I1II1
def iiIi ( url , fanart ) :
 eevVeVeVVevev . setSetting ( 'favlist' , 'yes' )
 eVIi111 = None
 file = open ( iiIIIII1i1iI , 'r' )
 eVIi111 = file . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 iiiI11 = re . compile ( "<item>(.+?)</item>" , re . DOTALL ) . findall ( eVIi111 )
 for VVeeV in iiiI11 :
  iI ( II111iiiiII , url , I1ii11iIi11i , fanart , VVeeV )
 eevVeVeVVevev . setSetting ( 'favlist' , 'no' )
 if 67 - 67: Vev
def Vee ( name , url , iconimage , fanart ) :
 eeeeeeve = eevVeVeVVevev . getSetting ( 'favtype' )
 url = url . replace ( ' ' , '%20' )
 iconimage = iconimage . replace ( ' ' , '%20' )
 if '<>' in url :
  i1Veevev = url . split ( '<>' ) [ 0 ]
  VVevevVe = url . split ( '<>' ) [ 1 ]
  VevVVVevVVeVevV = url . split ( '<>' ) [ 2 ]
  VevevVeeveveveeVev = url . split ( '<>' ) [ 3 ]
  VeVevVevev = url . split ( '<>' ) [ 4 ]
  Ii1Iii1iIi = '<FAV><item>\n<title>' + name + '</title>\n<meta>tvep</meta>\n<nan>tvshow</nan>\n<showyear>' + VevevVeeveveveeVev + '</showyear>\n<imdb>' + i1Veevev + '</imdb>\n<season>' + VVevevVe + '</season>\n<episode>' + VevVVVevVVeVevV + '</episode>\n<episodeyear>' + VeVevVevev + '</episodeyear>\n<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 elif len ( url ) == 9 :
  Ii1Iii1iIi = '<FAV><item>\n<title>' + name + '</title>\n<meta>movie</meta>\n<nan>movie</nan>\n<imdb>' + url + '</imdb>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 else :
  Ii1Iii1iIi = '<FAV><item>\n<title>' + name + '</title>\n<' + eeeeeeve + '>' + url + '</' + eeeeeeve + '>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 eevev = open ( iiIIIII1i1iI , 'a' )
 eevev . write ( Ii1Iii1iIi )
 eevev . close ( )
 if 74 - 74: VeeVeVevVe
def IiIII1i1i ( name , url , iconimage ) :
 print name
 eVIi111 = None
 file = open ( iiIIIII1i1iI , 'r' )
 eVIi111 = file . read ( )
 II11I = ''
 iiiI11 = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( eVIi111 )
 for VVeVeveve in iiiI11 :
  Ii1Iii1iIi = '\n<FAV><item>\n' + VVeVeveve + '</item>\n'
  if name in VVeVeveve :
   print 'xxxxxxxxxxxxxxxxx'
   Ii1Iii1iIi = Ii1Iii1iIi . replace ( 'item' , ' ' )
  II11I = II11I + Ii1Iii1iIi
 file = open ( iiIIIII1i1iI , 'w' )
 file . truncate ( )
 file . write ( II11I )
 file . close ( )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 80 - 80: i1iIIIiI1I
def Ii1I1IIii1II ( url ) :
 try :
  I11i1II = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  file = open ( eevVVV , 'r' )
  III = file . read ( )
  if I11i1II in III : return '[COLOR cyan] (RD)[/COLOR]'
  else : return ''
 except : return ''
 if 81 - 81: eeveVeVeveve / i11iIiiIii + iiIIiIiIi % iIii1I11I1II1 * Vevev
def iiI1II11II1i ( ) :
 xbmcaddon . Addon ( 'script.module.nanscrapers' ) . openSettings ( )
 if 67 - 67: i1iIIIiI1I + eeveVeVeveve
def VeVeeveveveVeevee ( ) :
 xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
 if 65 - 65: eeev / iIi1IIii11I % VeveeeeevVeevev
def iIiIIii ( ) :
 xbmcaddon . Addon ( 'script.module.metahandler' ) . openSettings ( )
 if 61 - 61: Veeev / i1iIIIiI1I / eeveVeVeveve * Vev
def eev ( link ) :
 try :
  iIII1i1i = re . compile ( '<layouttype>(.+?)</layouttype>' ) . findall ( link ) [ 0 ]
  if iIII1i1i == 'thumbnail' : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 except : pass
 if 35 - 35: II111iiii * VeVevevev - VeeeeeeeVV . VeVevevev . VeVevevev
 if 11 - 11: Vevev / eeev + VeVevevev % iIii1I11I1II1
VVevVeveveVe = Veeveee ( ) ; eVeVeeveveVe = None ; II111iiiiII = None ; eeevVeveeveveevV = None ; II1II1iIIi11 = None ; VeeevevVevevVevVevV = None ; IiI1iII1II111 = None
try : II1II1iIIi11 = urllib . unquote_plus ( VVevVeveveVe [ "site" ] )
except : pass
try : eVeVeeveveVe = urllib . unquote_plus ( VVevVeveveVe [ "url" ] )
except : pass
try : II111iiiiII = urllib . unquote_plus ( VVevVeveveVe [ "name" ] )
except : pass
try : eeevVeveeveveevV = int ( VVevVeveveVe [ "mode" ] )
except : pass
try : VeeevevVevevVevVevV = urllib . unquote_plus ( VVevVeveveVe [ "iconimage" ] )
except : pass
try : VevV = urllib . unquote_plus ( VVevVeveveVe [ "fanart" ] )
except : pass
try : IiI1iII1II111 = str ( VVevVeveveVe [ "description" ] )
except : pass
if 28 - 28: eeev * iIi1IIii11I . VeVevevev % VeVevevev / VeVevevev * Vevev
if eeevVeveeveveevV == None or eVeVeeveveVe == None or len ( eVeVeeveveVe ) < 1 : I11i1i11i1I ( )
elif eeevVeveeveveevV == 1 : iIi1ii1I1 ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 2 : VevevI11ii1i1 ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , IiI1iII1II111 )
elif eeevVeveeveveevV == 3 : iIIIII1ii1I ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV )
elif eeevVeveeveveevV == 4 : i1iIi1iI ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV )
elif eeevVeveeveveevV == 5 : VevVI11iiiii1II ( )
elif eeevVeveeveveevV == 6 : VeeveeeVeveV ( eVeVeeveveVe , VeeevevVevevVevVevV )
elif eeevVeveeveveevV == 7 : I1II ( eVeVeeveveVe )
elif eeevVeveeveveevV == 8 : VeeeveevVVV ( II111iiiiII )
elif eeevVeveeveveevV == 9 : iiIIi ( II111iiiiII , eVeVeeveveVe )
elif eeevVeveeveveevV == 10 : eevVevVVVVeVVev ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 11 : Iii1Veeeev ( eVeVeeveveVe )
elif eeevVeveeveveevV == 12 : VeVeeveveveVeevee ( )
elif eeevVeveeveveevV == 13 : iIiIIii ( )
elif eeevVeveeveveevV == 15 : SCRAPEMOVIE ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV )
elif eeevVeveeveveevV == 16 : eeeevVeVVVVV ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV )
elif eeevVeveeveveevV == 17 : I1IiI11 ( II111iiiiII , eVeVeeveveVe )
elif eeevVeveeveveevV == 18 : ee ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 19 : IIi ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
if 64 - 64: II111iiii - II1ii
elif eeevVeveeveveevV == 20 : Vee ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 21 : IiIII1i1i ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV )
elif eeevVeveeveveevV == 22 : iiIi ( eVeVeeveveVe , VevV )
elif eeevVeveeveveevV == 23 : DOIPLAYER ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 24 : II1I1iiIII ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 25 : iiI1II11II1i ( )
if 68 - 68: i11I1 - i1iIIIiI1I - iIii1I11I1II1 / eeev + i1iIIIiI1I - iIi1IIii11I
elif eeevVeveeveveevV == 26 : i1I11 ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 27 : Ii11Ii11I ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 28 : iI11iI1IiiIiI ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 29 : iiiI1i1I ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 30 : I11I1IIII ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 31 : VVevVeeeeveVVevV ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 32 : eVVVeeevVeveV ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 33 : VeveveVevevevVevV ( eVeVeeveveVe )
elif eeevVeveeveveevV == 34 : VVVIIiI1i1i ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 35 : IiII111i1i11 ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
if 75 - 75: iiIIiIiIi / Veeev % iIii1I11I1II1 . VeeeeeeeVV % VeeeeeeeVV % II111iiii
elif eeevVeveeveveevV == 36 : VVevVeVeveevev ( )
elif eeevVeveeveveevV == 37 : Ii ( eVeVeeveveVe )
elif eeevVeveeveveevV == 38 : IiIIIi1iIi ( eVeVeeveveVe )
elif eeevVeveeveveevV == 39 : VeeveV ( eVeVeeveveVe )
elif eeevVeveeveveevV == 40 : III1Iiii1I11 ( )
elif eeevVeveeveveevV == 41 : eevVVVVevevVevVe ( eVeVeeveveVe )
elif eeevVeveeveveevV == 42 : iii ( eVeVeeveveVe )
if 26 - 26: II111iiii % i11iIiiIii % iIii1I11I1II1 % VeVevevev * VeVevevev * eeeveveveveveev
elif eeevVeveeveveevV == 43 : i11i ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 44 : eeV ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 45 : IIIii11 ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
elif eeevVeveeveveevV == 46 : VeV ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , VevV )
if 24 - 24: II111iiii % Vevev - i11I1 + II1ii * eeeveveveveveev
elif eeevVeveeveveevV == 47 : DODOCLOGMENU ( )
elif eeevVeveeveveevV == 48 : GET_DOCCONTENT ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , Ve )
elif eeevVeveeveveevV == 49 : DO_DOCCONTENT ( II111iiiiII , eVeVeeveveVe , VeeevevVevevVevVevV , Ve )
elif eeevVeveeveveevV == 50 : RESOLVE2 ( eVeVeeveveVe )
if 2 - 2: VeeVeVevVe - VeveeeeevVeevev
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
