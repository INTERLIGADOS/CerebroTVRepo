#V 1.0.4
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , requests , urllib , urllib2 , json , os , re , sys , datetime , urlresolver , random , liveresolver , base64 , pyxbmct
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
import nanscrapers
import requests
import downloader as Get_Files
import extract
import time
if 64 - 64: i11iIiiIii
VVeve = 'plugin.video.picasso'
VeevVee = Addon ( VVeve , sys . argv )
VevVevVVevVevVev = xbmcaddon . Addon ( id = VVeve )
iiiii = xbmcaddon . Addon ( ) . getAddonInfo
eeeevVV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'fanart.png' ) )
Veveveeeeeevev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve , 'icon.png' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources/art' , 'next.png' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + '/resources' , 'rd.txt' ) )
I11i11Ii = 'http://matsbuilds.uk/pin'
eVeveveVe = xbmcaddon . Addon ( ) . getSetting ( 'password' )
VVVeev = xbmcaddon . Addon ( ) . getSetting ( 'enable_meta' )
Veeeeveveve = base64 . b64decode ( 'aHR0cHM6Ly94aGFtc3Rlci5jb20v' )
IiIi11iIIi1Ii = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
VeevV = requests . session ( )
IiI = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvaW5mby50eHQ=' )
eeVe = xbmc . translatePath ( 'special://home/userdata/addon_data/' + VVeve )
Ve = xbmc . translatePath ( os . path . join ( 'special://home/userdata/Database' , 'picasso.db' ) )
eevV = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'repository.Goliath' ) )
IiiIII111iI = '[COLOR cyan]Picasso[/COLOR]'
IiII = open ( Ve , 'a' )
IiII . close ( )
if 28 - 28: Ii11111i * iiI1i1
if 46 - 46: VeeevVVeveVV * Ii * Veeve
if not os . path . exists ( eevV ) :
 VVVeveeve = xbmcgui . Dialog ( ) . yesno ( IiiIII111iI , 'This Add-on requires [COLOR cyan]Goliaths Repo[/COLOR] to be installed to work correctly would you like to install it now?' , '' , yeslabel = '[B][COLOR white]YES[/COLOR][/B]' , nolabel = '[B][COLOR grey]NO[/COLOR][/B]' )
 if VVVeveeve == 1 :
  Ii1iI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  if not os . path . exists ( Ii1iI ) :
   os . makedirs ( Ii1iI )
  VeI1Ii11I1Ii1i = base64 . b64decode ( b'aHR0cDovL21hdHNidWlsZHMudWsvZ29saWF0aC9yZXBvc2l0b3J5LkdvbGlhdGgtMS40LnppcA==' )
  Vee = xbmcgui . DialogProgress ( )
  Vee . create ( IiiIII111iI , "" , "" , "Downloading [COLOR cyan]Goliaths Repo[/COLOR]" )
  eeveVeVeveve = os . path . join ( Ii1iI , 'repo.zip' )
  if 43 - 43: VevVVe . II1Iiii1111i
  try :
   os . remove ( eeveVeVeveve )
  except :
   pass
   if 25 - 25: VVeevevev
  Get_Files . download ( VeI1Ii11I1Ii1i , eeveVeVeveve , Vee )
  Vev = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  Vee . update ( 0 , "" , "Installing [COLOR red]Golitaths Repo[/COLOR] Please Wait" , "" )
  extract . all ( eeveVeVeveve , Vev , Vee )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  xbmc . executebuiltin ( "UpdateLocalAddons" )
  if 34 - 34: Veveevev % eeveee / VVVevV / I1ii * eVVVeeveevV + VVeVeeevevee
  if 41 - 41: i11IiIiiIIIII / IiiIII111ii / i1iIIi1
def ii11iIi1I ( st ) :
 import re
 st = re . sub ( '\[.+\]' , '' , st )
 import string
 iI111I11I1I1 = 0
 for VeevV in st :
  if VeevV in 'lij|\' ' : iI111I11I1I1 += 37
  elif VeevV in '![]fI.,:;/\\t' : iI111I11I1I1 += 50
  elif VeevV in '`-(){}r"' : iI111I11I1I1 += 60
  elif VeevV in '*^zcsJkvxy' : iI111I11I1I1 += 85
  elif VeevV in 'aebdhnopqug#$L+<>=?_~FZT' + string . digits : iI111I11I1I1 += 95
  elif VeevV in 'BSPEAKVXY&UwNRCHD' : iI111I11I1I1 += 112
  elif VeevV in 'QGOMm%W@' : iI111I11I1I1 += 135
  else : iI111I11I1I1 += 50
 return int ( iI111I11I1I1 * 6.5 / 100 )
 if 55 - 55: iI1I % iiiIi - eVVVeeveevV / Ii11111i % eeveee + VVeevevev
def iI111IiI111I ( Heading = xbmcaddon . Addon ( ) . getAddonInfo ( 'name' ) ) :
 VeeVeVevVe = xbmc . Keyboard ( '' , Heading )
 VeeVeVevVe . doModal ( )
 if ( VeeVeVevVe . isConfirmed ( ) ) :
  return VeeVeVevVe . getText ( )
  if 47 - 47: I1ii
def iiIiIiIi ( url ) :
 if 33 - 33: i11IiIiiIIIII + Veeve % i11iIiiIii . iiiIi - VevVVe
 import webbrowser
 if 66 - 66: i11IiIiiIIIII - VeeevVVeveVV * VeeevVVeveVV . eVVVeeveevV . VVVevV
 IiI1i11iii1 = webbrowser . open
 eeevVeevevVeev = xbmc . executebuiltin
 eVVVeveve = lambda VevVeveveevVVVev : xbmc . getCondVisibility ( str ( VevVeveveevVVVev ) )
 Ii1iIIIi1ii = lambda VevVeveveevVVVev : eeevVeevevVeev ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( VevVeveveevVVVev ) )
 if 80 - 80: VVeVeeevevee * i11iIiiIii / iI1I
 I11II1i = 'System.Platform.Android'
 if 23 - 23: VVVevV / eeveee + VVeVeeevevee + VVeVeeevevee / Veeve
 if eVVVeveve ( I11II1i ) : Ii1iIIIi1ii ( base64 . b64decode ( url ) )
 else : IiI1i11iii1 ( base64 . b64decode ( url ) )
 if 26 - 26: VeeevVVeveVV
 if 12 - 12: VeeevVVeveVV % Veveevev / iiiIi % eeveee
def iiii ( ) :
 if 54 - 54: VVVevV * eVVVeeveevV
 if 13 - 13: i1iIIi1 + Veveevev - VeeevVVeveVV + iI1I . IiiIII111ii + VVeevevev
 import sys
 if 8 - 8: iiI1i1 . VevVVe - iiI1i1 * i11IiIiiIIIII
 VVVV = 'aHR0cDovL21hdHNidWlsZHMudWsvcGlu'
 VVVevev = 'aHR0cDovL29mZnNob3JlcGx1Z2lucy5jb20vcGluL2NoZWNrLnBocD9waW49JXM='
 iiiiiIIii = 'W0JdW0NPTE9SIGN5YW5dSW4gb3JkZXIgdG8gY29udGludWUgcGxlYXNlWy9DT0xPUl0gW0NPTE9SIHdoaXRlXVZFUklGWVsvQ09MT1JdIFtDT0xPUiBjeWFuXXlvdXIgZGV2aWNlIGJ5IGdldHRpbmcgYSBwaW4gZnJvbSBvdXIgd2Vic2l0ZSBhbmQgZW50ZXJpbmcgdGhlIHBpbiBvbiB0aGUgbmV4dCBwcm9tdC4gT3IgZnJvbSBbL0NPTE9SXVtDT0xPUiB3aGl0ZV13d3cubWF0c2J1aWxkcy51ay9waW5bL0NPTE9SXVsvQl0='
 if 71 - 71: eVVVeeveevV + i11IiIiiIIIII * eVVVeeveevV - VVeevevev * eeveee
 VeeeevVeeevevev = base64 . b64decode ( iiiiiIIii )
 ee = xbmcaddon . Addon ( ) . getAddonInfo
 ii11I = xbmcaddon . Addon ( ) . getSetting ( 'pin' )
 VeeevVVeveVVii11i1 = lambda VevVeveveevVVVev : base64 . b64decode ( str ( VevVeveveevVVVev ) )
 IIIii1II1II = lambda VevVeveveevVVVev : requests . get ( base64 . b64decode ( VVVevev ) % ( VevVeveveevVVVev ) ) . text . strip ( )
 i1I1iI = lambda VevVeveveevVVVev : xbmcaddon . Addon ( ) . setSetting ( base64 . b64decode ( 'cGlu' ) , VevVeveveevVVVev )
 eeevVeeVVeev = lambda VevVeveveevVVVev : xbmcgui . Dialog ( ) . yesno ( ee ( 'name' ) , VevVeveveevVVVev , yeslabel = "Get A Pin" , nolabel = 'Cancel' )
 eevVVeveveV = bool ( IIIii1II1II ( ii11I ) == base64 . b64decode ( 'T0s=' ) )
 if 39 - 39: i1iIIi1 - Veeve * VVeevevev % eeveee * Veeve % Veeve
 if eevVVeveveV : return
 else :
  if 59 - 59: iiI1i1 + VevVVe - eeveee - VevVVe + eVVVeeveevV / VVVevV
  if eeevVeeVVeev ( VeeeevVeeevevev ) :
   iiIiIiIi ( VVVV )
   I1 = iI111IiI111I ( 'Type Your Pin Here' )
   i1I1iI ( I1 )
   iiii ( )
  else : sys . exit ( )
  if 71 - 71: eVVVeeveevV + iiiIi % i11iIiiIii + VVVevV - i1iIIi1
  if 88 - 88: Veveevev - VVeevevev % eVVVeeveevV
  if 16 - 16: VevVVe * I1ii % i1iIIi1
def Veeveveve ( ) :
 if not os . path . exists ( eeVe ) :
  os . mkdir ( eeVe )
 I11IiI1I11i1i ( IiI , 'GlobalCompare' )
 iI1ii1Ii ( '[B][COLOR yellow]Keep Safe[/COLOR][/B]' , 'url' , 22 , 'http://i.imgur.com/cR0cP8f.png' , II1 )
 iI1ii1Ii ( '[B][COLOR yellow]Find It...[/COLOR][/B]' , 'url' , 5 , 'http://i.imgur.com/ZQYQyHG.png' , II1 )
 iI1ii1Ii ( '[B][COLOR cyan]Movie Madness[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL01haW5tZW51LnhtbA==' ) , 26 , 'http://i.imgur.com/Y2rejnc.png' , II1 )
 iI1ii1Ii ( '[B][COLOR cyan]Telly Box[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvVHZTaG93cy9NYWlubWVudS54bWw=' ) , 27 , 'http://i.imgur.com/63LrHYW.png' , II1 )
 eeeeevevev = iIIIi1 ( iiII1i1 )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV in VVeVVeveeeveeV :
   iI1ii1Ii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , 1 , VevevVeveVVevevVevev , eeeevVV )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 11 - 11: i1iIIi1 . VVVevV
def eev ( name , url , iconimage , fanart ) :
 iI1ii1Ii ( '[B][COLOR yellow]MOVIE SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvTW92aWVzL1NlYXJjaC9TZWFyY2gudHh0' ) , 5 , 'http://i.imgur.com/QArRVYb.png' , II1 )
 iI1ii1Ii ( '[B][COLOR yellow]UK CINEMA RELEASE DATES[/COLOR][/B]' , 'http://www.empireonline.com/movies/features/upcoming-movies/' , 34 , 'http://i.imgur.com/aKQgDR7.png' , II1 )
 eeeeevevev = iIIIi1 ( url )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for name , url , iconimage , fanart in VVeVVeveeeveeV :
   eeeveVe ( name , url , iconimage , fanart , VVVevevV )
   if 89 - 89: Veveevev
def VVeveVeVVeveVVev ( name , url , iconimage , fanarts ) :
 iI1ii1Ii ( '[B][COLOR yellow]TV SEARCH[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvYW5ld0V2b2x2ZW1lbnUvc2VhcmNoLnhtbA==' ) , 33 , 'http://i.imgur.com/he5RFkL.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]TV SCHEDULE[/COLOR][/B]' , 'http://www.tvwise.co.uk/uk-premiere-dates/' , 32 , 'http://i.imgur.com/XKAapZH.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]Latest Episodes[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20=' ) , 28 , 'http://i.imgur.com/n8itltl.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]Popular Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9wb3B1bGFyLXNlcmllcw==' ) , 29 , 'http://i.imgur.com/ury75ui.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]New Shows[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy53YXRjaGVwaXNvZGVzNC5jb20vaG9tZS9uZXctc2VyaWVz' ) , 30 , 'http://i.imgur.com/UPWjTLw.png' , fanarts )
 iI1ii1Ii ( '[B][COLOR yellow]Soap Catchup[/COLOR][/B]' , base64 . b64decode ( 'aHR0cDovL3d3dy5jaW5lbWl4dHYuZ2Ev' ) , 51 , 'https://i.imgur.com/TSuNrSL.png' , fanarts )
 eVevVVeeevVV = Vevii1ii1ii ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eVevVVeeevVV )
 eeeeevevev = iIIIi1 ( url )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
  for name , url , iconimage , eeeevVV in VVeVVeveeeveeV :
   eeeveVe ( name , url , iconimage , eeeevVV , VVVevevV )
   if 91 - 91: i1iIIi1
def iiIii ( name , url , iconimage , fanart ) :
 eVevVVeeevVV = Vevii1ii1ii ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eVevVVeeevVV )
 eeeeevevev = iIIIi1 ( url )
 eeeevV ( eeeeevevev )
 if '<message>' in eeeeevevev :
  IiI = re . compile ( '<message>(.+?)</message>' ) . findall ( eeeeevevev ) [ 0 ]
  I11IiI1I11i1i ( IiI , eVevVVeeevVV )
 if '<intro>' in eeeeevevev :
  eVeVeveevevVVev = re . compile ( '<intro>(.+?)</intro>' ) . findall ( eeeeevevev ) [ 0 ]
  i1I1ii ( eVeVeveevevVVev )
 if 'XXX>yes</XXX' in eeeeevevev : eVVeev ( eeeeevevev )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in eeveveVVeve :
  eeeveVe ( name , url , iconimage , fanart , VVVevevV )
  if 54 - 54: Ii11111i - i1iIIi1 % eVVVeeveevV
def eeeveVe ( name , url , iconimage , fanart , item ) :
 try :
  if '<sportsdevil>' in item : VVeV ( name , url , iconimage , fanart , item )
  elif '<iplayer>' in item : iII ( name , url , iconimage , fanart , item )
  elif '<folder>' in item : ii1ii11IIIiiI ( name , url , iconimage , fanart , item )
  elif '<iptv>' in item : VevevVVVeVeeevV ( name , url , iconimage , fanart , item )
  elif '<image>' in item : VevevevVVeevevee ( name , url , iconimage , fanart , item )
  elif '<text>' in item : eeevVVe ( name , url , iconimage , fanart , item )
  elif '<scraper>' in item : eeVVVevevVee ( name , url , iconimage , fanart , item )
  elif '<lbscraper>' in item : IiIIIi1iIi ( name , url , iconimage , fanart , item )
  elif '<redirect>' in item : eeVVeeeeee ( name , url , iconimage , fanart , item )
  elif '<oktitle>' in item : II1I ( name , url , iconimage , fanart , item )
  elif '<nan>' in item : Vevi1II1Iiii1I11 ( name , url , iconimage , fanart , item )
  elif '<adult>' in item : IIII ( name , url , iconimage , fanart , item )
  else : iiIiI ( name , url , iconimage , fanart , item )
 except : pass
 if 91 - 91: IiiIII111ii % Ii % iiI1i1
def iII ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<iplayer>(.+?)</iplayer>' ) . findall ( item ) [ 0 ]
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 url = 'plugin://plugin.video.iplayerwww/?url=%s&mode=202&name=%s&iconimage=%s&description=&subtitles_url=&logged_in=False' % ( url , name , iconimage )
 IIi1I11I1II ( name , url , 16 , iconimage , fanart )
 if 63 - 63: VeeevVVeveVV - VVeevevev . Veeve / eeveee . Veveevev / Ii11111i
def Vevi1II1Iiii1I11 ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 eevVVVVevevVevVe = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 ii = re . compile ( '<nan>(.+?)</nan>' ) . findall ( item ) [ 0 ]
 eVeeVVVeVe = re . compile ( '<imdb>(.+?)</imdb>' ) . findall ( item ) [ 0 ]
 if ii == 'movie' :
  eVeeVVVeVe = eVeeVVVeVe + '<>movie'
 elif ii == 'tvshow' :
  i1Iii1i1I = re . compile ( '<showname>(.+?)</showname>' ) . findall ( item ) [ 0 ]
  VVeVevev = re . compile ( '<season>(.+?)</season>' ) . findall ( item ) [ 0 ]
  IiI111111IIII = re . compile ( '<episode>(.+?)</episode>' ) . findall ( item ) [ 0 ]
  i1Ii = re . compile ( '<showyear>(.+?)</showyear>' ) . findall ( item ) [ 0 ]
  ii111iI1iIi1 = re . compile ( '<episodeyear>(.+?)</episodeyear>' ) . findall ( item ) [ 0 ]
  eVeeVVVeVe = eVeeVVVeVe + '<>' + i1Iii1i1I + '<>' + VVeVevev + '<>' + IiI111111IIII + '<>' + i1Ii + '<>' + ii111iI1iIi1
  ii = "tvep"
 VVV ( name , eVeeVVVeVe , 19 , iconimage , 1 , ii , isFolder = True )
 if 68 - 68: Veeve + VVeVeeevevee
def I1I1I ( name , imdb , iconimage , fanart ) :
 IIi1IiiiI1Ii = ''
 VeVVevevev = name
 eVevVVeeevVV = Vevii1ii1ii ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eVevVVeeevVV )
 if 'movie' in imdb :
  imdb = imdb . split ( '<>' ) [ 0 ]
  i1Ii11i1i = [ ]
  eeveVVee = [ ]
  eVeevevVeveeeveveev = name . partition ( '(' )
  iiVVeeeeVevVe = eVeevevVeveeeveveev [ 0 ]
  iiVVeeeeVevVe = Vevii1ii1ii ( iiVVeeeeVevVe )
  VV = eVeevevVeveeeveveev [ 2 ] . partition ( ')' ) [ 0 ]
  iIiIIi1 = nanscrapers . scrape_movie ( iiVVeeeeVevVe , VV , imdb , timeout = 800 )
 else :
  i1Iii1i1I = imdb . split ( '<>' ) [ 1 ]
  I1IIII1i = imdb . split ( '<>' ) [ 0 ]
  VVeVevev = imdb . split ( '<>' ) [ 2 ]
  IiI111111IIII = imdb . split ( '<>' ) [ 3 ]
  i1Ii = imdb . split ( '<>' ) [ 4 ]
  ii111iI1iIi1 = imdb . split ( '<>' ) [ 5 ]
  iIiIIi1 = nanscrapers . scrape_episode ( i1Iii1i1I , i1Ii , ii111iI1iIi1 , VVeVevev , IiI111111IIII , I1IIII1i , None )
 I1I11i = 1
 for Ii1I1I1i1Ii in list ( iIiIIi1 ( ) ) :
  for i1 in Ii1I1I1i1Ii :
   if urlresolver . HostedMediaFile ( i1 [ 'url' ] ) . valid_url ( ) :
    IIi1IiiiI1Ii = VeeveVeveve ( i1 [ 'url' ] )
    name = "Link " + str ( I1I11i ) + ' | ' + i1 [ 'source' ] + IIi1IiiiI1Ii
    I1I11i = I1I11i + 1
    i11I1II1I11i ( name , i1 [ 'url' ] , 2 , iconimage , fanart , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
    if 61 - 61: VevVVe - eVVVeeveevV . I1ii / eVVVeeveevV + II1Iiii1111i
    if 5 - 5: iiiIi + iiiIi / Ii11111i * II1Iiii1111i - eVVVeeveevV % iiiIi
def IIII ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<adult>(.+?)</adult>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 36 , iconimage , fanart )
 if 15 - 15: i11iIiiIii % i11IiIiiIIIII . II1Iiii1111i + VVVevV
def VVevVVVVeeevVVV ( ) :
 iI1ii1Ii ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Top Viewed[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-viewed.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]HD[/COLOR][/B]' , Veeeeveveve + 'categories/hd-videos' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Most Commented[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-commented.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/weekly-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]50 Newest[/COLOR][/B]' , Veeeeveveve + 'last50.php' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Best of 2016[/COLOR][/B]' , Veeeeveveve + 'videos/top/year/2016' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]All-time Top Rated[/COLOR][/B]' , Veeeeveveve + 'rankings/alltime-top-videos.html' , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Main Categories[/COLOR][/B]' , Veeeeveveve , 39 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]All Categories Alpha[/COLOR][/B]' , Veeeeveveve + 'categories' , 38 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 iI1ii1Ii ( '[B][COLOR yellow]Search[/COLOR][/B]' , 'url' , 40 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 27 - 27: iiiIi + Veeve
def eevVeevev ( url ) :
 iI = VevVevVeeeeve ( url )
 eVVeeevevVeveve = re . compile ( '<div class="video"><a href="(.+?)" class=".+?"><div class=".+?"  data-previewvideo=".+?"><img src=\'(.+?)\' class=\'.+?\' alt="(.+?)"/><img class=\'.+?\' src=\'.+?\'' , re . DOTALL ) . findall ( iI )
 for url , Veveveeeeeevev , VeveevVevevVeeveev in eVVeeevevVeveve :
  VeveevVevevVeeveev = VeveevVevevVeeveev . replace ( '&#039;' , '\'' ) . replace ( '&amp;' , ' & ' )
  VevVevevVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 41 , Veveveeeeeevev , eeeevVV , '' )
 eeeeeeevVeveveve = re . compile ( '<link rel="next" href="(.+?)"' , re . DOTALL ) . findall ( iI )
 for url in eeeeeeevVeveveve :
  VevVevevVe ( '[B][COLOR cyan]Next Page>>>[/COLOR][/B]' , url , 37 , 'http://i.imgur.com/Uqrznbf.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 64 - 64: VevVVe . eeveee - iI1I / VeeevVVeveVV
def VevVeveeVVV ( url ) :
 iI = VevVevVeeeeve ( url )
 eVVeeevevVeveve = re . compile ( '<div class="list">(.+?)<div class="head"' , re . DOTALL ) . findall ( iI ) [ 1 ]
 eVVeevVeveve = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( str ( eVVeeevevVeveve ) )
 for url in eVVeevVeveve :
  VeveevVevevVeeveev = url . split ( 'xhamster.com/' ) [ 1 ]
  try :
   VeveevVevevVeeveev = VeveevVevevVeeveev . replace ( '-1.html' , '' )
   VeveevVevevVeeveev = VeveevVevevVeeveev . split ( '/' ) [ 1 ] . title ( )
  except : pass
  if 'categories' not in VeveevVevevVeeveev :
   VevVevevVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 8 - 8: VVeevevev
def ii1111iII ( url ) :
 iI = VevVevVeeeeve ( url )
 eVVeeevevVeveve = re . compile ( 'ul class="alphabet-block".+?<a class=""(.+?)</ul>' , re . DOTALL ) . findall ( iI )
 eVVeevVeveve = re . compile ( 'href="(.+?)">(.+?)<' , re . DOTALL ) . findall ( str ( eVVeeevevVeveve ) )
 for url , VeveevVevevVeeveev in eVVeevVeveve :
  VevVevevVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 42 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 32 - 32: Ii / Veeve . II1Iiii1111i
def eeeVeevVVVeeev ( url ) :
 iI = VevVevVeeeeve ( url )
 eVVeeevevVeveve = re . compile ( '<div class="letter-categories">(.+?)</ul>' , re . DOTALL ) . findall ( iI )
 eVVeevVeveve = re . compile ( 'href="(.+?)"><span >(.+?)<' , re . DOTALL ) . findall ( str ( eVVeeevevVeveve ) )
 for url , VeveevVevevVeeveev in eVVeevVeveve :
  VevVevevVe ( '[B][COLOR yellow]%s[/COLOR][/B]' % VeveevVevevVeeveev , url , 37 , 'http://i.imgur.com/z6WJ6RB.png' , eeeevVV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 51 - 51: II1Iiii1111i / Veveevev . eVVVeeveevV * eeveee + VVeevevev * i1iIIi1
def VVVeVe ( ) :
 Veveveev = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 Veveveev . doModal ( )
 if ( Veveveev . isConfirmed ( ) ) :
  I11iII = Veveveev . getText ( ) . replace ( ' ' , '+' )
  VeI1Ii11I1Ii1i = Veeeeveveve + 'search.php?from=&q=' + I11iII + '&qcat=video'
  eevVeevev ( VeI1Ii11I1Ii1i )
  if 5 - 5: VevVVe
def VevVevVeeeeve ( url ) :
 iIiIi11iI = { }
 iIiIi11iI [ 'User-Agent' ] = IiIi11iIIi1Ii
 eeeeevevev = VeevV . get ( url , headers = iIiIi11iI ) . text
 eeeeevevev = eeeeevevev . encode ( 'ascii' , 'ignore' )
 return eeeeevevev
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 83 - 83: Veeve % II1Iiii1111i % iiiIi % VVVevV
def VeVevevevVevVe ( url ) :
 VeeveeveeeeevVev = [ ]
 VeeeeVVeeev = [ ]
 i1I1IiiIi1i = ''
 iI = VevVevVeeeeve ( url )
 eeveveVVeve = re . compile ( 'sources:(.+?)allowFullScreen:' , re . DOTALL ) . findall ( iI ) [ 0 ]
 iiI11ii1I1 = re . compile ( '"(.+?)":"(.+?)"' , re . DOTALL ) . findall ( str ( eeveveVVeve ) )
 for VeeevVVeVeVev , eeeeevevev in iiI11ii1I1 :
  i1I1IiiIi1i = '[B][COLOR cyan]%s[/COLOR][/B]' % VeeevVVeVeVev
  VeeveeveeeeevVev . append ( i1I1IiiIi1i )
  VeeeeVVeeev . append ( eeeeevevev )
 if len ( eeveveVVeve ) > 1 :
  eVeevVVeVev = xbmcgui . Dialog ( )
  II = eVeevVVeVev . select ( 'Please Select Quality' , VeeveeveeeeevVev )
  if II == - 1 :
   return
  elif II > - 1 :
   url = VeeeeVVeeev [ II ]
 else :
  url = re . compile ( 'sources: {".+?":"(.+?)"' ) . findall ( iI ) [ 0 ]
 url = url . replace ( '\/' , '/' )
 eevVeeveVeveVVevev = xbmcgui . ListItem ( VeveevVevevVeeveev , iconImage = 'DefaultVideo.png' , thumbnailImage = VevevVeveVVevevVevev )
 eevVeeveVeveVVevev . setInfo ( type = 'Video' , infoLabels = { "Title" : VeveevVevevVeeveev } )
 eevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
 eevVeeveVeveVVevev . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , eevVeeveVeveVVevev )
 if 92 - 92: VeeevVVeveVV * iI1I
def VevVevevVe ( name , url , mode , iconimage , fanart , description ) :
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 eevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 if mode == 41 :
  eevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
  I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = False )
 else :
  I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = True )
 return I1II1
 if 86 - 86: iiI1i1 / Veveevev . Veeve
 if 19 - 19: VVVevV % VeeevVVeveVV % i1iIIi1 * eeveee % Ii11111i
 if 67 - 67: VevVVe . Ii
def eeVVVevevVee ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<scraper>(.+?)</scraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 18 , iconimage , fanart )
 if 27 - 27: iiiIi % VevVVe
def eeveeeVVevev ( name , url , iconimage , fanart ) :
 iiIiii1IIIII = url
 if iiIiii1IIIII == 'latestmovies' :
  eeveve = 15
  IIIIiiIiiI = MOVIESINDEXER ( )
  IIIIiI11I11 = re . compile ( '<item>(.+?)</item>' ) . findall ( IIIIiiIiiI )
  for VVVevevV in IIIIiI11I11 :
   VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( VVVevevV )
   eeeveveev = len ( IIIIiI11I11 )
   for name , url , iconimage , fanart in VVeVVeveeeveeV :
    if '<meta>' in VVVevevV :
     i11II1I11I1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( VVVevevV ) [ 0 ]
     VVV ( name , url , eeveve , iconimage , eeeveveev , i11II1I11I1 , isFolder = False )
    else : i11I1II1I11i ( name , url , 15 , iconimage , fanart )
    if 67 - 67: VevVVe - eeveee / VVeVeeevevee - Ii
    if 1 - 1: Veeve
def VeveVeeveve ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( 'http://www.watchepisodes4.com' )
 iiIi11iI1iii = re . compile ( '<a title=".+?" .+? style="background-image: url(.+?)"></a>.+?<div class="hb-right">.+?<a title=".+?" href="(.+?)" class="episode">(.+?)</a>' , re . DOTALL ) . findall ( eeeeevevev )
 for iconimage , url , name in iiIi11iI1iii :
  iconimage = iconimage . replace ( "('" , "" ) . replace ( "')" , "" )
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  name = name . split ( '  ' ) [ 0 ]
  iI1ii1Ii ( name , url , 24 , iconimage , iconimage )
  if 67 - 67: Ii11111i / iI1I
def VVVeveveveveV ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( name , url , 31 , iconimage , iconimage )
  if 15 - 15: Veveevev % VevVVe * VVeVeeevevee
def VevVeeeVev ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="cb-first">.+?<a href="(.+?)" class="c-image"><img alt=".+?" title="(.+?)" src="(.+?)"></a>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  name = name . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( name , url , 31 , iconimage , iconimage )
  if 85 - 85: VVeVeeevevee
def iI1i11II1i ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 iIi1I11I = re . compile ( '<div class="std-cts">.+?<div class="sdt-content tnContent">.+?<h2>(.+?)</h2>' , re . DOTALL ) . findall ( eeeeevevev ) [ 0 ] . replace ( ' Episodes' , '' ) . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
 eeveveVVeve = re . compile ( '<a title=".+?" href="(.+?)">.+?<div class="season">(.+?) </div>.+?<div class="episode">(.+?)</div>.+?<div class="e-name">(.+?)</div>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , VVeVevev , IiI111111IIII , Iii1 in eeveveVVeve :
  Iii1 = Iii1 . replace ( "&#39;" , "'" ) . replace ( '&amp;' , ' & ' )
  if '</div>' in name : name = 'TBA'
  iI1ii1Ii ( '%s ' % iIi1I11I + '(%s ' % VVeVevev + '%s)' % IiI111111IIII , url , 24 , iconimage , iconimage )
  if 58 - 58: VevVVe . IiiIII111ii + Veveevev
def VevevVV ( name , url , iconimage , fanart ) :
 VeVVevevev = name
 eeeeevevev = eeveevVeVeevVevVV ( url )
 I1I1 = re . compile ( '<a target="_blank" href=".+?" data-episodeid=".+?" data-linkid=".+?" data-hostname=".+?" class="watch-button" data-actuallink="(.+?)">Watch Now!</a>' ) . findall ( eeeeevevev )
 I1I11i = 1
 i1Ii11i1i = [ ]
 eeveVVee = [ ]
 for VeVevVeveeveVVV in I1I1 :
  IIi1IiiiI1Ii = VeeveVeveve ( VeVevVeveeveVVV )
  if 'http' in VeVevVeveeveVVV : VVeVeVe = VeVevVeveeveVVV . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : VVeVeVe = VeVevVeveeveVVV
  name = "Link " + str ( I1I11i ) + ' | ' + VVeVeVe + IIi1IiiiI1Ii
  if VVeVeVe != 'www' :
   i11I1II1I11i ( VVeVeVe , VeVevVeveeveVVV , 2 , iconimage , fanart , description = '' )
   if 98 - 98: IiiIII111ii
def VeeeeVeveVVVV ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 iiIi11iI1iii = re . compile ( '<td height="20">(.+?)</td>.+?<td>(.+?)</td>.+?<td><a href=".+?">(.+?)</a></td>.+?<td><a href=".+?">(.+?)</a></td>.+?</tr>' , re . DOTALL ) . findall ( eeeeevevev )
 for eevVeveveVVee , name , i1I1iIi , time in iiIi11iI1iii :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( '[COLOR yellow]%s[/COLOR] - ' % i1I1iIi + '[COLOR yellow]%s[/COLOR] ' % name + '- [COLOR white]%s[/COLOR]' % eevVeveveVVee , url , 28 , iconimage , fanart )
  if 22 - 22: Veveevev * Ii11111i . i1iIIi1 * i11iIiiIii - VevVVe * iiiIi
def VVeeeevVeveev ( url ) :
 II1iI1I11I = ''
 eevVVev = xbmc . Keyboard ( II1iI1I11I , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 eevVVev . doModal ( )
 if eevVVev . isConfirmed ( ) :
  II1iI1I11I = eevVVev . getText ( ) . replace ( ' ' , '+' ) . replace ( '+and+' , '+%26+' )
 if len ( II1iI1I11I ) > 1 :
  url = 'http://www.watchepisodes4.com/search/ajax_search?q=' + II1iI1I11I
  eeeeevevev = eeveevVeVeevVevVV ( url )
  VVeVVeveeeveeV = json . loads ( eeeeevevev )
  VVeVVeveeeveeV = VVeVVeveeeveeV [ 'series' ]
  for VVVevevV in VVeVVeveeeveeV :
   VeveevVevevVeeveev = VVVevevV [ 'value' ]
   IiI11ii1I = VVVevevV [ 'seo' ]
   url = 'http://www.watchepisodes4.com/' + IiI11ii1I
   VevevVeveVVevevVevev = 'http://www.watchepisodes4.com/movie_images/' + IiI11ii1I + '.jpg'
   iI1ii1Ii ( VeveevVevevVeeveev , url , 31 , VevevVeveVVevevVevev , eeeevVV )
  II1iI1I11I = II1iI1I11I [ : - 1 ]
  eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/anewEvolvemenu/search.xml' )
  eee = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeeevevev )
  for url in eee :
   try :
    eeeeevevev = iIIIi1 ( url )
    iiI = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
    for VVVevevV in iiI :
     eeveveVVeve = re . compile ( '<title>(.+?)</title>' ) . findall ( VVVevevV )
     for VeVVevevev in eeveveVVeve :
      VeVVevevev = Vevii1ii1ii ( VeVVevevev . upper ( ) )
      II1iI1I11I = II1iI1I11I . upper ( )
      if II1iI1I11I in VeVVevevev :
       eeeveVe ( VeveevVevevVeeveev , url , VevevVeveVVevevVevev , eeeevVV , VVVevevV )
   except : pass
   if 56 - 56: II1Iiii1111i . VVVevV . VevVVe
def ii111I ( name , url , date , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 eeveveVVeve = re . compile ( '</div>.+?<a href="(.+?)" class="list">.+?<div class="serie-poster">.+?<img src="(.+?)" alt="(.+?)"/>.+?<span class="date">(.+?)</span>' , re . DOTALL ) . findall ( eeeeevevev )
 for url , iconimage , name , date in eeveveVVeve :
  url = 'http://www.cinemixtv.ga/' + url
  i11I1II1I11i ( '[B][COLOR yellow]%s[/COLOR][/B]' % name , url , 52 , iconimage , fanart )
 try :
  eeeeeeevVeveveve = re . compile ( '<li class="active"><a href=".+?">.+?</a></li><li class="noactive"><a href="(.+?)">(.+?)</a></li>' , re . DOTALL ) . findall ( eeeeevevev )
  for url , iiIiIiiiII in eeeeeeevVeveveve :
   iI1ii1Ii ( '[COLOR cyan][B]Next Page >> %s[/B][/COLOR]' % iiIiIiiiII , url , i1iI1 , '' , '' )
 except : pass
 if 33 - 33: i1iIIi1 % iiI1i1 * VevVVe
 if 95 - 95: iiiIi / iiiIi
def IIiI1Ii ( name , url , iconimage ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 eeveveVVeve = re . compile ( '<iframe width=".+?" height=".+?" src="(.+?)" allowfullscreen></iframe>' ) . findall ( eeeeevevev )
 for url in eeveveVVeve :
  eeeeevevev = eeveevVeVeevVevVV ( url )
  VeeeeVVeeev = 'http:' + re . compile ( '<iframe width="100%" height="100%" src="(.+?)" allowfullscreen></iframe>' ) . findall ( eeeeevevev ) [ 0 ]
  VeeeeVVeeev = urlresolver . HostedMediaFile ( VeeeeVVeeev ) . resolve ( )
  eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = 'DefaultVideo.png' , thumbnailImage = iconimage )
  eevVeeveVeveVVevev . setPath ( VeeeeVVeeev )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , eevVeeveVeveVVevev )
  if 57 - 57: eVVVeeveevV - iiiIi - VVeVeeevevee + VVeevevev
  if 30 - 30: i11IiIiiIIIII % Veveevev + Ii - VVeVeeevevee - i11IiIiiIIIII
def III11I1 ( name , url , iconimage , fanart ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 iiIi11iI1iii = re . compile ( '<h2 id=".+?">(.+?)</h2>.+?<p><span class="article__image article__image--undefined"><img src="(.+?)" alt=".+?"></span> </p>.+?<p><strong>(.+?)</strong>(.+?)<' , re . DOTALL ) . findall ( eeeeevevev )
 for VeVVevevev , iconimage , IIi1IIIi , i1I1iIi in iiIi11iI1iii :
  name = name . replace ( "&#8217;" , "'" ) . replace ( '&amp;' , ' & ' )
  iI1ii1Ii ( '[COLOR yellow]%s [/COLOR] ' % VeVVevevev + '[COLOR yellow]%s[/COLOR]' % IIi1IIIi + '[COLOR white]%s[/COLOR]' % i1I1iIi , url , 35 , iconimage , fanart )
def VevevVee ( name , url , iconimage , fanart ) :
 eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/Menus/Movies/EvolveLatest/mainmenu.xml' )
 iiIi11iI1iii = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
 for VVVevevV in iiIi11iI1iii :
  eeeveVe ( name , url , iconimage , fanart , VVVevevV )
  if 52 - 52: VVVevV - II1Iiii1111i + VVVevV % eeveee
  if 35 - 35: iiI1i1
  if 42 - 42: iI1I . VevVVe . Ii + Veveevev + eVVVeeveevV + VevVVe
  if 31 - 31: IiiIII111ii . eVVVeeveevV - iiiIi . VeeevVVeveVV / VeeevVVeveVV
  if 56 - 56: VVeevevev / I1ii / i11iIiiIii + VeeevVVeveVV - II1Iiii1111i - VVeVeeevevee
def Iii1iiIi1II ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 60 - 60: VevVVe - I1ii * VVeVeeevevee % Veeve
def eeeIIiIiI1I ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="thumb" id="post-.+?">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=".+?" />' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 100 - 100: iiI1i1 + Veveevev / II1Iiii1111i . i11iIiiIii
def III1I1Iii1iiI ( name , url , iconimage , fanarts ) :
 eeeeevevev = eeveeeeVeveevV ( url )
 iiIi11iI1iii = re . compile ( '<div class="thumb">.+?<a href="(.+?)" title="Watch (.+?) Online"><img width=".+?" height=".+?" src="(.+?)" class="attachment-post-thumbnail size-post-thumbnail wp-post-image"' , re . DOTALL ) . findall ( eeeeevevev )
 for url , name , iconimage in iiIi11iI1iii :
  iI1ii1Ii ( name , url , 46 , iconimage , iconimage )
  if 17 - 17: i11IiIiiIIIII % iiI1i1 - iiI1i1
def VeveevVev ( name , url , iconimage , fanarts ) :
 i1Ii11i1i = [ ]
 eeveVVee = [ ]
 Ii1II1I11i1 = [ ]
 eeeeevevev = eeveevVeVeevVevVV ( url )
 I1I1 = re . compile ( '<a href="(.+?)" title=".+?" rel="nofollow" target="blank">.+?</a><br/>' ) . findall ( eeeeevevev )
 I1I11i = 1
 i1Ii11i1i = [ ]
 eeveVVee = [ ]
 for VeVevVeveeveVVV in I1I1 :
  IIi1IiiiI1Ii = VeeveVeveve ( VeVevVeveeveVVV )
  if '//' in VeVevVeveeveVVV : VVeVeVe = VeVevVeveeveVVV . split ( '/' ) [ 2 ] . split ( '.' ) [ 0 ]
  else : VVeVeVe = VeVevVeveeveVVV
  name = "Link " + str ( I1I11i ) + ' | ' + VVeVeVe + IIi1IiiiI1Ii
  if VVeVeVe != 'www' :
   i11I1II1I11i ( VVeVeVe , VeVevVeveeveVVV , 2 , iconimage , eeeevVV , description = '' )
   if 59 - 59: I1ii % iiI1i1 . Ii
   if 21 - 21: II1Iiii1111i
def IiIIIi1iIi ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<lbscraper>(.+?)</lbscraper>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 10 , iconimage , fanart )
 if 29 - 29: VVeVeeevevee / Veeve / iiiIi * eVVVeeveevV
def I111i1i1111 ( name , url , iconimage , fanart ) :
 iIiIIi1 = IIII1 ( name , url , iconimage )
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( iIiIIi1 )
 for VVVevevV in eeveveVVeve :
  eeeveVe ( name , url , iconimage , fanart , VVVevevV )
  if 10 - 10: iI1I / iiiIi + i11iIiiIii / i11IiIiiIIIII
def IIII1 ( name , url , iconimage ) :
 iiIiii1IIIII = url
 string = ''
 if url == 'mamahd' :
  eeeeevevev = eeveeeeVeveevV ( "http://mamahd.com" ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
  VVVeVeV = re . compile ( '<a href="(.+?)">.+?<img src="(.+?)"></div>.+?<div class="home cell">.+?<span>(.+?)</span>.+?<span>(.+?)</span>.+?</a>' ) . findall ( eeeeevevev )
  for url , iconimage , iIIIII1ii1I , Ii1i1iI in VVVeVeV :
   string = string + '<item>\n<title>%s vs %s</title>\n<sportsdevil>%s</sportsdevil>\n<thumbnail>%s</thumbnail>\n<fanart>fanart</fanart>\n</item>\n\n' % ( iIIIII1ii1I , Ii1i1iI , url , iconimage )
  return string
  if 16 - 16: eVVVeeveevV / II1Iiii1111i / VeeevVVeveVV * VevVVe + Ii % eVVVeeveevV
 elif url == 'cricfree' :
  eeeeevevev = eeveeeeVeveevV ( "http://cricfree.sc/football-live-stream" )
  eeeeveevev = re . compile ( '<td><span class="sport-icon(.+?)</tr>' , re . DOTALL ) . findall ( eeeeevevev )
  for eeV in eeeeveevev :
   eeveevev = re . compile ( '<td>(.+?)<br(.+?)</td>' ) . findall ( eeV )
   for IIi , i1I1iIi in eeveevev :
    IIi = '[COLOR yellow]' + IIi + '[/COLOR]'
    i1I1iIi = i1I1iIi . replace ( '>' , '' )
   time = re . compile ( '<td class="matchtime" style="color:#545454;font-weight:bold;font-size: 9px">(.+?)</td>' ) . findall ( eeV ) [ 0 ]
   time = '[COLOR white](' + time + ')[/COLOR]'
   eVeVeveveeevV = re . compile ( '<a style="text-decoration:none !important;color:#545454;" href="(.+?)" target="_blank">(.+?)</a></td>' ) . findall ( eeV )
   for url , IiiiI in eVeVeveveeevV :
    url = url
    IiiiI = IiiiI
   string = string + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( IIi + ' ' + time + ' - ' + IiiiI , url )
   string = string + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return string
  if 61 - 61: eVVVeeveevV % eVVVeeveevV * eeveee / eeveee
 elif url == 'bigsports' :
  eeeeevevev = eeveeeeVeveevV ( "http://www.bigsports.me/cat/4/football-live-stream.html" )
  VVVeVeV = re . compile ( '<td>.+?<td>(.+?)\-(.+?)\-(.+?)</td>.+?<td>(.+?)\:(.+?)</td>.+?<td>Football</td>.+?<td><strong>(.+?)</strong></td>.+?<a target=.+? href=(.+?) class=.+?' , re . DOTALL ) . findall ( eeeeevevev )
  for IIi , eeveVV , VeveevVVeveveveveee , iIIII1iIIii , eVVVeveveeveveve , name , url in VVVeVeV :
   if not '</td>' in IIi :
    url = url . replace ( '"' , '' )
    i1I1iIi = IIi + ' ' + eeveVV + ' ' + VeveevVVeveveveveee
    time = iIIII1iIIii + ':' + eVVVeveveeveveve
    i1I1iIi = '[COLOR yellow]' + i1I1iIi + '[/COLOR]'
    time = '[COLOR cyan](' + time + ')[/COLOR]'
    string = string + '\n<item>\n<title>%s</title>\n<sportsdevil>%s</sportsdevil>\n' % ( i1I1iIi + ' ' + time + ' ' + name , url )
    string = string + '<thumbnail>iconimage</thumbnail>\n<fanart>fanart</fanart>\n</item>\n'
  return string
  if 9 - 9: I1ii + VVeVeeevevee / VVeVeeevevee
def II1I ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 Ii1I11ii1i = re . compile ( '<oktitle>(.+?)</oktitle>' ) . findall ( item ) [ 0 ]
 VeviIiIIIIIii = re . compile ( '<line1>(.+?)</line1>' ) . findall ( item ) [ 0 ]
 VVeev = re . compile ( '<line2>(.+?)</line2>' ) . findall ( item ) [ 0 ]
 ii11I1 = re . compile ( '<line3>(.+?)</line3>' ) . findall ( item ) [ 0 ]
 eVevee = '##' + Ii1I11ii1i + '#' + VeviIiIIIIIii + '#' + VVeev + '#' + ii11I1 + '##'
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 IIi1I11I1II ( name , eVevee , 17 , iconimage , fanart )
 if 38 - 38: VeeevVVeveVV * iiiIi % Ii11111i * Veveevev
def IIiiI ( name , url ) :
 III1i11 = re . compile ( '##(.+?)##' ) . findall ( url ) [ 0 ] . split ( '#' )
 eVeevVVeVev = xbmcgui . Dialog ( )
 eVeevVVeVev . ok ( III1i11 [ 0 ] , III1i11 [ 1 ] , III1i11 [ 2 ] , III1i11 [ 3 ] )
 if 25 - 25: VVeevevev
def eeVVeeeeee ( name , url , iconimage , fanart , item ) :
 url = re . compile ( '<redirect>(.+?)</redirect>' ) . findall ( item ) [ 0 ]
 iiIii ( 'name' , url , 'iconimage' , 'fanart' )
 if 24 - 24: i1iIIi1 * i11iIiiIii * eVVVeeveevV
def eeevVVe ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 eVevee = re . compile ( '<text>(.+?)</text>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 IIi1I11I1II ( name , eVevee , 9 , iconimage , fanart )
 if 85 - 85: eeveee . Veveevev / iiiIi . Ii11111i % iI1I
def VVeveeeeveVV ( name , url ) :
 eeevevev = eeveevVeVeevVevVV ( url )
 iiVeV ( name , eeevevev )
 if 41 - 41: Ii * Veeve / VeeevVVeveVV . eVVVeeveevV
def VevevevVVeevevee ( name , url , iconimage , fanart , item ) :
 VeviII1 = re . compile ( '<image>(.+?)</image>' ) . findall ( item )
 if len ( VeviII1 ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  IIII1i = re . compile ( '<image>(.+?)</image>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  IIi1I11I1II ( name , IIII1i , 7 , iconimage , fanart )
 elif len ( VeviII1 ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  Ii1IIIIi1ii1I = ''
  for IIII1i in VeviII1 : Ii1IIIIi1ii1I = Ii1IIIIi1ii1I + '<image>' + IIII1i + '</image>'
  Ii1iI = eeVe
  name = Vevii1ii1ii ( name )
  IiiIiI1Ii1i = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( IiiIiI1Ii1i ) : file ( IiiIiI1Ii1i , 'w' ) . close ( )
  i1iIi = open ( IiiIiI1Ii1i , "w" )
  i1iIi . write ( Ii1IIIIi1ii1I )
  i1iIi . close ( )
  IIi1I11I1II ( name , 'image' , 8 , iconimage , fanart )
  if 30 - 30: Ii11111i - iiI1i1 / VeeevVVeveVV
def VevevVVVeVeeevV ( name , url , iconimage , fanart , item ) :
 name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
 url = re . compile ( '<iptv>(.+?)</iptv>' ) . findall ( item ) [ 0 ]
 fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
 iI1ii1Ii ( name , url , 6 , iconimage , fanart )
 if 89 - 89: IiiIII111ii - iiiIi % II1Iiii1111i % eeveee
def IIiii11i ( url , iconimage ) :
 eeeeevevev = eeveevVeVeevVevVV ( url )
 VeveveVeeveveeve = re . compile ( '^#.+?:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( eeeeevevev )
 VeveveVev = [ ]
 for VevVeevevVeVe , VeveevVevevVeeveev , url in VeveveVeeveveeve :
  ii1ii111 = { "params" : VevVeevevVeVe , "name" : VeveevVevevVeeveev , "url" : url }
  VeveveVev . append ( ii1ii111 )
 list = [ ]
 for eevVeveveVVee in VeveveVev :
  ii1ii111 = { "name" : eevVeveveVVee [ "name" ] , "url" : eevVeveveVVee [ "url" ] }
  VeveveVeeveveeve = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( eevVeveveVVee [ "params" ] )
  for i11111I1I , ii1 in VeveveVeeveveeve :
   ii1ii111 [ i11111I1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1 . strip ( )
  list . append ( ii1ii111 )
 for eevVeveveVVee in list :
  if '.ts' in eevVeveveVVee [ "url" ] : IIi1I11I1II ( eevVeveveVVee [ "name" ] , eevVeveveVVee [ "url" ] , 2 , iconimage , eeeevVV )
  else : i11I1II1I11i ( eevVeveveVVee [ "name" ] , eevVeveveVVee [ "url" ] , 2 , iconimage , eeeevVV )
  if 80 - 80: VeeevVVeveVV - eVVVeeveevV * i11IiIiiIIIII * VVVevV / VevVVe / eVVVeeveevV
def iiIiI ( name , url , iconimage , fanart , item ) :
 IIi1IiiiI1Ii = ''
 I1I11iI11iI1i = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , eeeveevVevVeeeee , iconimage , fanart in VVeVVeveeeveeV :
  if 'youtube.com/playlist?' in eeeveevVevVeeeee :
   II1iI1I11I = eeeveevVevVeeeee . split ( 'list=' ) [ 1 ]
   iI1ii1Ii ( name , eeeveevVevVeeeee , i1iI1 , iconimage , fanart , description = II1iI1I11I )
 if len ( I1I11iI11iI1i ) == 1 :
  VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
  for name , url , iconimage , fanart in VVeVVeveeeveeV :
   try :
    IIi1IiiiI1Ii = VeeveVeveve ( url )
    i11IIIiI1I = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
    if 'SportsDevil' in url : i11IIIiI1I = ''
   except : pass
   if '.ts' in url : i11I1II1I11i ( name , url , 16 , iconimage , fanart , description = '' )
   if '<meta>' in item :
    i11II1I11I1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
    VVV ( name + IIi1IiiiI1Ii , url , 2 , iconimage , 10 , i11II1I11I1 , isFolder = False )
   else :
    i11I1II1I11i ( name + IIi1IiiiI1Ii , url , 2 , iconimage , fanart )
 elif len ( I1I11iI11iI1i ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  fanart = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( item ) [ 0 ]
  if '.ts' in url : i11I1II1I11i ( name , url , 16 , iconimage , fanart , description = '' )
  if '<meta>' in item :
   i11II1I11I1 = re . compile ( '<meta>(.+?)</meta>' ) . findall ( item ) [ 0 ]
   VVV ( name , url , 3 , iconimage , len ( I1I11iI11iI1i ) , i11II1I11I1 , isFolder = True )
  else :
   iI1ii1Ii ( name , url , 3 , iconimage , fanart )
   if 69 - 69: Ii11111i
   if 85 - 85: iiiIi / Ii11111i
def VVeV ( name , url , iconimage , fanart , item ) :
 I1I11iI11iI1i = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item )
 iI1iIIIi1i = re . compile ( '<link>(.+?)</link>' ) . findall ( item )
 if len ( I1I11iI11iI1i ) + len ( iI1iIIIi1i ) == 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( item ) [ 0 ]
  url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url
  IIi1I11I1II ( name , url , 16 , iconimage , fanart )
 elif len ( I1I11iI11iI1i ) + len ( iI1iIIIi1i ) > 1 :
  name = re . compile ( '<title>(.+?)</title>' ) . findall ( item ) [ 0 ]
  iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( item ) [ 0 ]
  iI1ii1Ii ( name , url , 3 , iconimage , fanart )
  if 89 - 89: iiI1i1
def eVVeev ( link ) :
 if eVeveveVe == '' :
  eVeevVVeVev = xbmcgui . Dialog ( )
  II = eVeevVVeVev . yesno ( 'Adult Content' , 'You have found the goodies ;)' , '' , 'Please set a password to prevent accidental access' , 'Cancel' , 'OK' )
  if II == 1 :
   Veveveev = xbmc . Keyboard ( '' , 'Set Password' )
   Veveveev . doModal ( )
   if ( Veveveev . isConfirmed ( ) ) :
    i11iiiiI1i = Veveveev . getText ( )
    VevVevVVevVevVev . setSetting ( 'password' , i11iiiiI1i )
  else : quit ( )
 elif eVeveveVe <> '' :
  eVeevVVeVev = xbmcgui . Dialog ( )
  II = eVeevVVeVev . yesno ( 'Adult Content' , 'Please enter the password you set!' , 'to continue' , 'dirty git' , 'Cancel' , 'OK' )
  if II == 1 :
   Veveveev = xbmc . Keyboard ( '' , 'Enter Password' )
   Veveveev . doModal ( )
   if ( Veveveev . isConfirmed ( ) ) :
    i11iiiiI1i = Veveveev . getText ( )
   if i11iiiiI1i <> eVeveveVe :
    quit ( )
  else : quit ( )
  if 37 - 37: eVVVeeveevV / VeeevVVeveVV - i11iIiiIii
def i1iIiIi1I ( name , url , iconimage ) :
 iiii11i = ''
 eVevVVeeevVV = Vevii1ii1ii ( name )
 VevVevVVevVevVev . setSetting ( 'tv' , eVevVVeeevVV )
 eeeeevevev = iIIIi1 ( url )
 III11II1I1Ii1 = re . compile ( '<title>.*?' + re . escape ( name ) + '.*?</title>(.+?)</item>' , re . DOTALL ) . findall ( eeeeevevev ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( III11II1I1Ii1 ) [ 0 ]
 I1I11iI11iI1i = [ ]
 if '<link>' in III11II1I1Ii1 :
  VevevVeeveeveveveV = re . compile ( '<link>(.+?)</link>' ) . findall ( III11II1I1Ii1 )
  for eVeveeveveVVeeVev in VevevVeeveeveveveV :
   I1I11iI11iI1i . append ( eVeveeveveVVeeVev )
 if '<sportsdevil>' in III11II1I1Ii1 :
  VVVeVevevev = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( III11II1I1Ii1 )
  for eVVVV in VVVeVevevev :
   eVVVV = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + eVVVV
   I1I11iI11iI1i . append ( eVVVV )
 I1I11i = 1
 for eeeeevevev in I1I11iI11iI1i :
  if '(' in eeeeevevev :
   eeeeevevev = eeeeevevev . split ( '(' )
   iiii11i = eeeeevevev [ 1 ] . replace ( ')' , '' )
   eeeeevevev = eeeeevevev [ 0 ]
  IIi1IiiiI1Ii = VeeveVeveve ( eeeeevevev )
  i11IIIiI1I = eeeeevevev . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  if iiii11i <> '' : name = "Link " + str ( I1I11i ) + ' | ' + iiii11i + IIi1IiiiI1Ii
  else : name = "Link " + str ( I1I11i ) + ' | ' + i11IIIiI1I + IIi1IiiiI1Ii
  I1I11i = I1I11i + 1
  VVV ( name , eeeeevevev , 2 , iconimage , 10 , '' , isFolder = False , description = VevVevVVevVevVev . getSetting ( 'tv' ) )
  if 49 - 49: Veeve . I1ii . i11iIiiIii % i1iIIi1
def ii1ii11IIIiiI ( name , url , iconimage , fanart , item ) :
 VVeVVeveeeveeV = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( item )
 for name , url , iconimage , fanart in VVeVVeveeeveeV :
  if 'youtube.com/channel/' in url :
   II1iI1I11I = url . split ( 'channel/' ) [ 1 ]
   iI1ii1Ii ( name , url , i1iI1 , iconimage , fanart , description = II1iI1I11I )
  elif 'youtube.com/user/' in url :
   II1iI1I11I = url . split ( 'user/' ) [ 1 ]
   iI1ii1Ii ( name , url , i1iI1 , iconimage , fanart , description = II1iI1I11I )
  elif 'youtube.com/playlist?' in url :
   II1iI1I11I = url . split ( 'list=' ) [ 1 ]
   iI1ii1Ii ( name , url , i1iI1 , iconimage , fanart , description = II1iI1I11I )
  elif 'plugin://' in url :
   i11i1iiI1i = HTMLParser ( )
   url = i11i1iiI1i . unescape ( url )
   iI1ii1Ii ( name , url , i1iI1 , iconimage , fanart )
  else :
   iI1ii1Ii ( name , url , 1 , iconimage , fanart )
   if 87 - 87: iiiIi
def IIIii ( ) :
 Veveveev = xbmc . Keyboard ( '' , '[B][COLOR cyan]What Would You Like Me To Find?[/COLOR][/B]' )
 Veveveev . doModal ( )
 if ( Veveveev . isConfirmed ( ) ) :
  II1iI1I11I = Veveveev . getText ( )
  II1iI1I11I = II1iI1I11I . upper ( )
 else : quit ( )
 eeeeevevev = iIIIi1 ( 'http://matsbuilds.uk/Menus/anewEvolvemenu/search.xml' )
 eee = re . compile ( '<link>(.+?)</link>' ) . findall ( eeeeevevev )
 for VeI1Ii11I1Ii1i in eee :
  try :
   eeeeevevev = iIIIi1 ( VeI1Ii11I1Ii1i )
   iiI = re . compile ( '<item>(.+?)</item>' ) . findall ( eeeeevevev )
   for VVVevevV in iiI :
    eeveveVVeve = re . compile ( '<title>(.+?)</title>' ) . findall ( VVVevevV )
    for VeVVevevev in eeveveVVeve :
     VeVVevevev = VeVVevevev . upper ( )
     if II1iI1I11I in VeVVevevev :
      eeeveVe ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV , VVVevevV )
  except : pass
  if 83 - 83: i1iIIi1 % eeveee % VevVVe . iiI1i1 - i1iIIi1
def eeveveIi1IIiiIIi ( url ) :
 string = "ShowPicture(%s)" % url
 xbmc . executebuiltin ( string )
 if 88 - 88: VeeevVVeveVV + VVeVeeevevee * Veeve % II1Iiii1111i
def I1I1iIi11i1II ( name , url , iconimage , description ) :
 if description : name = description
 try :
  if 'plugin://plugin.video.SportsDevil/' in url :
   ii1IIIIiI11 ( name , url , iconimage )
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
   url = url . replace ( '|' , '' )
   ii1IIIIiI11 ( name , url , iconimage )
  elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   iI1IIIii ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   iI1IIIii ( name , url , iconimage )
  else : iI1IIIii ( name , url , iconimage )
 except :
  I1i11ii11 ( VVevevVeveVV ( 'Picasso' ) , 'Stream Unavailable' , '3000' , Veveveeeeeevev )
  if 4 - 4: VeeevVVeveVV - Ii % i11IiIiiIIIII - eVVVeeveevV * eeveee
def i1I1ii ( url ) :
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 xbmc . Player ( ) . play ( url )
 if 85 - 85: VeeevVVeveVV * iiI1i1 . IiiIII111ii / VeeevVVeveVV % VevVVe % Ii11111i
def iI1IIIii ( name , url , iconimage ) :
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = eevVeeveVeveVVevev )
 eevVeeveVeveVVevev . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , eevVeeveVeveVVevev )
 if 36 - 36: i11IiIiiIIIII / Veeve / i1iIIi1 / i1iIIi1 + VVVevV
def ii1IIIIiI11 ( name , url , iconimage ) :
 xbmc . executebuiltin ( 'Dialog.Close(all,True)' )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage ) ; eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = eevVeeveVeveVVevev )
 xbmc . Player ( ) . play ( url , eevVeeveVeveVVevev , False )
 if 95 - 95: i1iIIi1
def Veeevee ( url ) :
 xbmc . executebuiltin ( "PlayMedia(%s)" % url )
 if 41 - 41: Veveevev * VVeVeeevevee / Veveevev % I1ii
def iIIIi1 ( url ) :
 IieVeveVVVevVee = urllib2 . Request ( url )
 IieVeveVVVevVee . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'aWhqdXJoeWRkZ3N0YWdhazk0aGZ5ZHM=' ) )
 i1i1I = urllib2 . urlopen ( IieVeveVVVevVee )
 eeeeevevev = i1i1I . read ( )
 i1i1I . close ( )
 eeeeevevev = eeeeevevev . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 if '{' in eeeeevevev :
  string = eeeeevevev [ : : - 1 ]
  string = string . replace ( '}' , '' ) . replace ( '{' , '' ) . replace ( ',' , '' ) . replace ( ']' , '' ) . replace ( '[' , '' )
  string = string + '=='
  eeeeevevev = string . decode ( 'base64' )
 if url <> IiI : eeeeevevev = eeeeevevev . replace ( '\n' , '' ) . replace ( '\r' , '' )
 print eeeeevevev
 return eeeeevevev
 if 25 - 25: iiI1i1 + VVVevV + IiiIII111ii / Veeve / VVeVeeevevee
def eeveevVeVeevVevVV ( url ) :
 IieVeveVVVevVee = urllib2 . Request ( url )
 IieVeveVVVevVee . add_header ( base64 . b64decode ( 'VXNlci1BZ2VudA==' ) , base64 . b64decode ( 'aWhqdXJoeWRkZ3N0YWdhazk0aGZ5ZHM=' ) )
 i1i1I = urllib2 . urlopen ( IieVeveVVVevVee )
 eeeeevevev = i1i1I . read ( )
 i1i1I . close ( )
 return eeeeevevev
 if 60 - 60: iiiIi * iI1I + II1Iiii1111i
def eeveeeeVeveevV ( url ) :
 IieVeveVVVevVee = urllib2 . Request ( url )
 IieVeveVVVevVee . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 i1i1I = urllib2 . urlopen ( IieVeveVVVevVee )
 eeeeevevev = i1i1I . read ( )
 i1i1I . close ( )
 eeeeevevev = eeeeevevev . replace ( '\n' , '' ) . replace ( '\r' , '' )
 return eeeeevevev
 if 19 - 19: VVeevevev * VVeVeeevevee / VVeVeeevevee . VeeevVVeveVV - eVVVeeveevV + i11iIiiIii
 if 88 - 88: i11iIiiIii - iiiIi
def VeviIi1IiII ( ) :
 iiii ( )
 I1i = [ ]
 eeeii1iiIi1 = sys . argv [ 2 ]
 if len ( eeeii1iiIi1 ) >= 2 :
  VevVeevevVeVe = sys . argv [ 2 ]
  i111iiI1ii = VevVeevevVeVe . replace ( '?' , '' )
  if ( VevVeevevVeVe [ len ( VevVeevevVeVe ) - 1 ] == '/' ) :
   VevVeevevVeVe = VevVeevevVeVe [ 0 : len ( VevVeevevVeVe ) - 2 ]
  IIiii = i111iiI1ii . split ( '&' )
  I1i = { }
  for I1I11i in range ( len ( IIiii ) ) :
   I1i1i = { }
   I1i1i = IIiii [ I1I11i ] . split ( '=' )
   if ( len ( I1i1i ) ) == 2 :
    I1i [ I1i1i [ 0 ] ] = I1i1i [ 1 ]
 return I1i
 if 86 - 86: II1Iiii1111i / I1ii + Ii11111i * IiiIII111ii
def I1i11ii11 ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 19 - 19: Veeve * i1iIIi1 + i11IiIiiIIIII
def Vevii1ii1ii ( string ) :
 Veve = re . compile ( '(\[.+?\])' ) . findall ( string )
 for eVeveveV in Veve : string = string . replace ( eVeveveV , '' )
 return string
 if 36 - 36: eVVVeeveevV
def VVevevVeveVV ( string ) :
 string = string . split ( ' ' )
 Veveii111 = ''
 for VevVVeveVeVevVevV in string :
  eeeveveveVeev = '[B][COLOR yellow]' + VevVVeveVeVevVevV [ 0 ] . upper ( ) + '[/COLOR][COLOR white]' + VevVVeveVeVevVevV [ 1 : ] + '[/COLOR][/B] '
  Veveii111 = Veveii111 + eeeveveveVeev
 return Veveii111
 if 6 - 6: VVeevevev - Ii
def VVV ( name , url , mode , iconimage , itemcount , metatype , isFolder = False , description = '' ) :
 if isFolder == True : VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 else : VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 if VVVeev == 'true' :
  I1IiIIi = name
  name = Vevii1ii1ii ( name )
  IiVVeevev = ""
  iIII = ""
  Ii1iI11iI1 = [ ]
  i11 = eval ( base64 . b64decode ( 'bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ==' ) )
  eevVVVVevevVevVe = { }
  if metatype == 'movie' :
   eVeevevVeveeeveveev = name . partition ( '(' )
   if len ( eVeevevVeveeeveveev ) > 0 :
    IiVVeevev = eVeevevVeveeeveveev [ 0 ]
    iIII = eVeevevVeveeeveveev [ 2 ] . partition ( ')' )
   if len ( iIII ) > 0 :
    iIII = iIII [ 0 ]
   eevVVVVevevVevVe = i11 . get_meta ( 'movie' , name = IiVVeevev , year = iIII )
   if not eevVVVVevevVevVe [ 'trailer' ] == '' : Ii1iI11iI1 . append ( ( VVevevVeveVV ( 'Play Trailer' ) , 'XBMC.RunPlugin(%s)' % VeevVee . build_plugin_url ( { 'mode' : 11 , 'url' : eevVVVVevevVevVe [ 'trailer' ] } ) ) )
  elif metatype == 'tvep' :
   VeVVevevev = VevVevVVevVevVev . getSetting ( 'tv' )
   if '<>' in url :
    print url
    I1IIII1i = url . split ( '<>' ) [ 0 ]
    i1Iii1i1I = url . split ( '<>' ) [ 1 ]
    VVeVevev = url . split ( '<>' ) [ 2 ]
    IiI111111IIII = url . split ( '<>' ) [ 3 ]
    i1Ii = url . split ( '<>' ) [ 4 ]
    ii111iI1iIi1 = url . split ( '<>' ) [ 5 ]
    eevVVVVevevVevVe = i11 . get_episode_meta ( i1Iii1i1I , imdb_id = I1IIII1i , season = VVeVevev , episode = IiI111111IIII , air_date = '' , episode_title = '' , overlay = '' )
   else :
    I1II = re . compile ( 'Season (.+?) Episode (.+?)\)' ) . findall ( name )
    for VVev , VVVeveVVeevevV in I1II :
     eevVVVVevevVevVe = i11 . get_episode_meta ( VeVVevevev , imdb_id = '' , season = VVev , episode = VVVeveVVeevevV , air_date = '' , episode_title = '' , overlay = '' )
  try :
   if eevVVVVevevVevVe [ 'cover_url' ] == '' : iconimage = iconimage
   else : iconimage = eevVVVVevevVevVe [ 'cover_url' ]
  except : pass
  eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( eeeevVV ) + "&iconimage=" + urllib . quote_plus ( iconimage )
  I1II1 = True
  eevVeeveVeveVVevev = xbmcgui . ListItem ( I1IiIIi , iconImage = iconimage , thumbnailImage = iconimage )
  eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = eevVVVVevevVevVe )
  eevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
  eevVeeveVeveVVevev . addContextMenuItems ( Ii1iI11iI1 , replaceItems = False )
  if not eevVVVVevevVevVe . get ( 'backdrop_url' , '' ) == '' : eevVeeveVeveVVevev . setProperty ( 'fanart_image' , eevVVVVevevVevVe [ 'backdrop_url' ] )
  else : eevVeeveVeveVVevev . setProperty ( 'fanart_image' , eeeevVV )
  VVeveIII111i11IiI = VevVevVVevVevVev . getSetting ( 'favlist' )
  Vevevevev = [ ]
  Vevevevev . append ( ( VVevevVeveVV ( 'Stream Information' ) , 'XBMC.Action(Info)' ) )
  if VVeveIII111i11IiI == 'yes' : Vevevevev . append ( ( '[COLOR cyan]Remove From Keep Safe? [/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  else : Vevevevev . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
  eevVeeveVeveVVevev . addContextMenuItems ( Vevevevev , replaceItems = False )
  I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = isFolder , totalItems = itemcount )
  return I1II1
 else :
  if isFolder :
   iI1ii1Ii ( name , url , mode , iconimage , eeeevVV , description = '' )
  else :
   i11I1II1I11i ( name , url , mode , iconimage , eeeevVV , description = '' )
   if 64 - 64: Veeve - VevVVe
def iI1ii1Ii ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'folder' )
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eevVeeveVeveVVevev . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 eevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 if 'youtube.com/channel/' in url :
  eeveveveveV = 'plugin://plugin.video.youtube/channel/' + description + '/'
 if 'youtube.com/user/' in url :
  eeveveveveV = 'plugin://plugin.video.youtube/user/' + description + '/'
 if 'youtube.com/playlist?' in url :
  eeveveveveV = 'plugin://plugin.video.youtube/playlist/' + description + '/'
 if 'plugin://' in url :
  eeveveveveV = url
 Vevevevev = [ ]
 VVeveIII111i11IiI = VevVevVVevVevVev . getSetting ( 'favlist' )
 if VVeveIII111i11IiI == 'yes' : Vevevevev . append ( ( '[COLOR cyan]Remove From Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : Vevevevev . append ( ( '[COLOR cyan]Add To Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 eevVeeveVeveVVevev . addContextMenuItems ( Vevevevev , replaceItems = False )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = True )
 return I1II1
 if 68 - 68: iiiIi - eVVVeeveevV - iiI1i1 / Veveevev + eVVVeeveevV - VVeevevev
def IIi1I11I1II ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 Vevevevev = [ ]
 VVeveIII111i11IiI = VevVevVVevVevVev . getSetting ( 'favlist' )
 if VVeveIII111i11IiI == 'yes' : Vevevevev . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : Vevevevev . append ( ( '[COLOR cyan]Add to Keeo Safe[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 eevVeeveVeveVVevev . addContextMenuItems ( Vevevevev , replaceItems = False )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = False )
 return I1II1
 if 75 - 75: IiiIII111ii / eeveee % iiI1i1 . VeeevVVeveVV % VeeevVVeveVV % Veeve
def i11I1II1I11i ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVVevVevVev . setSetting ( 'favtype' , 'link' )
 eeveveveveV = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1II1 = True
 eevVeeveVeveVVevev = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 eevVeeveVeveVVevev . setProperty ( 'fanart_image' , fanart )
 eevVeeveVeveVVevev . setProperty ( "IsPlayable" , "true" )
 Vevevevev = [ ]
 VVeveIII111i11IiI = VevVevVVevVevVev . getSetting ( 'favlist' )
 if VVeveIII111i11IiI == 'yes' : Vevevevev . append ( ( '[COLOR cyan]Remove from Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=21&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 else : Vevevevev . append ( ( '[COLOR cyan]Add to Keep Safe?[/COLOR]' , 'XBMC.RunPlugin(%s?mode=20&name=%s&url=%s&iconimage=%s)' % ( sys . argv [ 0 ] , name , url , iconimage ) ) )
 eevVeeveVeveVVevev . addContextMenuItems ( Vevevevev , replaceItems = False )
 I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = eeveveveveV , listitem = eevVeeveVeveVVevev , isFolder = False )
 return I1II1
iiII1i1 = base64 . b64decode ( 'aHR0cDovL21hdHNidWlsZHMudWsvTWVudXMvYW5ld0V2b2x2ZW1lbnUvRXZvbHZlTWFpbk1lbnUueG1s' )
def I11IiI1I11i1i ( url , name ) :
 Ii1i1i1111 = eeveevVeVeevVevVV ( url )
 if len ( Ii1i1i1111 ) > 1 :
  Ii1iI = eeVe
  IiiIiI1Ii1i = os . path . join ( os . path . join ( Ii1iI , '' ) , name + '.txt' )
  if not os . path . exists ( IiiIiI1Ii1i ) :
   file ( IiiIiI1Ii1i , 'w' ) . close ( )
  eeveVevVeveveVe = open ( IiiIiI1Ii1i )
  I1111I1II11 = eeveVevVeveveVe . read ( )
  if I1111I1II11 == Ii1i1i1111 : pass
  else :
   iiVeV ( '[B][COLOR yellow]PICASSO INFO[/COLOR][/B]' , Ii1i1i1111 )
   i1iIi = open ( IiiIiI1Ii1i , "w" )
   i1iIi . write ( Ii1i1i1111 )
   i1iIi . close ( )
   if 30 - 30: VeeevVVeveVV % VeeevVVeveVV
def iiVeV ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 eVeVeeev = xbmcgui . Window ( id )
 ii1II = 50
 while ( ii1II > 0 ) :
  try :
   xbmc . sleep ( 10 )
   ii1II -= 1
   eVeVeeev . getControl ( 1 ) . setLabel ( heading )
   eVeVeeev . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 50 - 50: i11IiIiiIIIII + Ii / Ii11111i / eeveee
def Iii ( name ) :
 global Icon
 global Next
 global Previous
 global window
 global Quit
 global images
 IiiIiI1Ii1i = os . path . join ( os . path . join ( eeVe , '' ) , name + '.txt' )
 eeveVevVeveveVe = open ( IiiIiI1Ii1i )
 I1111I1II11 = eeveVevVeveveVe . read ( )
 images = re . compile ( '<image>(.+?)</image>' ) . findall ( I1111I1II11 )
 VevVevVVevVevVev . setSetting ( 'pos' , '0' )
 window = pyxbmct . AddonDialogWindow ( '' )
 i1I1 = '/resources/art'
 VevII11i11II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + i1I1 , 'next_focus.png' ) )
 II1Ii1iI1i1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + i1I1 , 'next1.png' ) )
 eevVeVevevevV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + i1I1 , 'previous_focus.png' ) )
 VVe = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + i1I1 , 'previous.png' ) )
 iIIiiIIIi1I = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + i1I1 , 'close_focus.png' ) )
 VVeveeveeveeevV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + i1I1 , 'close.png' ) )
 IIiI1I1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + VVeve + i1I1 , 'main-bg1.png' ) )
 window . setGeometry ( 1300 , 720 , 100 , 50 )
 I11I1IIiiII1 = pyxbmct . Image ( IIiI1I1 )
 window . placeControl ( I11I1IIiiII1 , - 10 , - 10 , 130 , 70 )
 eVevee = '0xFF000000'
 Previous = pyxbmct . Button ( '' , focusTexture = eevVeVevevevV , noFocusTexture = VVe , textColor = eVevee , focusedColor = eVevee )
 Next = pyxbmct . Button ( '' , focusTexture = VevII11i11II , noFocusTexture = II1Ii1iI1i1 , textColor = eVevee , focusedColor = eVevee )
 Quit = pyxbmct . Button ( '' , focusTexture = iIIiiIIIi1I , noFocusTexture = VVeveeveeveeevV , textColor = eVevee , focusedColor = eVevee )
 Icon = pyxbmct . Image ( images [ 0 ] , aspectRatio = 2 )
 window . placeControl ( Previous , 102 , 1 , 10 , 10 )
 window . placeControl ( Next , 102 , 40 , 10 , 10 )
 window . placeControl ( Quit , 102 , 21 , 10 , 10 )
 window . placeControl ( Icon , 0 , 0 , 100 , 50 )
 Previous . controlRight ( Next )
 Previous . controlUp ( Quit )
 window . connect ( Previous , IIIIIii1ii11 )
 window . connect ( Next , VVVeeeevVeeVeV )
 Previous . setVisible ( False )
 window . setFocus ( Quit )
 Previous . controlRight ( Quit )
 Quit . controlLeft ( Previous )
 Quit . controlRight ( Next )
 Next . controlLeft ( Quit )
 window . connect ( Quit , window . close )
 window . doModal ( )
 del window
 if 91 - 91: I1ii + VevVVe
def VVVeeeevVeeVeV ( ) :
 VeVeee = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 eeevevVVeVeVevev = int ( VeVeee ) + 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( eeevevVVeVeVevev ) )
 I1iii = len ( images )
 Icon . setImage ( images [ int ( eeevevVVeVeVevev ) ] )
 Previous . setVisible ( True )
 if int ( eeevevVVeVeVevev ) == int ( I1iii ) - 1 :
  Next . setVisible ( False )
  if 51 - 51: VVVevV
def IIIIIii1ii11 ( ) :
 VeVeee = int ( VevVevVVevVevVev . getSetting ( 'pos' ) )
 III1I1Ii11iI = int ( VeVeee ) - 1
 VevVevVVevVevVev . setSetting ( 'pos' , str ( III1I1Ii11iI ) )
 Icon . setImage ( images [ int ( III1I1Ii11iI ) ] )
 Next . setVisible ( True )
 if int ( III1I1Ii11iI ) == 0 :
  Previous . setVisible ( False )
  if 52 - 52: eVVVeeveevV - IiiIII111ii * I1ii
def Ii1I11I ( url , fanart ) :
 VevVevVVevVevVev . setSetting ( 'favlist' , 'yes' )
 iiIii1I = None
 file = open ( Ve , 'r' )
 iiIii1I = file . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 eeveveVVeve = re . compile ( "<item>(.+?)</item>" , re . DOTALL ) . findall ( iiIii1I )
 for VVVevevV in eeveveVVeve :
  eeeveVe ( VeveevVevevVeeveev , url , Veveveeeeeevev , fanart , VVVevevV )
 VevVevVVevVevVev . setSetting ( 'favlist' , 'no' )
 if 47 - 47: iiiIi . VVeVeeevevee / eeveee
def VVeVV ( name , url , iconimage , fanart ) :
 VVevVVevVV = VevVevVVevVevVev . getSetting ( 'favtype' )
 url = url . replace ( ' ' , '%20' )
 iconimage = iconimage . replace ( ' ' , '%20' )
 if '<>' in url :
  I1IIII1i = url . split ( '<>' ) [ 0 ]
  VVeVevev = url . split ( '<>' ) [ 1 ]
  IiI111111IIII = url . split ( '<>' ) [ 2 ]
  i1Ii = url . split ( '<>' ) [ 3 ]
  ii111iI1iIi1 = url . split ( '<>' ) [ 4 ]
  string = '<FAV><item>\n<title>' + name + '</title>\n<meta>tvep</meta>\n<nan>tvshow</nan>\n<showyear>' + i1Ii + '</showyear>\n<imdb>' + I1IIII1i + '</imdb>\n<season>' + VVeVevev + '</season>\n<episode>' + IiI111111IIII + '</episode>\n<episodeyear>' + ii111iI1iIi1 + '</episodeyear>\n<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 elif len ( url ) == 9 :
  string = '<FAV><item>\n<title>' + name + '</title>\n<meta>movie</meta>\n<nan>movie</nan>\n<imdb>' + url + '</imdb>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 else :
  string = '<FAV><item>\n<title>' + name + '</title>\n<' + VVevVVevVV + '>' + url + '</' + VVevVVevVV + '>\n' + '<thumbnail>' + iconimage + '</thumbnail>\n<fanart>' + fanart + '</fanart></item></FAV>\n'
 IiII = open ( Ve , 'a' )
 IiII . write ( string )
 IiII . close ( )
 if 61 - 61: VeeevVVeveVV . I1ii . VeeevVVeveVV / II1Iiii1111i
def eevevV ( name , url , iconimage ) :
 print name
 iiIii1I = None
 file = open ( Ve , 'r' )
 iiIii1I = file . read ( )
 i1i = ''
 eeveveVVeve = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( iiIii1I )
 for VVeVVeveeeveeV in eeveveVVeve :
  string = '\n<FAV><item>\n' + VVeVVeveeeveeV + '</item>\n'
  if name in VVeVVeveeeveeV :
   print 'xxxxxxxxxxxxxxxxx'
   string = string . replace ( 'item' , ' ' )
  i1i = i1i + string
 file = open ( Ve , 'w' )
 file . truncate ( )
 file . write ( i1i )
 file . close ( )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 5 - 5: I1ii . VVVevV . Veeve . VeeevVVeveVV
def VeeveVeveve ( url ) :
 try :
  i11IIIiI1I = url . split ( '/' ) [ 2 ] . replace ( 'www.' , '' )
  file = open ( IIi1IiiiI1Ii , 'r' )
  VeevVeeVev = file . read ( )
  if i11IIIiI1I in VeevVeeVev : return '[COLOR cyan] (RD)[/COLOR]'
  else : return ''
 except : return ''
 if 87 - 87: I1ii % i11IiIiiIIIII
def eeevVVVeVe ( ) :
 xbmcaddon . Addon ( 'script.module.nanscrapers' ) . openSettings ( )
 if 21 - 21: VVeevevev - Ii11111i . I1ii + i11IiIiiIIIII . iiI1i1 - Veveevev
def I11IIIiIi11 ( ) :
 xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
 if 39 - 39: i11IiIiiIIIII % Ii11111i % Veveevev . Ii
def eVeevevVeeVeveV ( ) :
 xbmcaddon . Addon ( 'script.module.metahandler' ) . openSettings ( )
 if 16 - 16: i1iIIi1 / II1Iiii1111i + eVVVeeveevV / i11IiIiiIIIII
def eeeevV ( link ) :
 try :
  IIIiiI1 = re . compile ( '<layouttype>(.+?)</layouttype>' ) . findall ( link ) [ 0 ]
  if IIIiiI1 == 'thumbnail' : xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 except : pass
 if 74 - 74: VVeVeeevevee - eVVVeeveevV + Ii . VevVVe + eVVVeeveevV - VVeVeeevevee
 if 17 - 17: Ii11111i . iI1I . Ii11111i + Ii11111i / II1Iiii1111i . iiiIi
VevVeevevVeVe = VeviIi1IiII ( ) ; VeI1Ii11I1Ii1i = None ; VeveevVevevVeeveev = None ; i1iI1 = None ; VVevevVVeVeve = None ; VevevVeveVVevevVevev = None ; Iiiiiii1 = None
try : VVevevVVeVeve = urllib . unquote_plus ( VevVeevevVeVe [ "site" ] )
except : pass
try : VeI1Ii11I1Ii1i = urllib . unquote_plus ( VevVeevevVeVe [ "url" ] )
except : pass
try : VeveevVevevVeeveev = urllib . unquote_plus ( VevVeevevVeVe [ "name" ] )
except : pass
try : i1iI1 = int ( VevVeevevVeVe [ "mode" ] )
except : pass
try : VevevVeveVVevevVevev = urllib . unquote_plus ( VevVeevevVeVe [ "iconimage" ] )
except : pass
try : eeeevVV = urllib . unquote_plus ( VevVeevevVeVe [ "fanart" ] )
except : pass
try : Iiiiiii1 = str ( VevVeevevVeVe [ "description" ] )
except : pass
if 78 - 78: VVVevV + VVeVeeevevee - Ii11111i
if i1iI1 == None or VeI1Ii11I1Ii1i == None or len ( VeI1Ii11I1Ii1i ) < 1 : Veeveveve ( )
elif i1iI1 == 1 : iiIii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 2 : I1I1iIi11i1II ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , Iiiiiii1 )
elif i1iI1 == 3 : i1iIiIi1I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 4 : iI1IIIii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 5 : IIIii ( )
elif i1iI1 == 6 : IIiii11i ( VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 7 : eeveveIi1IIiiIIi ( VeI1Ii11I1Ii1i )
elif i1iI1 == 8 : Iii ( VeveevVevevVeeveev )
elif i1iI1 == 9 : VVeveeeeveVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i )
elif i1iI1 == 10 : I111i1i1111 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 11 : Veeevee ( VeI1Ii11I1Ii1i )
elif i1iI1 == 12 : I11IIIiIi11 ( )
elif i1iI1 == 13 : eVeevevVeeVeveV ( )
elif i1iI1 == 15 : SCRAPEMOVIE ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 16 : ii1IIIIiI11 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 17 : IIiiI ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i )
elif i1iI1 == 18 : eeveeeVVevev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 19 : I1I1I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 10 - 10: iI1I % VevVVe
elif i1iI1 == 20 : VVeVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 21 : eevevV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
elif i1iI1 == 22 : Ii1I11I ( VeI1Ii11I1Ii1i , eeeevVV )
elif i1iI1 == 23 : DOIPLAYER ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 24 : VevevVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 25 : eeevVVVeVe ( )
if 97 - 97: VeeevVVeveVV - iI1I
elif i1iI1 == 26 : eev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 27 : VVeveVeVVeveVVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 28 : VeveVeeveve ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 29 : VevVeeeVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 30 : VVVeveveveveV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 31 : iI1i11II1i ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 32 : VeeeeVeveVVVV ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 33 : VVeeeevVeveev ( VeI1Ii11I1Ii1i )
elif i1iI1 == 34 : III11I1 ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 35 : VevevVee ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 58 - 58: iiI1i1 + Ii11111i
elif i1iI1 == 36 : VVevVVVVeeevVVV ( )
elif i1iI1 == 37 : eevVeevev ( VeI1Ii11I1Ii1i )
elif i1iI1 == 38 : ii1111iII ( VeI1Ii11I1Ii1i )
elif i1iI1 == 39 : VevVeveeVVV ( VeI1Ii11I1Ii1i )
elif i1iI1 == 40 : VVVeVe ( )
elif i1iI1 == 41 : VeVevevevVevVe ( VeI1Ii11I1Ii1i )
elif i1iI1 == 42 : eeeVeevVVVeeev ( VeI1Ii11I1Ii1i )
if 30 - 30: iiiIi % IiiIII111ii * eVVVeeveevV - VVVevV * i11IiIiiIIIII % iiiIi
elif i1iI1 == 43 : Iii1iiIi1II ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 44 : eeeIIiIiI1I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 45 : III1I1Iii1iiI ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 46 : VeveevVev ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
if 46 - 46: i11iIiiIii - Ii11111i . I1ii
elif i1iI1 == 47 : DODOCLOGMENU ( )
elif i1iI1 == 48 : GET_DOCCONTENT ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , II1 )
elif i1iI1 == 49 : DO_DOCCONTENT ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , II1 )
elif i1iI1 == 50 : RESOLVE2 ( VeI1Ii11I1Ii1i )
elif i1iI1 == 51 : ii111I ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev , eeeevVV )
elif i1iI1 == 52 : IIiI1Ii ( VeveevVevevVeeveev , VeI1Ii11I1Ii1i , VevevVeveVVevevVevev )
if 100 - 100: VevVVe / eeveee * IiiIII111ii . Ii11111i / eVVVeeveevV
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
