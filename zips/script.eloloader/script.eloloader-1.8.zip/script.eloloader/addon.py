import time
import xbmc
import os
import xbmcgui
import urllib2

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elysium/?action=movieNavigator",return)')
