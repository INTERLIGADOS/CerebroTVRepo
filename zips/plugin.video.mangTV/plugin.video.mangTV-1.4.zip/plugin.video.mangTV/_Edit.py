import xbmcaddon

MainBase = 'https://archive.org/download/mangkulaspiro_gmail_Home/home.xml'
addon = xbmcaddon.Addon('plugin.video.mangTV')